/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: adminanmkavps_tbl
-- ------------------------------------------------------
-- Server version	11.4.8-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `SequelizeMeta`
--

DROP TABLE IF EXISTS `SequelizeMeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `SequelizeMeta` (
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SequelizeMeta`
--

LOCK TABLES `SequelizeMeta` WRITE;
/*!40000 ALTER TABLE `SequelizeMeta` DISABLE KEYS */;
INSERT INTO `SequelizeMeta` VALUES
('20260210000000-add-orders-guest-columns.js'),
('20260509183000-create-marketing-tables.js'),
('20260509190000-create-whatsapp-integrations.js'),
('20260510120000-orders-user-id-nullable-for-guest.js'),
('20260510133000-add-whatsapp-phone-country-code.js'),
('20260510140000-add-whatsapp-business-account-id.js'),
('20260603120000-add-category-coming-soon-labels.js'),
('20260608120000-add-paymob-payment-method.js'),
('20260609120000-create-store-analytics-tables.js'),
('20260609140000-add-product-hero-ticker-fields.js'),
('20260610120000-add-subcategory-parent-id.js');
/*!40000 ALTER TABLE `SequelizeMeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `country` varchar(100) DEFAULT 'EG',
  `city` varchar(100) NOT NULL,
  `district` varchar(100) DEFAULT NULL,
  `street` varchar(200) DEFAULT NULL,
  `building` varchar(50) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_ar` varchar(200) DEFAULT NULL,
  `title_en` varchar(200) DEFAULT NULL,
  `subtitle_ar` varchar(300) DEFAULT NULL,
  `subtitle_en` varchar(300) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `mobile_image` varchar(500) DEFAULT NULL,
  `link` varchar(300) DEFAULT NULL,
  `type` enum('hero','promotion','category','brand') DEFAULT 'hero',
  `position` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cart_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `size` varchar(20) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_id` (`cart_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `cart_items_ibfk_53` FOREIGN KEY (`cart_id`) REFERENCES `carts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cart_items_ibfk_54` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `carts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carts`
--

LOCK TABLES `carts` WRITE;
/*!40000 ALTER TABLE `carts` DISABLE KEYS */;
INSERT INTO `carts` VALUES
(1,1,NULL,'2026-06-03 11:23:52','2026-06-03 11:23:52'),
(2,2,NULL,'2026-06-08 13:14:23','2026-06-08 13:14:23'),
(3,7,NULL,'2026-06-08 23:59:51','2026-06-08 23:59:51');
/*!40000 ALTER TABLE `carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_ar` varchar(100) NOT NULL,
  `name_en` varchar(100) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `description_ar` text DEFAULT NULL,
  `description_en` text DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `meta_title_ar` varchar(200) DEFAULT NULL,
  `meta_title_en` varchar(200) DEFAULT NULL,
  `meta_description_ar` text DEFAULT NULL,
  `meta_description_en` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `coming_soon_label_en` varchar(80) DEFAULT NULL,
  `coming_soon_label_ar` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `slug_2` (`slug`),
  UNIQUE KEY `slug_3` (`slug`),
  UNIQUE KEY `slug_4` (`slug`),
  UNIQUE KEY `slug_5` (`slug`),
  UNIQUE KEY `slug_6` (`slug`),
  UNIQUE KEY `slug_7` (`slug`),
  UNIQUE KEY `slug_8` (`slug`),
  UNIQUE KEY `slug_9` (`slug`),
  UNIQUE KEY `slug_10` (`slug`),
  UNIQUE KEY `slug_11` (`slug`),
  UNIQUE KEY `slug_12` (`slug`),
  UNIQUE KEY `slug_13` (`slug`),
  UNIQUE KEY `slug_14` (`slug`),
  UNIQUE KEY `slug_15` (`slug`),
  UNIQUE KEY `slug_16` (`slug`),
  UNIQUE KEY `slug_17` (`slug`),
  UNIQUE KEY `slug_18` (`slug`),
  UNIQUE KEY `slug_19` (`slug`),
  UNIQUE KEY `slug_20` (`slug`),
  UNIQUE KEY `slug_21` (`slug`),
  UNIQUE KEY `slug_22` (`slug`),
  UNIQUE KEY `slug_23` (`slug`),
  UNIQUE KEY `slug_24` (`slug`),
  UNIQUE KEY `slug_25` (`slug`),
  UNIQUE KEY `slug_26` (`slug`),
  UNIQUE KEY `slug_27` (`slug`),
  UNIQUE KEY `slug_28` (`slug`),
  UNIQUE KEY `slug_29` (`slug`),
  UNIQUE KEY `slug_30` (`slug`),
  UNIQUE KEY `slug_31` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES
(1,'ملابس نسائية','Women','womens-clothing',NULL,NULL,'/api/uploads/1781042527784-675953779.jpeg',0,6,NULL,NULL,NULL,NULL,'2026-06-02 08:17:45','2026-06-09 22:02:07','(2027)','(2027)'),
(2,'ملابس رجالية','Men','mens-clothing',NULL,NULL,'/api/uploads/1781042457828-538325592.jpeg',1,1,NULL,NULL,NULL,NULL,'2026-06-02 08:17:45','2026-06-09 22:00:57',NULL,NULL),
(3,'ملابس أطفال','Kids','childrens-clothing',NULL,NULL,'/api/uploads/1781042491975-320596999.jpeg',0,5,NULL,NULL,NULL,NULL,'2026-06-02 08:17:45','2026-06-09 22:47:43','(2027)','(2027)'),
(4,'إكسسوارات','Accessories','accessories',NULL,NULL,'/api/uploads/1781042477145-332449430.jpeg',0,2,NULL,NULL,NULL,NULL,'2026-06-03 08:33:50','2026-06-09 22:01:17','(SEP)','(سبتمبر)'),
(5,'أحذية','Shoes','shoes',NULL,NULL,'/photos/v0XCMMD3lRM3TU0xC5O5upOnFM.jpeg',0,3,NULL,NULL,NULL,NULL,'2026-06-03 08:33:50','2026-06-09 21:53:49','(SEP)','(سبتمبر)'),
(6,'عطور','Perfumes','perfumes',NULL,NULL,'/photos/9634.jpg',0,4,NULL,NULL,NULL,NULL,'2026-06-03 08:33:50','2026-06-09 21:53:56','(SEP)','(سبتمبر)');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `type` enum('percentage','fixed') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `min_order_amount` decimal(10,2) DEFAULT 0.00,
  `max_discount_amount` decimal(10,2) DEFAULT NULL,
  `usage_limit` int(11) DEFAULT NULL,
  `used_count` int(11) DEFAULT 0,
  `user_limit` int(11) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `starts_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `description_ar` varchar(300) DEFAULT NULL,
  `description_en` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `code_2` (`code`),
  UNIQUE KEY `code_3` (`code`),
  UNIQUE KEY `code_4` (`code`),
  UNIQUE KEY `code_5` (`code`),
  UNIQUE KEY `code_6` (`code`),
  UNIQUE KEY `code_7` (`code`),
  UNIQUE KEY `code_8` (`code`),
  UNIQUE KEY `code_9` (`code`),
  UNIQUE KEY `code_10` (`code`),
  UNIQUE KEY `code_11` (`code`),
  UNIQUE KEY `code_12` (`code`),
  UNIQUE KEY `code_13` (`code`),
  UNIQUE KEY `code_14` (`code`),
  UNIQUE KEY `code_15` (`code`),
  UNIQUE KEY `code_16` (`code`),
  UNIQUE KEY `code_17` (`code`),
  UNIQUE KEY `code_18` (`code`),
  UNIQUE KEY `code_19` (`code`),
  UNIQUE KEY `code_20` (`code`),
  UNIQUE KEY `code_21` (`code`),
  UNIQUE KEY `code_22` (`code`),
  UNIQUE KEY `code_23` (`code`),
  UNIQUE KEY `code_24` (`code`),
  UNIQUE KEY `code_25` (`code`),
  UNIQUE KEY `code_26` (`code`),
  UNIQUE KEY `code_27` (`code`),
  UNIQUE KEY `code_28` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landing_page_orders`
--

DROP TABLE IF EXISTS `landing_page_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_page_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `landing_page_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `landing_page_id` (`landing_page_id`),
  CONSTRAINT `landing_page_orders_ibfk_1` FOREIGN KEY (`landing_page_id`) REFERENCES `landing_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_page_orders`
--

LOCK TABLES `landing_page_orders` WRITE;
/*!40000 ALTER TABLE `landing_page_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `landing_page_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landing_page_sections`
--

DROP TABLE IF EXISTS `landing_page_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_page_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `landing_page_id` int(11) NOT NULL,
  `type` enum('hero','product','features','countdown','text','image','testimonials','stats','cta','gallery') NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `sort_order` int(11) DEFAULT 0,
  `is_visible` tinyint(1) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `landing_page_id` (`landing_page_id`),
  CONSTRAINT `landing_page_sections_ibfk_1` FOREIGN KEY (`landing_page_id`) REFERENCES `landing_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_page_sections`
--

LOCK TABLES `landing_page_sections` WRITE;
/*!40000 ALTER TABLE `landing_page_sections` DISABLE KEYS */;
/*!40000 ALTER TABLE `landing_page_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landing_page_views`
--

DROP TABLE IF EXISTS `landing_page_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_page_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `landing_page_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `landing_page_id` (`landing_page_id`),
  CONSTRAINT `landing_page_views_ibfk_1` FOREIGN KEY (`landing_page_id`) REFERENCES `landing_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_page_views`
--

LOCK TABLES `landing_page_views` WRITE;
/*!40000 ALTER TABLE `landing_page_views` DISABLE KEYS */;
/*!40000 ALTER TABLE `landing_page_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `landing_pages`
--

DROP TABLE IF EXISTS `landing_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `landing_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title_ar` varchar(200) NOT NULL,
  `title_en` varchar(200) DEFAULT NULL,
  `slug` varchar(250) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `status` enum('draft','published') DEFAULT 'draft',
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `meta_title` varchar(200) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `slug_2` (`slug`),
  UNIQUE KEY `slug_3` (`slug`),
  UNIQUE KEY `slug_4` (`slug`),
  UNIQUE KEY `slug_5` (`slug`),
  UNIQUE KEY `slug_6` (`slug`),
  UNIQUE KEY `slug_7` (`slug`),
  UNIQUE KEY `slug_8` (`slug`),
  UNIQUE KEY `slug_9` (`slug`),
  UNIQUE KEY `slug_10` (`slug`),
  UNIQUE KEY `slug_11` (`slug`),
  UNIQUE KEY `slug_12` (`slug`),
  UNIQUE KEY `slug_13` (`slug`),
  UNIQUE KEY `slug_14` (`slug`),
  UNIQUE KEY `slug_15` (`slug`),
  UNIQUE KEY `slug_16` (`slug`),
  UNIQUE KEY `slug_17` (`slug`),
  UNIQUE KEY `slug_18` (`slug`),
  UNIQUE KEY `slug_19` (`slug`),
  UNIQUE KEY `slug_20` (`slug`),
  UNIQUE KEY `slug_21` (`slug`),
  UNIQUE KEY `slug_22` (`slug`),
  UNIQUE KEY `slug_23` (`slug`),
  UNIQUE KEY `slug_24` (`slug`),
  UNIQUE KEY `slug_25` (`slug`),
  UNIQUE KEY `slug_26` (`slug`),
  UNIQUE KEY `slug_27` (`slug`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `landing_pages_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `landing_pages`
--

LOCK TABLES `landing_pages` WRITE;
/*!40000 ALTER TABLE `landing_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `landing_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_bulk_jobs`
--

DROP TABLE IF EXISTS `marketing_bulk_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_bulk_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(64) NOT NULL DEFAULT 'send_full_events',
  `status` enum('queued','running','completed','failed') DEFAULT 'queued',
  `total` int(11) DEFAULT 0,
  `processed` int(11) DEFAULT 0,
  `success_count` int(11) DEFAULT 0,
  `fail_count` int(11) DEFAULT 0,
  `detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`detail`)),
  `error` text DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_bulk_jobs`
--

LOCK TABLES `marketing_bulk_jobs` WRITE;
/*!40000 ALTER TABLE `marketing_bulk_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_bulk_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_event_logs`
--

DROP TABLE IF EXISTS `marketing_event_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_event_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marketing_integration_id` int(11) DEFAULT NULL,
  `provider` varchar(32) NOT NULL,
  `event_name` varchar(80) NOT NULL,
  `event_id` varchar(120) DEFAULT NULL,
  `status` enum('pending','success','failed') DEFAULT 'pending',
  `http_status` int(11) DEFAULT NULL,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_payload`)),
  `response_body` text DEFAULT NULL,
  `error_message` text DEFAULT NULL,
  `retry_of_log_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `marketing_integration_id` (`marketing_integration_id`),
  CONSTRAINT `marketing_event_logs_ibfk_1` FOREIGN KEY (`marketing_integration_id`) REFERENCES `marketing_integrations` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_event_logs`
--

LOCK TABLES `marketing_event_logs` WRITE;
/*!40000 ALTER TABLE `marketing_event_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_event_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_failed_events`
--

DROP TABLE IF EXISTS `marketing_failed_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_failed_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marketing_integration_id` int(11) DEFAULT NULL,
  `provider` varchar(32) NOT NULL,
  `event_name` varchar(80) NOT NULL,
  `event_id` varchar(120) DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `error_message` text DEFAULT NULL,
  `last_log_id` int(11) DEFAULT NULL,
  `retries_count` int(11) DEFAULT 0,
  `resolved` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_failed_provider_resolved` (`provider`,`resolved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_failed_events`
--

LOCK TABLES `marketing_failed_events` WRITE;
/*!40000 ALTER TABLE `marketing_failed_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_failed_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_integration_settings`
--

DROP TABLE IF EXISTS `marketing_integration_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_integration_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marketing_integration_id` int(11) NOT NULL,
  `key` varchar(120) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_integration_setting_key` (`marketing_integration_id`,`key`),
  CONSTRAINT `marketing_integration_settings_ibfk_1` FOREIGN KEY (`marketing_integration_id`) REFERENCES `marketing_integrations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_integration_settings`
--

LOCK TABLES `marketing_integration_settings` WRITE;
/*!40000 ALTER TABLE `marketing_integration_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_integration_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_integrations`
--

DROP TABLE IF EXISTS `marketing_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_integrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` enum('meta','snapchat','google') NOT NULL,
  `enabled` tinyint(1) DEFAULT 0,
  `test_mode` tinyint(1) DEFAULT 0,
  `connection_status` enum('disconnected','connected','error','testing') DEFAULT 'disconnected',
  `last_sync_at` datetime DEFAULT NULL,
  `last_test_at` datetime DEFAULT NULL,
  `last_error` text DEFAULT NULL,
  `encrypted_credentials` text DEFAULT NULL,
  `iv` varchar(32) DEFAULT NULL,
  `auth_tag` varchar(32) DEFAULT NULL,
  `secret_version` int(11) DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `provider` (`provider`),
  UNIQUE KEY `provider_2` (`provider`),
  UNIQUE KEY `provider_3` (`provider`),
  UNIQUE KEY `provider_4` (`provider`),
  UNIQUE KEY `provider_5` (`provider`),
  UNIQUE KEY `provider_6` (`provider`),
  UNIQUE KEY `provider_7` (`provider`),
  UNIQUE KEY `provider_8` (`provider`),
  UNIQUE KEY `provider_9` (`provider`),
  UNIQUE KEY `provider_10` (`provider`),
  UNIQUE KEY `provider_11` (`provider`),
  UNIQUE KEY `provider_12` (`provider`),
  UNIQUE KEY `provider_13` (`provider`),
  UNIQUE KEY `provider_14` (`provider`),
  UNIQUE KEY `provider_15` (`provider`),
  UNIQUE KEY `provider_16` (`provider`),
  UNIQUE KEY `provider_17` (`provider`),
  UNIQUE KEY `provider_18` (`provider`),
  UNIQUE KEY `provider_19` (`provider`),
  UNIQUE KEY `provider_20` (`provider`),
  UNIQUE KEY `provider_21` (`provider`),
  UNIQUE KEY `provider_22` (`provider`),
  UNIQUE KEY `provider_23` (`provider`),
  UNIQUE KEY `provider_24` (`provider`),
  UNIQUE KEY `provider_25` (`provider`),
  UNIQUE KEY `provider_26` (`provider`),
  UNIQUE KEY `provider_27` (`provider`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_integrations`
--

LOCK TABLES `marketing_integrations` WRITE;
/*!40000 ALTER TABLE `marketing_integrations` DISABLE KEYS */;
INSERT INTO `marketing_integrations` VALUES
(1,'meta',0,0,'disconnected',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-06-02 08:19:14','2026-06-02 08:19:14'),
(2,'snapchat',0,0,'disconnected',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-06-02 08:19:14','2026-06-02 08:19:14'),
(3,'google',0,0,'disconnected',NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-06-02 08:19:14','2026-06-02 08:19:14');
/*!40000 ALTER TABLE `marketing_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_retry_queue`
--

DROP TABLE IF EXISTS `marketing_retry_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_retry_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(32) NOT NULL,
  `marketing_integration_id` int(11) DEFAULT NULL,
  `marketing_failed_event_id` int(11) DEFAULT NULL,
  `event_name` varchar(80) NOT NULL,
  `event_id` varchar(120) DEFAULT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `attempts` int(11) DEFAULT 0,
  `max_attempts` int(11) DEFAULT 6,
  `next_attempt_at` datetime NOT NULL,
  `status` enum('pending','processing','completed','dead') DEFAULT 'pending',
  `last_error` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_retry_status_next` (`status`,`next_attempt_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_retry_queue`
--

LOCK TABLES `marketing_retry_queue` WRITE;
/*!40000 ALTER TABLE `marketing_retry_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_retry_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nav_links`
--

DROP TABLE IF EXISTS `nav_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `nav_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label_en` varchar(100) NOT NULL,
  `label_ar` varchar(100) DEFAULT NULL,
  `slug` varchar(100) NOT NULL,
  `href` varchar(300) NOT NULL,
  `link_type` enum('browse','page') DEFAULT 'browse',
  `filter_config` text DEFAULT NULL,
  `product_ids` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `slug_2` (`slug`),
  UNIQUE KEY `slug_3` (`slug`),
  UNIQUE KEY `slug_4` (`slug`),
  UNIQUE KEY `slug_5` (`slug`),
  UNIQUE KEY `slug_6` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nav_links`
--

LOCK TABLES `nav_links` WRITE;
/*!40000 ALTER TABLE `nav_links` DISABLE KEYS */;
INSERT INTO `nav_links` VALUES
(3,'Brands','ماركات','brands','/products?nav=brands','browse','{}','[]',1,1,'2026-06-07 07:52:38','2026-06-07 08:55:33'),
(4,'Trending','رائج','trending','/products?nav=trending','browse','{\"best_sellers\":true}','[]',1,2,'2026-06-07 07:52:38','2026-06-07 08:55:33'),
(5,'New','جديد','new','/products?nav=new','browse','{\"new_arrivals\":true}','[]',1,3,'2026-06-07 07:52:38','2026-06-07 08:55:33'),
(6,'Deals','عروض','deals','/products?nav=deals','browse','{\"on_sale\":true}','[]',1,4,'2026-06-07 07:52:38','2026-06-07 08:55:33'),
(7,'Men','رجالي','men','/products?nav=men','browse','{\"gender\":\"men\"}','[]',1,5,'2026-06-07 07:52:38','2026-06-07 08:55:33'),
(8,'Women','نسائي','women','/products?nav=women','browse','{\"gender\":\"women\"}','[]',0,6,'2026-06-07 07:52:38','2026-06-07 08:55:33'),
(9,'Kids','أطفال','kids','/products?nav=kids','browse','{\"category_slug\":\"childrens-clothing\"}','[]',0,7,'2026-06-07 07:52:38','2026-06-07 08:55:33'),
(11,'Shoes','أحذية','shoes','/products?nav=shoes','browse','{\"category_slug\":\"shoes\"}','[]',0,8,'2026-06-07 07:52:38','2026-06-08 15:52:05'),
(13,'Accessories','إكسسوارات','accessories','/products?nav=accessories','browse','{\"category_slug\":\"accessories\"}','[]',0,9,'2026-06-07 07:52:38','2026-06-08 15:52:05'),
(16,'More','المزيد','more','/products?nav=more','browse','{}','[]',0,10,'2026-06-07 07:52:38','2026-06-08 15:52:05');
/*!40000 ALTER TABLE `nav_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `title_ar` varchar(200) DEFAULT NULL,
  `title_en` varchar(200) DEFAULT NULL,
  `body_ar` text DEFAULT NULL,
  `body_en` text DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variant_id` int(11) DEFAULT NULL,
  `name_ar` varchar(200) DEFAULT NULL,
  `name_en` varchar(200) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `image` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_ibfk_53` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_ibfk_54` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `guest_name` varchar(100) DEFAULT NULL,
  `guest_email` varchar(150) DEFAULT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `status` enum('pending','confirmed','processing','shipped','delivered','cancelled','refunded') DEFAULT 'pending',
  `subtotal` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) DEFAULT 0.00,
  `shipping_cost` decimal(10,2) DEFAULT 0.00,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `currency` varchar(5) DEFAULT 'EGP',
  `payment_method` enum('stripe','cod','bank_transfer','paymob') NOT NULL,
  `payment_status` enum('pending','paid','failed','refunded') DEFAULT 'pending',
  `shipping_address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`shipping_address`)),
  `billing_address` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`billing_address`)),
  `notes` text DEFAULT NULL,
  `tracking_number` varchar(100) DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `attribution` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attribution`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  UNIQUE KEY `order_number_2` (`order_number`),
  UNIQUE KEY `order_number_3` (`order_number`),
  UNIQUE KEY `order_number_4` (`order_number`),
  UNIQUE KEY `order_number_5` (`order_number`),
  UNIQUE KEY `order_number_6` (`order_number`),
  UNIQUE KEY `order_number_7` (`order_number`),
  UNIQUE KEY `order_number_8` (`order_number`),
  UNIQUE KEY `order_number_9` (`order_number`),
  UNIQUE KEY `order_number_10` (`order_number`),
  UNIQUE KEY `order_number_11` (`order_number`),
  UNIQUE KEY `order_number_12` (`order_number`),
  UNIQUE KEY `order_number_13` (`order_number`),
  UNIQUE KEY `order_number_14` (`order_number`),
  UNIQUE KEY `order_number_15` (`order_number`),
  UNIQUE KEY `order_number_16` (`order_number`),
  UNIQUE KEY `order_number_17` (`order_number`),
  UNIQUE KEY `order_number_18` (`order_number`),
  UNIQUE KEY `order_number_19` (`order_number`),
  UNIQUE KEY `order_number_20` (`order_number`),
  UNIQUE KEY `order_number_21` (`order_number`),
  UNIQUE KEY `order_number_22` (`order_number`),
  UNIQUE KEY `order_number_23` (`order_number`),
  UNIQUE KEY `order_number_24` (`order_number`),
  UNIQUE KEY `order_number_25` (`order_number`),
  UNIQUE KEY `order_number_26` (`order_number`),
  UNIQUE KEY `order_number_27` (`order_number`),
  UNIQUE KEY `order_number_28` (`order_number`),
  KEY `user_id` (`user_id`),
  KEY `coupon_id` (`coupon_id`),
  CONSTRAINT `orders_ibfk_55` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_56` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES
(1,'MW-1780844232836-10dd15350926',1,NULL,NULL,NULL,'pending',1680.00,0.00,50.00,259.50,1989.50,'EGP','cod','pending','{\"full_name\":\"Admin\",\"phone\":\"+201000000001\",\"email\":\"admin@theboutiqueline.com\",\"city\":\"البحيرة\",\"district\":\"test\",\"street\":\"test\",\"country\":\"EG\"}','{\"full_name\":\"Admin\",\"phone\":\"+201000000001\",\"email\":\"admin@theboutiqueline.com\",\"city\":\"البحيرة\",\"district\":\"test\",\"street\":\"test\",\"country\":\"EG\"}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-07 11:57:12','2026-06-07 11:57:12',NULL),
(2,'MW-1780930432888-f54efe259cd5',NULL,'Ha','karimourad150@gmail.com',NULL,'pending',1887.00,0.00,50.00,290.55,2227.55,'EGP','cod','pending','{\"full_name\":\"Kajdndh\",\"phone\":\"01150005608\",\"email\":\"karimourad150@gmail.com\",\"city\":\"البحيرة\",\"district\":\"Shha\",\"street\":\"Hshsh\",\"country\":\"EG\"}','{\"full_name\":\"Kajdndh\",\"phone\":\"01150005608\",\"email\":\"karimourad150@gmail.com\",\"city\":\"البحيرة\",\"district\":\"Shha\",\"street\":\"Hshsh\",\"country\":\"EG\"}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-08 14:53:52','2026-06-08 14:53:52','{\"session_id\":\"e5710b25-5372-4d8e-a9a9-8a59c47475b5\",\"referrer\":null,\"utm_source\":null,\"utm_medium\":null,\"utm_campaign\":null,\"device_type\":\"mobile\",\"landing_path\":\"/\",\"country\":null,\"channel\":\"direct\",\"channel_label\":\"Direct\",\"social\":null}'),
(3,'MW-1780931330643-2f6d97930608',1,NULL,NULL,NULL,'pending',1680.00,0.00,50.00,259.50,1989.50,'EGP','cod','pending','{\"full_name\":\"Inventore veritatis \",\"phone\":\"Minus facilis culpa \",\"email\":\"dabo@mailinator.com\",\"city\":\"أسيوط\",\"district\":\"Excepturi ea autem l\",\"street\":\"Amet odit commodi h\",\"country\":\"EG\"}','{\"full_name\":\"Inventore veritatis \",\"phone\":\"Minus facilis culpa \",\"email\":\"dabo@mailinator.com\",\"city\":\"أسيوط\",\"district\":\"Excepturi ea autem l\",\"street\":\"Amet odit commodi h\",\"country\":\"EG\"}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-08 15:08:50','2026-06-08 15:08:50','{\"session_id\":\"7b8ab818-7dce-4e10-97f3-5d5ec3e48480\",\"referrer\":\"https://theboutiqueline.com/admin/products\",\"utm_source\":null,\"utm_medium\":null,\"utm_campaign\":null,\"device_type\":\"desktop\",\"landing_path\":\"/\",\"country\":null,\"channel\":\"referral\",\"channel_label\":\"theboutiqueline.com\",\"social\":null}'),
(4,'MW-1780931442465-979bc06ede19',1,NULL,NULL,NULL,'pending',1680.00,0.00,50.00,259.50,1989.50,'EGP','cod','pending','{\"full_name\":\"Error natus consequa\",\"phone\":\"Quia eos facere aut\",\"email\":\"kucaxek@mailinator.com\",\"city\":\"الدقهلية\",\"district\":\"Ullam eiusmod molest\",\"street\":\"Atque aliquip nulla \",\"country\":\"EG\"}','{\"full_name\":\"Error natus consequa\",\"phone\":\"Quia eos facere aut\",\"email\":\"kucaxek@mailinator.com\",\"city\":\"الدقهلية\",\"district\":\"Ullam eiusmod molest\",\"street\":\"Atque aliquip nulla \",\"country\":\"EG\"}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-08 15:10:42','2026-06-08 15:10:42','{\"session_id\":\"7b8ab818-7dce-4e10-97f3-5d5ec3e48480\",\"referrer\":\"https://theboutiqueline.com/admin/products\",\"utm_source\":null,\"utm_medium\":null,\"utm_campaign\":null,\"device_type\":\"desktop\",\"landing_path\":\"/\",\"country\":null,\"channel\":\"referral\",\"channel_label\":\"theboutiqueline.com\",\"social\":null}'),
(5,'MW-1780963488499-90a2e60984a3',7,NULL,NULL,NULL,'delivered',800.00,0.00,50.00,127.50,977.50,'EGP','cod','pending','{\"full_name\":\"Mohamed atef\",\"phone\":\"01123360043\",\"email\":\"mohamedatef5115@gmail.com\",\"city\":\"القاهرة\",\"district\":\"\",\"street\":\"\",\"country\":\"EG\"}','{\"full_name\":\"Mohamed atef\",\"phone\":\"01123360043\",\"email\":\"mohamedatef5115@gmail.com\",\"city\":\"القاهرة\",\"district\":\"\",\"street\":\"\",\"country\":\"EG\"}',NULL,NULL,'2026-06-09 00:30:17','2026-06-09 00:39:50','2026-06-09 00:39:24',NULL,'2026-06-09 00:04:48','2026-06-09 00:39:50','{\"session_id\":\"0be87f4c-9850-4bc8-82fd-22e503253dfb\",\"referrer\":null,\"utm_source\":\"ig\",\"utm_medium\":\"social\",\"utm_campaign\":null,\"device_type\":\"mobile\",\"landing_path\":\"/products/hyh-1780933430759\",\"country\":\"EG\",\"channel\":\"campaign\",\"channel_label\":\"ig\",\"social\":null}'),
(6,'MW-1781001420956-9e56cd83c759',7,NULL,NULL,NULL,'processing',400.00,0.00,50.00,67.50,517.50,'EGP','cod','pending','{\"full_name\":\"Mohamed atef\",\"phone\":\"01123360043\",\"email\":\"mohamedatef5115@gmail.com\",\"city\":\"الدقهلية\",\"district\":\"\",\"street\":\"\",\"country\":\"EG\"}','{\"full_name\":\"Mohamed atef\",\"phone\":\"01123360043\",\"email\":\"mohamedatef5115@gmail.com\",\"city\":\"الدقهلية\",\"district\":\"\",\"street\":\"\",\"country\":\"EG\"}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-09 10:37:00','2026-06-09 21:43:16','{\"session_id\":\"0be87f4c-9850-4bc8-82fd-22e503253dfb\",\"referrer\":null,\"utm_source\":\"ig\",\"utm_medium\":\"social\",\"utm_campaign\":null,\"device_type\":\"mobile\",\"landing_path\":\"/products/hyh-1780933430759\",\"country\":\"EG\",\"channel\":\"campaign\",\"channel_label\":\"ig\",\"social\":null}'),
(7,'MW-1781041048219-d1d173b198fe',NULL,'Mohamed Hammouda','mohamed.hamouda5115@gmil.com',NULL,'pending',400.00,0.00,50.00,67.50,517.50,'EGP','cod','pending','{\"full_name\":\"Ghh\",\"phone\":\"01011206497\",\"email\":\"mohamed.hamouda5115@gmil.com\",\"city\":\"أسوان\",\"district\":\"Fggv\",\"street\":\"Fggvh\",\"country\":\"EG\"}','{\"full_name\":\"Ghh\",\"phone\":\"01011206497\",\"email\":\"mohamed.hamouda5115@gmil.com\",\"city\":\"أسوان\",\"district\":\"Fggv\",\"street\":\"Fggvh\",\"country\":\"EG\"}',NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-09 21:37:28','2026-06-09 21:37:28','{\"session_id\":\"68b2c010-c63d-459a-b73e-1af25b83830c\",\"referrer\":\"https://www.google.com/\",\"utm_source\":null,\"utm_medium\":null,\"utm_campaign\":null,\"device_type\":\"desktop\",\"landing_path\":\"/\",\"country\":\"EG\",\"channel\":\"organic\",\"channel_label\":\"google\",\"social\":null}'),
(8,'MW-1781051249332-8a18fe85f987',NULL,'Mohamed Hammouda','mohamedhamouda5115@gmail.com',NULL,'shipped',1244.00,0.00,120.00,0.00,1364.00,'EGP','cod','pending','{\"full_name\":\"Mohamed Hammouda\",\"phone\":\"010102828828\",\"email\":\"mohamedhamouda5115@gmail.com\",\"city\":\"القليوبية\",\"district\":\"Hshehahs\",\"street\":\"Hshhhss\",\"country\":\"EG\"}','{\"full_name\":\"Mohamed Hammouda\",\"phone\":\"010102828828\",\"email\":\"mohamedhamouda5115@gmail.com\",\"city\":\"القليوبية\",\"district\":\"Hshehahs\",\"street\":\"Hshhhss\",\"country\":\"EG\"}',NULL,NULL,'2026-06-10 00:29:00',NULL,NULL,NULL,'2026-06-10 00:27:29','2026-06-10 00:29:00','{\"session_id\":\"7384018e-2e78-40e4-8624-2f3d23544628\",\"referrer\":null,\"utm_source\":null,\"utm_medium\":null,\"utm_campaign\":null,\"device_type\":\"mobile\",\"landing_path\":\"/\",\"country\":\"EG\",\"channel\":\"direct\",\"channel_label\":\"Direct\",\"social\":null}');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `method` enum('stripe','cod','bank_transfer','paymob') NOT NULL,
  `status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(5) DEFAULT 'EGP',
  `stripe_payment_intent_id` varchar(200) DEFAULT NULL,
  `stripe_charge_id` varchar(200) DEFAULT NULL,
  `bank_transfer_reference` varchar(200) DEFAULT NULL,
  `bank_transfer_proof` varchar(500) DEFAULT NULL,
  `transaction_id` varchar(200) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES
(1,1,'cod','pending',1989.50,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-07 11:57:12','2026-06-07 11:57:12'),
(2,2,'cod','pending',2227.55,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-08 14:53:52','2026-06-08 14:53:52'),
(3,3,'cod','pending',1989.50,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-08 15:08:50','2026-06-08 15:08:50'),
(4,4,'cod','pending',1989.50,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-08 15:10:42','2026-06-08 15:10:42'),
(5,5,'cod','pending',977.50,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-09 00:04:48','2026-06-09 00:04:48'),
(6,6,'cod','pending',517.50,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-09 10:37:00','2026-06-09 10:37:00'),
(7,7,'cod','pending',517.50,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-09 21:37:28','2026-06-09 21:37:28'),
(8,8,'cod','pending',1364.00,'EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-10 00:27:29','2026-06-10 00:27:29');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `url` varchar(500) NOT NULL,
  `public_id` varchar(300) DEFAULT NULL,
  `alt_ar` varchar(200) DEFAULT NULL,
  `alt_en` varchar(200) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
INSERT INTO `product_images` VALUES
(43,32,'/api/uploads/1781052192888-384982166.JPG','1781052192888-384982166.JPG',NULL,NULL,0,1,'2026-06-10 00:43:12','2026-06-10 00:43:12'),
(44,32,'/api/uploads/1781052192907-3588558.JPG','1781052192907-3588558.JPG',NULL,NULL,3,0,'2026-06-10 00:43:12','2026-06-10 00:43:12'),
(45,32,'/api/uploads/1781052192896-813509630.JPG','1781052192896-813509630.JPG',NULL,NULL,2,0,'2026-06-10 00:43:12','2026-06-10 00:43:12'),
(46,32,'/api/uploads/1781052192893-819676824.JPG','1781052192893-819676824.JPG',NULL,NULL,1,0,'2026-06-10 00:43:12','2026-06-10 00:43:12'),
(47,32,'/api/uploads/1781052192909-733935048.PNG','1781052192909-733935048.PNG',NULL,NULL,4,0,'2026-06-10 00:43:12','2026-06-10 00:43:12'),
(48,33,'/api/uploads/1781052738659-411934763.webp','1781052738659-411934763.webp',NULL,NULL,0,1,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(49,33,'/api/uploads/1781052738660-156723791.webp','1781052738660-156723791.webp',NULL,NULL,1,0,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(50,33,'/api/uploads/1781052738661-666974654.webp','1781052738661-666974654.webp',NULL,NULL,2,0,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(51,33,'/api/uploads/1781052738661-158897121.webp','1781052738661-158897121.webp',NULL,NULL,3,0,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(52,34,'/api/uploads/1781053303628-911343392.webp','1781053303628-911343392.webp',NULL,NULL,0,1,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(53,34,'/api/uploads/1781053303628-651396735.webp','1781053303628-651396735.webp',NULL,NULL,1,0,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(54,34,'/api/uploads/1781053303633-81106097.webp','1781053303633-81106097.webp',NULL,NULL,3,0,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(55,34,'/api/uploads/1781053303631-861742088.webp','1781053303631-861742088.webp',NULL,NULL,2,0,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(56,35,'/api/uploads/1781053774403-944972705.webp','1781053774403-944972705.webp',NULL,NULL,0,1,'2026-06-10 01:09:34','2026-06-10 01:09:34'),
(57,35,'/api/uploads/1781053774404-402876240.jpeg','1781053774404-402876240.jpeg',NULL,NULL,1,0,'2026-06-10 01:09:34','2026-06-10 01:09:34'),
(58,35,'/api/uploads/1781053774408-321575137.jpeg','1781053774408-321575137.jpeg',NULL,NULL,2,0,'2026-06-10 01:09:34','2026-06-10 01:09:34'),
(59,36,'/api/uploads/1781054221974-394472673.webp','1781054221974-394472673.webp',NULL,NULL,0,1,'2026-06-10 01:17:01','2026-06-10 01:17:01'),
(60,36,'/api/uploads/1781054221980-214197407.webp','1781054221980-214197407.webp',NULL,NULL,2,0,'2026-06-10 01:17:01','2026-06-10 01:17:01'),
(61,36,'/api/uploads/1781054221978-278989340.webp','1781054221978-278989340.webp',NULL,NULL,1,0,'2026-06-10 01:17:01','2026-06-10 01:17:01'),
(62,36,'/api/uploads/1781054221983-674832924.webp','1781054221983-674832924.webp',NULL,NULL,3,0,'2026-06-10 01:17:01','2026-06-10 01:17:01'),
(63,37,'/api/uploads/1781054951407-451740093.avif','1781054951407-451740093.avif',NULL,NULL,0,1,'2026-06-10 01:29:11','2026-06-10 01:29:11'),
(64,37,'/api/uploads/1781054951409-535256286.avif','1781054951409-535256286.avif',NULL,NULL,1,0,'2026-06-10 01:29:11','2026-06-10 01:29:11'),
(65,37,'/api/uploads/1781054951421-737151422.webp','1781054951421-737151422.webp',NULL,NULL,3,0,'2026-06-10 01:29:11','2026-06-10 01:29:11'),
(66,37,'/api/uploads/1781054951412-396620109.jpg','1781054951412-396620109.jpg',NULL,NULL,2,0,'2026-06-10 01:29:11','2026-06-10 01:29:11'),
(70,38,'/api/uploads/1781055856405-259853696.jpg','1781055856405-259853696.jpg',NULL,NULL,0,1,'2026-06-10 01:44:16','2026-06-10 01:44:16'),
(71,38,'/api/uploads/1781055856410-372956017.webp','1781055856410-372956017.webp',NULL,NULL,1,0,'2026-06-10 01:44:16','2026-06-10 01:44:16'),
(72,38,'/api/uploads/1781055856413-136325443.webp','1781055856413-136325443.webp',NULL,NULL,2,0,'2026-06-10 01:44:16','2026-06-10 01:44:16'),
(73,39,'/api/uploads/1781056505281-977553402.webp','1781056505281-977553402.webp',NULL,NULL,0,1,'2026-06-10 01:55:05','2026-06-10 01:55:05'),
(74,39,'/api/uploads/1781056505281-105320860.WEBP','1781056505281-105320860.WEBP',NULL,NULL,1,0,'2026-06-10 01:55:05','2026-06-10 01:55:05'),
(76,39,'/api/uploads/1781056505284-896475847.WEBP','1781056505284-896475847.WEBP',NULL,NULL,3,0,'2026-06-10 01:55:05','2026-06-10 01:55:05'),
(81,40,'/api/uploads/1781057038800-332298737.jpg','1781057038800-332298737.jpg',NULL,NULL,0,1,'2026-06-10 02:03:58','2026-06-10 02:03:58'),
(82,40,'/api/uploads/1781057038806-400146635.jpg','1781057038806-400146635.jpg',NULL,NULL,1,0,'2026-06-10 02:03:58','2026-06-10 02:03:58'),
(83,40,'/api/uploads/1781057038817-600442894.webp','1781057038817-600442894.webp',NULL,NULL,3,0,'2026-06-10 02:03:58','2026-06-10 02:03:58'),
(84,40,'/api/uploads/1781057038815-936378105.webp','1781057038815-936378105.webp',NULL,NULL,2,0,'2026-06-10 02:03:58','2026-06-10 02:03:58'),
(85,41,'/api/uploads/1781057717912-177546252.JPG','1781057717912-177546252.JPG',NULL,NULL,0,1,'2026-06-10 02:15:17','2026-06-10 02:15:17'),
(86,41,'/api/uploads/1781057717914-190826932.WEBP','1781057717914-190826932.WEBP',NULL,NULL,3,0,'2026-06-10 02:15:17','2026-06-10 02:15:17'),
(87,41,'/api/uploads/1781057717912-53699413.WEBP','1781057717912-53699413.WEBP',NULL,NULL,1,0,'2026-06-10 02:15:17','2026-06-10 02:15:17'),
(88,41,'/api/uploads/1781057717914-431290425.WEBP','1781057717914-431290425.WEBP',NULL,NULL,2,0,'2026-06-10 02:15:17','2026-06-10 02:15:17'),
(89,42,'/api/uploads/1781059099146-756216541.JPG','1781059099146-756216541.JPG',NULL,NULL,0,1,'2026-06-10 02:38:19','2026-06-10 02:38:19'),
(90,42,'/api/uploads/1781059099147-79689176.JPG','1781059099147-79689176.JPG',NULL,NULL,1,0,'2026-06-10 02:38:19','2026-06-10 02:38:19'),
(96,46,'/api/uploads/1781060765864-207863003.webp','1781060765864-207863003.webp',NULL,NULL,0,1,'2026-06-10 03:06:05','2026-06-10 03:06:05'),
(97,46,'/api/uploads/1781060765868-866261222.avif','1781060765868-866261222.avif',NULL,NULL,1,0,'2026-06-10 03:06:05','2026-06-10 03:06:05'),
(98,46,'/api/uploads/1781060765870-238960604.avif','1781060765870-238960604.avif',NULL,NULL,2,0,'2026-06-10 03:06:05','2026-06-10 03:06:05'),
(99,47,'/api/uploads/1781061637717-681005346.WEBP','1781061637717-681005346.WEBP',NULL,NULL,0,1,'2026-06-10 03:20:37','2026-06-10 03:20:37'),
(100,47,'/api/uploads/1781061637718-580970756.WEBP','1781061637718-580970756.WEBP',NULL,NULL,1,0,'2026-06-10 03:20:37','2026-06-10 03:20:37'),
(101,47,'/api/uploads/1781061637719-257913646.jpg','1781061637719-257913646.jpg',NULL,NULL,2,0,'2026-06-10 03:20:37','2026-06-10 03:20:37'),
(102,47,'/api/uploads/1781061637721-190014469.WEBP','1781061637721-190014469.WEBP',NULL,NULL,3,0,'2026-06-10 03:20:37','2026-06-10 03:20:37'),
(107,48,'/api/uploads/1781062459435-364267795.jpg','1781062459435-364267795.jpg',NULL,NULL,0,1,'2026-06-10 03:34:19','2026-06-10 03:34:19'),
(108,48,'/api/uploads/1781062459439-460234261.JPG','1781062459439-460234261.JPG',NULL,NULL,1,0,'2026-06-10 03:34:19','2026-06-10 03:34:19'),
(109,48,'/api/uploads/1781062459440-68019298.AVIF','1781062459440-68019298.AVIF',NULL,NULL,2,0,'2026-06-10 03:34:19','2026-06-10 03:34:19'),
(110,48,'/api/uploads/1781062459442-145839722.JPG','1781062459442-145839722.JPG',NULL,NULL,3,0,'2026-06-10 03:34:19','2026-06-10 03:34:19'),
(111,48,'/api/uploads/1781062459443-360224534.JPG','1781062459443-360224534.JPG',NULL,NULL,4,0,'2026-06-10 03:34:19','2026-06-10 03:34:19'),
(112,49,'/api/uploads/1781063012145-666518028.avif','1781063012145-666518028.avif',NULL,NULL,0,1,'2026-06-10 03:43:32','2026-06-10 03:43:32'),
(113,49,'/api/uploads/1781063012151-296847797.avif','1781063012151-296847797.avif',NULL,NULL,3,0,'2026-06-10 03:43:32','2026-06-10 03:43:32'),
(114,49,'/api/uploads/1781063012148-548035640.jpg','1781063012148-548035640.jpg',NULL,NULL,1,0,'2026-06-10 03:43:32','2026-06-10 03:43:32'),
(115,49,'/api/uploads/1781063012149-38919948.avif','1781063012149-38919948.avif',NULL,NULL,2,0,'2026-06-10 03:43:32','2026-06-10 03:43:32'),
(116,49,'/api/uploads/1781063012152-673031322.avif','1781063012152-673031322.avif',NULL,NULL,4,0,'2026-06-10 03:43:32','2026-06-10 03:43:32'),
(118,50,'/api/uploads/1781063691136-41500099.jpg','1781063691136-41500099.jpg',NULL,NULL,1,0,'2026-06-10 03:54:51','2026-06-10 03:54:51'),
(119,50,'/api/uploads/1781063691143-370403526.jpg','1781063691143-370403526.jpg',NULL,NULL,2,0,'2026-06-10 03:54:51','2026-06-10 03:54:51'),
(121,50,'/api/uploads/1781063722310-497133736.jpg','1781063722310-497133736.jpg',NULL,NULL,2,0,'2026-06-10 03:55:22','2026-06-10 03:55:22'),
(122,50,'/api/uploads/1781063722316-318317810.webp','1781063722316-318317810.webp',NULL,NULL,3,0,'2026-06-10 03:55:22','2026-06-10 03:55:22');
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_variants`
--

DROP TABLE IF EXISTS `product_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_variants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `color_hex` varchar(10) DEFAULT NULL,
  `price_adjustment` decimal(10,2) DEFAULT 0.00,
  `stock` int(11) DEFAULT 0,
  `image` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_variants_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_variants`
--

LOCK TABLES `product_variants` WRITE;
/*!40000 ALTER TABLE `product_variants` DISABLE KEYS */;
INSERT INTO `product_variants` VALUES
(58,33,'MW-1781052738383-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(59,33,'MW-1781052738383-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(60,33,'MW-1781052738383-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(61,33,'MW-1781052738383-XXL','XXL',NULL,NULL,0.00,1,NULL,'2026-06-10 00:52:18','2026-06-10 00:52:18'),
(62,34,'MW-1781053303270-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(63,34,'MW-1781053303270-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(64,34,'MW-1781053303270-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(65,34,'MW-1781053303270-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 01:01:43','2026-06-10 01:01:43'),
(66,35,'MW-1781053773874-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 01:09:33','2026-06-10 01:09:33'),
(67,35,'MW-1781053773874-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 01:09:33','2026-06-10 01:09:33'),
(68,35,'MW-1781053773874-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 01:09:33','2026-06-10 01:09:33'),
(69,35,'MW-1781053773874-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 01:09:33','2026-06-10 01:09:33'),
(98,40,'MW-1781056939762-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 02:03:57','2026-06-10 02:03:57'),
(99,40,'MW-1781056939762-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 02:03:57','2026-06-10 02:03:57'),
(100,40,'MW-1781056939762-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 02:03:57','2026-06-10 02:03:57'),
(101,40,'MW-1781056939762-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 02:03:57','2026-06-10 02:03:57'),
(110,42,'MW-1781059098580-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 02:39:13','2026-06-10 02:39:13'),
(111,42,'MW-1781059098580-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 02:39:13','2026-06-10 02:39:13'),
(112,42,'MW-1781059098580-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 02:39:13','2026-06-10 02:39:13'),
(113,42,'MW-1781059098580-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 02:39:13','2026-06-10 02:39:13'),
(150,39,'MW-1781056504674-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:08','2026-06-10 03:07:08'),
(151,39,'MW-1781056504674-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:08','2026-06-10 03:07:08'),
(152,39,'MW-1781056504674-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:08','2026-06-10 03:07:08'),
(153,39,'MW-1781056504674-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:08','2026-06-10 03:07:08'),
(166,37,'MW-1781054949518-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:47','2026-06-10 03:07:47'),
(167,37,'MW-1781054949518-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:47','2026-06-10 03:07:47'),
(168,37,'MW-1781054949518-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:47','2026-06-10 03:07:47'),
(169,37,'MW-1781054949518-XXL','XXL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:47','2026-06-10 03:07:47'),
(170,38,'MW-1781055706642-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:59','2026-06-10 03:07:59'),
(171,38,'MW-1781055706642-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:59','2026-06-10 03:07:59'),
(172,38,'MW-1781055706642-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:59','2026-06-10 03:07:59'),
(173,38,'MW-1781055706642-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 03:07:59','2026-06-10 03:07:59'),
(174,36,'MW-1781054221240-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:08:20','2026-06-10 03:08:20'),
(175,36,'MW-1781054221240-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:08:20','2026-06-10 03:08:20'),
(176,36,'MW-1781054221240-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:08:20','2026-06-10 03:08:20'),
(177,36,'MW-1781054221240-XXL','XXL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:08:20','2026-06-10 03:08:20'),
(186,32,'MW-1781052190199-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:16','2026-06-10 03:24:16'),
(187,32,'MW-1781052190199-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:16','2026-06-10 03:24:16'),
(188,32,'MW-1781052190199-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:16','2026-06-10 03:24:16'),
(189,32,'MW-1781052190199-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:16','2026-06-10 03:24:16'),
(190,41,'MW-1781057716343-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:54','2026-06-10 03:24:54'),
(191,41,'MW-1781057716343-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:54','2026-06-10 03:24:54'),
(192,41,'MW-1781057716343-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:54','2026-06-10 03:24:54'),
(193,41,'MW-1781057716343-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:24:54','2026-06-10 03:24:54'),
(194,47,'MW-1781061637032-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:02','2026-06-10 03:25:02'),
(195,47,'MW-1781061637032-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:02','2026-06-10 03:25:02'),
(196,47,'MW-1781061637032-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:02','2026-06-10 03:25:02'),
(197,47,'MW-1781061637032-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:02','2026-06-10 03:25:02'),
(198,46,'MW-1781059851988-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:09','2026-06-10 03:25:09'),
(199,46,'MW-1781059851988-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:09','2026-06-10 03:25:09'),
(200,46,'MW-1781059851988-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:09','2026-06-10 03:25:09'),
(201,46,'MW-1781059851988-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:25:09','2026-06-10 03:25:09'),
(205,48,'MW-1781062377828-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:34:18','2026-06-10 03:34:18'),
(206,48,'MW-1781062377828-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:34:18','2026-06-10 03:34:18'),
(207,48,'MW-1781062377828-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:34:18','2026-06-10 03:34:18'),
(212,49,'MW-1781063011206-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:44:40','2026-06-10 03:44:40'),
(213,49,'MW-1781063011206-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:44:40','2026-06-10 03:44:40'),
(214,49,'MW-1781063011206-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:44:40','2026-06-10 03:44:40'),
(215,49,'MW-1781063011206-XXL','XXL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:44:40','2026-06-10 03:44:40'),
(220,50,'MW-1781063687014-S','S',NULL,NULL,0.00,1,NULL,'2026-06-10 03:55:19','2026-06-10 03:55:19'),
(221,50,'MW-1781063687014-M','M',NULL,NULL,0.00,1,NULL,'2026-06-10 03:55:19','2026-06-10 03:55:19'),
(222,50,'MW-1781063687014-L','L',NULL,NULL,0.00,1,NULL,'2026-06-10 03:55:19','2026-06-10 03:55:19'),
(223,50,'MW-1781063687014-XL','XL',NULL,NULL,0.00,1,NULL,'2026-06-10 03:55:19','2026-06-10 03:55:19');
/*!40000 ALTER TABLE `product_variants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `name_ar` varchar(200) NOT NULL,
  `name_en` varchar(200) NOT NULL,
  `slug` varchar(250) DEFAULT NULL,
  `description_ar` text DEFAULT NULL,
  `description_en` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT 0,
  `low_stock_threshold` int(11) DEFAULT 5,
  `weight` decimal(8,2) DEFAULT NULL,
  `thumbnail` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_new_arrival` tinyint(1) DEFAULT 0,
  `is_best_seller` tinyint(1) DEFAULT 0,
  `is_on_sale` tinyint(1) DEFAULT 0,
  `sizes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sizes`)),
  `colors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`colors`)),
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `rating_avg` decimal(3,2) DEFAULT 0.00,
  `rating_count` int(11) DEFAULT 0,
  `views` int(11) DEFAULT 0,
  `sales_count` int(11) DEFAULT 0,
  `meta_title_ar` varchar(200) DEFAULT NULL,
  `meta_title_en` varchar(200) DEFAULT NULL,
  `meta_description_ar` text DEFAULT NULL,
  `meta_description_en` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_hero_ticker` tinyint(1) NOT NULL DEFAULT 0,
  `hero_ticker_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `sku_2` (`sku`),
  UNIQUE KEY `slug_2` (`slug`),
  UNIQUE KEY `sku_3` (`sku`),
  UNIQUE KEY `slug_3` (`slug`),
  UNIQUE KEY `sku_4` (`sku`),
  UNIQUE KEY `slug_4` (`slug`),
  UNIQUE KEY `sku_5` (`sku`),
  UNIQUE KEY `slug_5` (`slug`),
  UNIQUE KEY `sku_6` (`sku`),
  UNIQUE KEY `slug_6` (`slug`),
  UNIQUE KEY `sku_7` (`sku`),
  UNIQUE KEY `slug_7` (`slug`),
  UNIQUE KEY `sku_8` (`sku`),
  UNIQUE KEY `slug_8` (`slug`),
  UNIQUE KEY `sku_9` (`sku`),
  UNIQUE KEY `slug_9` (`slug`),
  UNIQUE KEY `sku_10` (`sku`),
  UNIQUE KEY `slug_10` (`slug`),
  UNIQUE KEY `sku_11` (`sku`),
  UNIQUE KEY `slug_11` (`slug`),
  UNIQUE KEY `sku_12` (`sku`),
  UNIQUE KEY `slug_12` (`slug`),
  UNIQUE KEY `sku_13` (`sku`),
  UNIQUE KEY `slug_13` (`slug`),
  UNIQUE KEY `sku_14` (`sku`),
  UNIQUE KEY `slug_14` (`slug`),
  UNIQUE KEY `sku_15` (`sku`),
  UNIQUE KEY `slug_15` (`slug`),
  UNIQUE KEY `sku_16` (`sku`),
  UNIQUE KEY `slug_16` (`slug`),
  UNIQUE KEY `sku_17` (`sku`),
  UNIQUE KEY `slug_17` (`slug`),
  UNIQUE KEY `sku_18` (`sku`),
  UNIQUE KEY `slug_18` (`slug`),
  UNIQUE KEY `sku_19` (`sku`),
  UNIQUE KEY `slug_19` (`slug`),
  UNIQUE KEY `sku_20` (`sku`),
  UNIQUE KEY `slug_20` (`slug`),
  UNIQUE KEY `sku_21` (`sku`),
  UNIQUE KEY `slug_21` (`slug`),
  UNIQUE KEY `sku_22` (`sku`),
  UNIQUE KEY `slug_22` (`slug`),
  UNIQUE KEY `sku_23` (`sku`),
  UNIQUE KEY `slug_23` (`slug`),
  UNIQUE KEY `sku_24` (`sku`),
  UNIQUE KEY `slug_24` (`slug`),
  UNIQUE KEY `sku_25` (`sku`),
  UNIQUE KEY `slug_25` (`slug`),
  UNIQUE KEY `sku_26` (`sku`),
  UNIQUE KEY `slug_26` (`slug`),
  UNIQUE KEY `sku_27` (`sku`),
  UNIQUE KEY `slug_27` (`slug`),
  UNIQUE KEY `sku_28` (`sku`),
  UNIQUE KEY `slug_28` (`slug`),
  UNIQUE KEY `sku_29` (`sku`),
  UNIQUE KEY `slug_29` (`slug`),
  UNIQUE KEY `sku_30` (`sku`),
  UNIQUE KEY `slug_30` (`slug`),
  UNIQUE KEY `sku_31` (`sku`),
  KEY `category_id` (`category_id`),
  KEY `subcategory_id` (`subcategory_id`),
  CONSTRAINT `products_ibfk_61` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `products_ibfk_62` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(32,2,NULL,'MW-1781052190199',' لويس فويتون قصيرة الأكمام برقبة دائرية مصنوعة من القطن والكشمير','LOUIS VUITTON Cotton-Cashmere Short-Sleeved Crewneck','louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199','هذا التيشيرت ذو الأكمام القصيرة والياقة المستديرة مصنوع من مزيج قطن وكشمير عضوي ناعم الملمس على البشرة. يتميز بتصميم أنيق مع حياكة بوانتيل خفيفة على الأكمام والظهر، مما يجعله مثاليًا لأيام الصيف الدافئة. يضفي شعار لويس فويتون بنقشة بوانتيل على الصدر لمسة نهائية راقية على هذا التصميم العملي متعدد الاستخدامات.\n\nقصة عادية\nلون كحلي داكن\n85% قطن، 15% كشمير\nياقة مضلعة\nأكمام وظهر بنقشة بوانتيل\nشعار بوانتيل على الصدر\nصنع في إيطاليا','This short-sleeved crewneck is crafted from an organic cotton-cashmere blend that is soft against the skin. It is elevated with a breezy pointelle knit on the sleeves and back, making it perfect for warm summer days. Pointelle Louis Vuitton lettering across the chest adds a sophisticated finishing touch to this versatile casual style.\n\n\nRegular fit\nDeep Navy\n85% Cotton, 15% Cashmere\nRibbed Collar\nPointelle sleeves and back\nPointelle signature on chest\nMade in Italy',2800.00,NULL,NULL,4,5,NULL,'/api/uploads/1781052192888-384982166.JPG',1,0,1,1,0,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,13,0,'','','','','2026-06-10 00:43:10','2026-06-10 03:24:16',0,NULL),
(33,2,NULL,'MW-1781052738383','تيشيرت جيرسي برقبة دائرية وشورت','JERSEY CREWNECK T-SHIRT And Short ','jersey-crewneck-t-shirt-and-short-1781052738383','تيشيرت فير أوف غود إسينشالز\nتيشيرت قطني بياقة دائرية\nمصنوع من قطن جيرسي ثقيل الوزن (220 غرام/متر مربع)\nقصة مريحة\nياقة دائرية مضلعة\nأكمام قصيرة\nشعار \"إسينشالز فير أوف غود\" ناعم الملمس على الصدر والظهر\nملصق شعار مطاطي\nاللون: أسود\nالخامة: 100% قطن\nشاهد المزيد من التيشيرتات والملابس ذات الأكمام القصيرة\nيرتدي العارض مقاس M\nأبعاد العارض: الطول 189 سم، محيط الصدر 80 سم، محيط الخصر 69 سم، محيط الورك 87 سم','\nFear of God Essentials\nJersey Crewneck T-shirt\nMade of 220gsm heavyweight cotton jersey\nRelaxed fit\nRibbed crewneck\nShort sleeve\n\"Essentials Fear of God\" soft-touch logo on chest and back\nRubberized logo label\nColor: Black\nMaterial: 100% Cotton\nSee more SS T-Shirts, T-Shirts and Clothing\nModel wears size M\nModel measures: Height 189cm, Chest 31.5\"/80cm, Waist 27”/69cm, Hip 34.3’’/87cm',3500.00,NULL,NULL,4,5,NULL,'/api/uploads/1781052738659-411934763.webp',1,0,1,0,0,'[\"M\",\"L\",\"XL\",\"XXL\"]','[]','[]',0.00,0,6,0,'','','','','2026-06-10 00:52:18','2026-06-10 00:57:37',0,NULL),
(34,2,NULL,'MW-1781053303270','تيشيرت أوف وايت أروز','OFF-WHITE Arrows T-shirt','off-white-arrows-t-shirt-1781053303270','تيشيرت \"أروز\" من أوف-وايت مصنوع من القطن الخالص، ويتميز بطبعة \"الأروز\" المميزة للعلامة التجارية على الظهر، وهي رمز لا يُخطئه أحد لهويتها. بتصميم كلاسيكي بياقة دائرية وأكمام قصيرة وقصة بسيطة، يجمع هذا التيشيرت بين الراحة والأناقة العصرية.\n\nالموسم: خريف/شتاء 2025\nالمقاس: عادي\nالخامة: قطن 100%\nصُنع في البرتغال','The Arrows T-shirt by Off-White is crafted from pure cotton and features the brand’s signature Arrows print on the back, an unmistakable icon of its identity. With a classic crew neck, short sleeves, and a minimalist cut, it offers both comfort and contemporary streetwear appeal.\n\nSeason: AW25\nFit: Regular\nComposition: GENERAL 100% Cotton\nMADE IN PORTUGAL',2900.00,NULL,NULL,4,5,NULL,'/api/uploads/1781053303628-911343392.webp',1,0,1,0,0,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,2,0,'','','','','2026-06-10 01:01:43','2026-06-10 03:11:08',0,NULL),
(35,2,NULL,'MW-1781053773874','تيشيرت أميري إم إيه هوليوود أسود','Amiri MA Hollywood Tee Black','amiri-ma-hollywood-tee-black-1781053773874','تيشيرت Amiri MA Hollywood الأسود قطعة أساسية فاخرة في عالم أزياء الشارع، تجمع بين الحرفية العالية والتصميم العصري. يتميز هذا التيشيرت برسومات MA Hollywood الشهيرة، ويعكس جمالية Amiri المميزة مع اهتمام دقيق بأدق التفاصيل. مصنوع من قطن عالي الجودة، يوفر راحة فائقة ومتانة عالية للارتداء اليومي أو لإطلالات كاجوال أنيقة. يضمن اللون الأسود الكلاسيكي سهولة تنسيقه مع أي خزانة ملابس. مثالي لمن يقدرون أزياء الشارع الراقية التي تعكس شخصيتهم.','The Amiri MA Hollywood Tee in Black is a premium streetwear essential that combines luxury craftsmanship with contemporary style. Featuring the iconic MA Hollywood graphic, this tee showcases Amiri\'s signature aesthetic with meticulous attention to detail. Crafted from high-quality cotton, it delivers superior comfort and durability for everyday wear or elevated casual looks. The classic black colorway ensures versatility, pairing effortlessly with any wardrobe. Perfect for those who appreciate refined streetwear that makes a statement.',3200.00,NULL,NULL,4,5,NULL,'/api/uploads/1781053774403-944972705.webp',1,0,1,0,0,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,0,0,'','','','','2026-06-10 01:09:33','2026-06-10 01:09:34',0,NULL),
(36,2,NULL,'MW-1781054221240','قميص بولو من غوتشي مصنوع من القطن المحبوك','Gucci Cotton Knit Polo Shirt','gucci-cotton-knit-polo-shirt-1781054221240','• ننصح بشراء مقاسك المعتاد - هذا التصميم مطابق للمقاسات المعتادة\n• مصمم بقصة عادية\n• قماش متوسط ​​الوزن، مطاطي\n• طول العارض 189 سم/ 6\'2\" ويرتدي مقاسًا معينًا\n• اللون: عاجي\n• شعار العلامة التجارية\n• إغلاق بأزرار\n• قطن\n• يُغسل في الغسالة','• We recommend purchasing your normal size - this design fits true to size\n• Designed for a regular fit\n• Mid-weight, stretchy fabric\n• Model is 189cm/ 6\'2\" and wears size\n• Colour: Ivory\n• Logo detail\n• Button closure\n• Cotton\n• Machine wash',3900.00,NULL,NULL,4,5,NULL,'/api/uploads/1781054221974-394472673.webp',1,0,1,0,1,'[\"M\",\"L\",\"XL\",\"XXL\"]','[]','[]',0.00,0,2,0,'','','','','2026-06-10 01:17:01','2026-06-10 03:08:20',0,NULL),
(37,2,NULL,'MW-1781054949518','تيشيرت أميري بلاك إم إيه شاتو كبير الحجم','AMIRI Black MA Chateau Oversized T-shirt','amiri-black-ma-chateau-oversized-t-shirt-1781054949518','تيشيرت قطني جيرسي.\n\n• ياقة دائرية محبوكة\n• شعار ونص مطبوعان على الصدر والظهر\n• أكتاف منسدلة\n\nلون المورد: أسود\n• الخامة: ١٠٠٪ قطن. الحواف: ٩٥٪ قطن، ٥٪ إيلاستين.\n\nصنع في إيطاليا.','Cotton jersey T-shirt.\n\n· Rib-knit crewneck\n· Logo and text printed at chest and back\n· Dropped shoulders\n\nSupplier color: Black\nBody: 100% cotton. Trim: 95% cotton, 5% elastane.\nMade in Italy.\n',2800.00,NULL,NULL,4,5,NULL,'/api/uploads/1781054951407-451740093.avif',1,0,1,0,1,'[\"M\",\"L\",\"XL\",\"XXL\"]','[]','[]',0.00,0,0,0,'','','','','2026-06-10 01:29:09','2026-06-10 03:07:47',0,NULL),
(38,2,NULL,'MW-1781055706642','تيشيرت بأكمام قصيرة من ايمي ','AMI Paris Short-Sleeves T-shirt','ami-paris-short-sleeves-t-shirt-1781055706642','تيشيرت \"آمي دو كور\" من قطن جيرسي خفيف.\n\nقصة كلاسيكية\nتطريز \"آمي دو كور\" أسود على الصدر\nتطريز \"آمي\" بنفس اللون أسفل فتحة الرقبة الخلفية\nصُنع في البرتغال (بكل حب)\n\nمقاسه مطابق للمقاسات المعتادة.\n\nطول العارض 184 سم / 6 أقدام، ويرتدي مقاس M.\n\nالخامة الرئيسية: 100% قطن\nالخيوط: 100% قطن\n\nممنوع استخدام الكلور\nيُغسل في الغسالة على درجة حرارة 30 مئوية، دورة غسيل لطيفة\nيُكوى بمكواة باردة\nيُنظف تنظيفًا جافًا لطيفًا\nلا يُجفف في المجفف الآلي\nيُغسل ويُكوى من الداخل إلى الخارج\nيُغسل مع ألوان مشابهة','Ami de Coeur T-shirt in light cotton jersey.\nClassic fit\nBlack Ami de Coeur chest embroidery\nTonal Ami embroidery under back neckline\nMade in Portugal (with love)\n\nFits true to size. Take your normal size.\n\nMan model is 184 cm / 6\"0 and is wearing a size M.\nMain Material : 100% Cotton\nRib : 100% Cotton\n\nChlorine Prohibited\nMachine Wash At 30°C Gentle\nCool Iron\nDry Clean Gentle\nDo Not Tumble Dry\nWash And Iron Inside Out\nWash With Similar Colours',3200.00,NULL,NULL,4,5,NULL,'/api/uploads/1781055856405-259853696.jpg',1,0,1,0,1,'[\"M\",\"L\",\"XL\",\"S\"]','[]','[]',0.00,0,3,0,'','','','','2026-06-10 01:41:46','2026-06-10 03:46:09',0,NULL),
(39,2,NULL,'MW-1781056504674','تيشيرت قصير الأكمام برقبة دائرية مطرز من لويس فويتون','LV Blason Embroidered Short-Sleeved Crewneck','lv-blason-embroidered-short-sleeved-crewneck-1781056504674','يُضفي هذا التيشيرت الأسود ذو الأكمام القصيرة والياقة المستديرة لمسةً أنيقةً مميزةً على إطلالتك. مصنوع من قطن عضوي خفيف الوزن ومحكم الحياكة، ومُزيّن بشعار LV Blason مطرز بالكامل بخيوط سوداء لامعة. يُناسب هذا التصميم العصري والمتعدد الاستخدامات، والذي يُعدّ مثاليًا لفصلي الربيع والخريف، الإطلالات الكاجوال والرسمية على حدٍ سواء.\n\nقطن 100%\nأسود\nقصة عادية\nياقة مضلعة\nشعار مطرز بالكامل\nصُنع في إيطاليا\n\nأسود','This black short-sleeved crewneck brings an elegant signature accent to a look. Crafted in light, close-knit organic cotton, it is adorned with an LV Blason motif, which is embroidered all over in lustrous black yarn. This timeless and versatile mid-season style can complete both casual and more formal ensembles.\n\n100% cotton\nBlack\nRegular fit\nRibbed collar\nEmbroidered signature all over\nMade in Italy\n\nBlack\n',2600.00,NULL,NULL,4,5,NULL,'/api/uploads/1781056505281-977553402.webp',1,0,1,0,1,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,4,0,'','','','','2026-06-10 01:55:04','2026-06-10 03:46:13',0,NULL),
(40,2,NULL,'MW-1781056939762','تيشيرت بأكمام قصيرة من ايمي ','AMI Paris Short-Sleeves T-shirt','ami-paris-short-sleeves-t-shirt-1781056939762','تيشيرت \"آمي دو كور\" من قطن جيرسي خفيف.\n\nقصة كلاسيكية\nتطريز \"آمي دو كور\" أسود على الصدر\nتطريز \"آمي\" بنفس اللون أسفل فتحة الرقبة الخلفية\nصُنع في البرتغال (بكل حب)\n\nمقاسه مطابق للمقاسات المعتادة.\n\nطول العارض 184 سم / 6 أقدام، ويرتدي مقاس M.\n\nالخامة الرئيسية: 100% قطن\nالخيوط: 100% قطن\n\nممنوع استخدام الكلور\nيُغسل في الغسالة على درجة حرارة 30 مئوية، دورة غسيل لطيفة\nيُكوى بمكواة باردة\nيُنظف تنظيفًا جافًا لطيفًا\nلا يُجفف في المجفف الآلي\nيُغسل ويُكوى من الداخل إلى الخارج\nيُغسل مع ألوان مشابهة','Ami de Coeur T-shirt in light cotton jersey.\nClassic fit\nBlack Ami de Coeur chest embroidery\nTonal Ami embroidery under back neckline\nMade in Portugal (with love)\n\nFits true to size. Take your normal size.\n\nMan model is 184 cm / 6\"0 and is wearing a size M.\nMain Material : 100% Cotton\nRib : 100% Cotton\n\nChlorine Prohibited\nMachine Wash At 30°C Gentle\nCool Iron\nDry Clean Gentle\nDo Not Tumble Dry\nWash And Iron Inside Out\nWash With Similar Colours',3200.00,NULL,NULL,4,5,NULL,'/api/uploads/1781057038800-332298737.jpg',1,0,1,0,0,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,3,0,'','','','','2026-06-10 02:02:19','2026-06-10 03:11:03',0,NULL),
(41,2,NULL,'MW-1781057716343','قميص بولو من قماش تيري من غوتشي','Gucci Terry Knit Polo','gucci-terry-knit-polo-1781057716343','مستوحاة من روح الصيف ونوادي الشاطئ على الساحل الإيطالي، تُعدّ هذه القطعة جزءًا من مجموعة غوتشي ليدو. بلونها الأبيض الناصع، تُعيد غوتشي ابتكار شريطها المميز ليُصبح قطعة فريدة من نوعها، وذلك من خلال تصميمات وتقنيات خياطة خاصة تُضفي على قميص البولو هذا المصنوع من مزيج القطن التركي لمسةً أساسيةً تُغنيك عن الملابس الجاهزة.\n\nملمس قطني أبيض ممزوج بمزيج من القطن التركي\nتطريز غوتشي الداخلي\nتفاصيل من شريط غوتشي الأزرق والأخضر\nكشكشة مدببة\nأكمام قصيرة\nمقاس عادي\nصُنع في إيطاليا','Inspired by the summer spirit and the beach clubs on the Italian coast, this piece is part of the Gucci Lido. As white as a fresh fabric, the Web is being rethought as unique details through special constructions and sewing techniques that elevate this cotton-blend Turkish cotton polo shirt to an essential piece without ready-to-wear clothing.\n\n\nMalha in Turkish water with white cotton mixture\nGucci Intársia\nDetail of blue and green Web stripe\nPointed ruff\nshort sleeve\nNormal size\nFeito in Italy',3500.00,NULL,NULL,4,5,NULL,'/api/uploads/1781057717912-177546252.JPG',1,0,1,1,0,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,2,0,'','','','','2026-06-10 02:15:16','2026-06-10 03:24:54',0,NULL),
(42,2,NULL,'MW-1781059098580','قميص بولو رجالي من غوتشي باللون الكحلي','Gucci Men\'s Navy Polo Shirt','gucci-men-s-navy-polo-shirt-1781059098580','يجمع قميص بولو غوتشي GG القطني بسلاسة بين الأناقة الخالدة واللمسة العصرية، ليُضفي مزيجًا ساحرًا من الفخامة الإيطالية والرقيّ العصري. يتميز القميص بتدرجات لونية رائعة من الأزرق والعاجي، مما يعكس سحرًا راقيًا وجودة فائقة. يضفي الجزء الأمامي المُزرّر جزئيًا لمسة أنيقة، ليبرز جمال القطعة دون مبالغة. مصنوع من القطن الخالص بنسبة 100%، يوفر القميص ملمسًا ناعمًا ومريحًا، يدعوك للاستمتاع بكل لحظة ارتدائه.\n\n\nالمواد / الخامة\nقميص بولو غوتشي GG قطني\nتدرجات لونية رائعة من الأزرق والعاجي\nجزء أمامي مُزرّر جزئيًا\n\nمصنوع من القطن الخالص بنسبة 100%\nيجمع بين الفخامة الإيطالية والرقيّ العصري\n\nقماش خفيف الوزن يسمح بمرور الهواء\n\n\nتعليمات العناية الموصى بها\nيُغسل في الغسالة بماء بارد على دورة غسيل لطيفة للحفاظ على اللون وجودة القماش.\n\nاستخدم منظفًا معتدلًا للحفاظ على نعومة القطن.\n\nيُجفف مُسطحًا لتجنب تمدده.\nيكوى على درجة حرارة منخفضة عند الحاجة. تجنب التعرض المباشر لأشعة الشمس لفترات طويلة لمنع بهتان اللون.','The Gucci GG cotton polo top effortlessly combines timeless elegance with a modern twist, exuding that irresistible blend of Italian luxury and casual sophistication. Rendered in a striking blue and ivory palette, the fabric speaks of understated charm and premium quality. The partially buttoned front adds a discreet touch of detail, allowing the piece to shine without shouting. Crafted from 100% cotton, it offers a breathable, gentle touch that feels as good as it looks, inviting you to savor each wear.\n\nMaterials / Fabrication\nGucci GG cotton polo top\nStriking blue and ivory palette\nPartially buttoned front\nCrafted from 100% cotton\nMade with Italian luxury and casual sophistication\nLightweight and breathable fabric\n\nRecommended Care\nMachine wash cold on gentle cycle to preserve color and fabric integrity.\nUse mild detergent to maintain the cotton’s softness.\nLay flat to dry to avoid stretching.\nIron on low heat if necessary.\nAvoid exposure to direct sunlight for extended periods to prevent fading.',4550.00,NULL,NULL,4,5,NULL,'/api/uploads/1781059099146-756216541.JPG',1,0,1,0,0,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,2,0,'','','','','2026-06-10 02:38:18','2026-06-10 03:04:15',0,NULL),
(46,2,NULL,'MW-1781059851988','تيشرت لويس فويتون قصير الأكمام برقبة دائرية من قماش الجاكار','LOUIS VUITTON Short-Sleeved Jacquard Crewneck','s-1781059851988','sيستوحي هذا التيشيرت ذو الأكمام القصيرة والياقة المستديرة تصميمه من شعار LV الملكي المستوحى من القصور البريطانية الفخمة. يجمع نسيج الجاكار الغني على قاعدة زرقاء داكنة بين توقيعات لويس فويتون وعناصر شعارية، بما في ذلك الأشرطة والتيجان والكلب والثعلب. تضفي هذه القطعة الأنيقة لمسة راقية على إطلالتك الكاجوال.\n\nقصة عادية\nلون السماء الليلية\n100% قطن\nياقة مضلعة\nنقشة الجاكار المميزة على كامل القطعة\nصُنع في إيطاليا\n\nالعناية بالمنتج\nللحفاظ على جودة هذه القطعة، نوصي باتباع تعليمات العناية التالية:\nأقصى درجة حرارة للغسيل 30 درجة مئوية\nغسيل لطيف\nلا تستخدم المبيضات\nلا تجفف في المجفف الآلي\nكوي على درجة حرارة قصوى 110 درجة مئوية\nتنظيف جاف احترافي لطيف باستخدام الهيدروكربونات KWL\nتجفيف مسطح\nغسيل لطيف على درجة حرارة منخفضة\nيُغسل مقلوبًا في شبكة غسيل\nيُكوى مقلوبًا مع وضع قطعة قماش بينهما','This graphic short-sleeved crewneck draws on this collection’s regal LV Emblem motif inspired by British stately homes. The richly worked jacquard knit on a dark blue base mixes Louis Vuitton signatures with heraldic elements, including ribbons, crowns, a dog and a fox. This sophisticated piece elevates a casual look.\n\n\nRegular fit\nNight Sky\n100% Cotton\nRibbed collar\nJacquard signature motif all over\nMade in Italy\n\nProduct care\nTo preserve the quality of this garment, we recommend you to respect the care instructions :\nMaximum washing temperature 30°C\nmild process\nDo not bleach\nDo not tumble dry\nIron at a maximum sole-plate temperature of 110°C\nMild professional dry cleaning in hydrocarbons KWL\nFlat drying\nGentle wash with low temperature\nWash inside out in a net\nIron inside out with a fabric in between',2950.00,NULL,NULL,4,5,NULL,'/api/uploads/1781060765864-207863003.webp',1,0,1,1,0,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,8,0,'','','','','2026-06-10 02:50:51','2026-06-10 03:45:42',0,NULL),
(47,2,NULL,'MW-1781061637032','اكني ستوديوز','Acne Studios ','acne-studios-1781061637032','هذا التيشيرت من Acne Studios ذو ياقة دائرية وأكمام قصيرة، مزين بشعار موسمي. مصنوع من قطن جيرسي عضوي بسطح غير منتظم قليلاً لإطلالة مستوحاة من الطراز القديم، ويتميز بقصة مريحة وياقة مضلعة. مصنوع من قطن عضوي، والطبقة الخارجية قطن 100%.\n\nقصة مريحة\nالخامة: قطن جيرسي عضوي\nطول الكم: كم قصير\nميزة خاصة: شعار موسمي\nتركيب الخامة: قطن 100%\nفتحة الرقبة: ياقة دائرية','This Acne Studios T-shirt is a crewneck short-sleeve style with a seasonal logo. Crafted from organic cotton jersey with a slightly irregular surface for a vintage-inspired look, it has a relaxed fit and a ribbed collar. Style ID: FN-UX-TSHI000211. Made from organically grown cotton, the shell is 100% cotton.\n\nFit	relaxed\nMaterial	organic cotton jersey\nSleeve Length	short sleeve\nSpecial Feature	seasonal logo\nMaterial Composition	100% cotton\nNeckline	crewneck\n',2250.00,NULL,NULL,4,5,NULL,'/api/uploads/1781061637717-681005346.WEBP',1,0,1,1,1,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,2,0,'','','','','2026-06-10 03:20:37','2026-06-10 03:45:05',0,NULL),
(48,2,NULL,'MW-1781062377828','تيشيرت ري بيرسينت ','Represent Banner T-Shirt','represent-banner-t-shirt-1781062377828','','Model is 184.5cm and 72kg wearing size M\nRepresent Banner T-Shirt\n\nIntroducing the Represent Banner T-Shirt in Stained Black, a midweight cotton jersey with a carbon finish. Designed to a oversized fit, it features screen print graphics, rib collar, and ladder stitching at the hem and cuffs. Subtle distressing across the hem, cuffs, and shoulder seams adds a worn-in edge, finished with the signature Represent metal bar.\n\nStained Black Colourway\nOversized Fit\n100% Cotton, 270gsm with Carbon Finish\nScreen Print Graphic\nRibbed Collar\nLadder Stitch Detailing at Hem & Cuffs\nDistressing to Hem, Cuffs & Shoulder Seam\nSignature Metal Bar at Hem\nComposition: 100% Cotton\n270gsm with Carbon Finish\n\n\n',2950.00,NULL,NULL,3,5,NULL,'/api/uploads/1781062459435-364267795.jpg',1,0,1,1,0,'[\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,6,0,'','','','','2026-06-10 03:32:57','2026-06-10 05:00:48',0,NULL),
(49,2,NULL,'MW-1781063011206','تيشيرت أسود من AMIRI بنقش \"Chateau\"','AMIRI Black \'Chateau\' Script T-shirt','amiri-black-chateau-script-t-shirt-1781063011206','أميري\nتيشيرت أسود بنقشة \"شاتو\"\nتيشيرت قطني جيرسي.\n\n• ياقة دائرية محبوكة\n• شعار ونص مطبوعان على الصدر والظهر\n\nلون المورد: أسود\n100% قطن.\n\nصنع في إيطاليا.\n\nالمقاس والملاءمة\nقياسات العارض: الطول 188 سم، محيط الصدر 102 سم\nيرتدي العارض مقاس متوسط ​​أمريكي','AMIRI\nBlack \'Chateau\' Script T-shirt\nCotton jersey T-shirt.\n\n· Rib-knit crewneck\n· Logo and text printed at chest and back\n\nSupplier color: Black\n100% cotton.\nMade in Italy.\nSIZE & FIT\nModel measurements: 6\'2\" tall, 40\" chest\nModel is wearing a US size Medium\n',2950.00,NULL,NULL,4,5,NULL,'/api/uploads/1781063012145-666518028.avif',1,0,1,1,1,'[\"M\",\"L\",\"XL\",\"XXL\"]','[]','[]',0.00,0,6,0,'','','','','2026-06-10 03:43:31','2026-06-10 05:00:25',0,NULL),
(50,2,NULL,'MW-1781063687014','قميص بولو أبيض من كازابلانكا بشعار','Casablanca WHITE Polo with logo','casablanca-white-polo-with-logo-1781063687014','','Model`s Measurements\n\nHeight: 185cm\nChest: 92cm\nWaist: 74cm\nHips: 91cm\nModel is wearing size: L\n\nCasablanca Logo Polo is an exquisite example of modern elegance. Its classic design with a straight cut perfectly complements the unique blend of fabrics—a delicate, airy mesh wraps around the body like a summer breeze, ensuring exceptional wearing comfort.\n\nThe prevailing white is accentuated by wide navy blue stripes and subtle, light blue accents, harmoniously distributed throughout. The refined polo collar with three contrasting buttons and the distinctive CASABLANCA inscription on the left chest complete the composition, full of character. The ribbed knit finishes—also in navy blue—and perfectly matched stripes enhance the unique aesthetic of this piece.\n\n47% Cotton\n31% Wool\n21% Polyamide\n1% Elastane\n',2800.00,NULL,NULL,4,5,NULL,'/api/uploads/1781063691136-41500099.jpg',1,0,1,0,1,'[\"S\",\"M\",\"L\",\"XL\"]','[]','[]',0.00,0,0,0,'','','','','2026-06-10 03:54:47','2026-06-10 03:55:19',0,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `reviews_ibfk_53` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `reviews_ibfk_54` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `name_2` (`name`),
  UNIQUE KEY `name_3` (`name`),
  UNIQUE KEY `name_4` (`name`),
  UNIQUE KEY `name_5` (`name`),
  UNIQUE KEY `name_6` (`name`),
  UNIQUE KEY `name_7` (`name`),
  UNIQUE KEY `name_8` (`name`),
  UNIQUE KEY `name_9` (`name`),
  UNIQUE KEY `name_10` (`name`),
  UNIQUE KEY `name_11` (`name`),
  UNIQUE KEY `name_12` (`name`),
  UNIQUE KEY `name_13` (`name`),
  UNIQUE KEY `name_14` (`name`),
  UNIQUE KEY `name_15` (`name`),
  UNIQUE KEY `name_16` (`name`),
  UNIQUE KEY `name_17` (`name`),
  UNIQUE KEY `name_18` (`name`),
  UNIQUE KEY `name_19` (`name`),
  UNIQUE KEY `name_20` (`name`),
  UNIQUE KEY `name_21` (`name`),
  UNIQUE KEY `name_22` (`name`),
  UNIQUE KEY `name_23` (`name`),
  UNIQUE KEY `name_24` (`name`),
  UNIQUE KEY `name_25` (`name`),
  UNIQUE KEY `name_26` (`name`),
  UNIQUE KEY `name_27` (`name`),
  UNIQUE KEY `name_28` (`name`),
  UNIQUE KEY `name_29` (`name`),
  UNIQUE KEY `name_30` (`name`),
  UNIQUE KEY `name_31` (`name`),
  UNIQUE KEY `name_32` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'admin','{\"all\":true}','2026-06-02 08:17:44','2026-06-02 08:17:44'),
(2,'customer','{}','2026-06-02 08:17:44','2026-06-02 08:17:44'),
(3,'orders_admin','{\"orders\":true}','2026-06-07 11:55:01','2026-06-07 11:55:01');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequelizemeta`
--

DROP TABLE IF EXISTS `sequelizemeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequelizemeta` (
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequelizemeta`
--

LOCK TABLES `sequelizemeta` WRITE;
/*!40000 ALTER TABLE `sequelizemeta` DISABLE KEYS */;
INSERT INTO `sequelizemeta` VALUES
('20260210000000-add-orders-guest-columns.js'),
('20260509183000-create-marketing-tables.js'),
('20260509190000-create-whatsapp-integrations.js'),
('20260510120000-orders-user-id-nullable-for-guest.js'),
('20260510133000-add-whatsapp-phone-country-code.js'),
('20260510140000-add-whatsapp-business-account-id.js'),
('20260603120000-add-category-coming-soon-labels.js'),
('20260608120000-add-paymob-payment-method.js');
/*!40000 ALTER TABLE `sequelizemeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `group` varchar(50) DEFAULT 'general',
  `type` enum('string','number','boolean','json') DEFAULT 'string',
  `label_ar` varchar(200) DEFAULT NULL,
  `label_en` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`),
  UNIQUE KEY `key_2` (`key`),
  UNIQUE KEY `key_3` (`key`),
  UNIQUE KEY `key_4` (`key`),
  UNIQUE KEY `key_5` (`key`),
  UNIQUE KEY `key_6` (`key`),
  UNIQUE KEY `key_7` (`key`),
  UNIQUE KEY `key_8` (`key`),
  UNIQUE KEY `key_9` (`key`),
  UNIQUE KEY `key_10` (`key`),
  UNIQUE KEY `key_11` (`key`),
  UNIQUE KEY `key_12` (`key`),
  UNIQUE KEY `key_13` (`key`),
  UNIQUE KEY `key_14` (`key`),
  UNIQUE KEY `key_15` (`key`),
  UNIQUE KEY `key_16` (`key`),
  UNIQUE KEY `key_17` (`key`),
  UNIQUE KEY `key_18` (`key`),
  UNIQUE KEY `key_19` (`key`),
  UNIQUE KEY `key_20` (`key`),
  UNIQUE KEY `key_21` (`key`),
  UNIQUE KEY `key_22` (`key`),
  UNIQUE KEY `key_23` (`key`),
  UNIQUE KEY `key_24` (`key`),
  UNIQUE KEY `key_25` (`key`),
  UNIQUE KEY `key_26` (`key`),
  UNIQUE KEY `key_27` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=324 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'site_name','The Boutique Line','general','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(2,'site_name_ar','ذا بوتيك لاين','general','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(3,'default_language','en','general','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(4,'currency','EGP','general','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(5,'tax_rate','0','tax','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(6,'shipping_cost','120','shipping','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(7,'free_shipping_threshold','10000000000000','shipping','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(8,'delivery_countries','[\"EG\"]','shipping','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(9,'payment_stripe','false','payment','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(10,'payment_cod','true','payment','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(11,'payment_bank_transfer','false','payment','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(12,'bank_name','Al Rajhi Bank','payment','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(13,'bank_account','SA12 3456 7890 1234 5678 90','payment','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(14,'whatsapp','+966500000000','contact','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(15,'email_contact','info@miskwear.com','contact','string',NULL,NULL,'2026-06-02 08:17:45','2026-06-09 21:52:28'),
(46,'email_notify_status_confirmed','true','general','string',NULL,NULL,'2026-06-08 04:26:48','2026-06-09 21:52:28'),
(47,'smtp_secure','true','general','string',NULL,NULL,'2026-06-08 04:26:48','2026-06-09 21:52:28'),
(48,'smtp_user','app@anmka.com','general','string',NULL,NULL,'2026-06-08 04:26:48','2026-06-09 21:52:28'),
(49,'smtp_pass','Anmka@2506','general','string',NULL,NULL,'2026-06-08 04:26:48','2026-06-08 04:34:35'),
(50,'smtp_host','smtp.hostinger.com','general','string',NULL,NULL,'2026-06-08 04:26:48','2026-06-09 21:52:28'),
(51,'email_from_address','app@anmka.com','general','string',NULL,NULL,'2026-06-08 04:26:48','2026-06-09 21:52:28'),
(52,'email_from_name','The Boutique Line','general','string',NULL,NULL,'2026-06-08 04:26:48','2026-06-09 21:52:28'),
(75,'smtp_port','465','general','string',NULL,NULL,'2026-06-08 04:27:28','2026-06-09 21:52:28'),
(145,'payment_paymob','true','payment','string',NULL,NULL,'2026-06-08 04:37:46','2026-06-09 21:52:28'),
(146,'paymob_api_key','ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SmpiR0Z6Y3lJNklrMWxjbU5vWVc1MElpd2ljSEp2Wm1sc1pWOXdheUk2TVRFM05qTTFNeXdpYm1GdFpTSTZJbWx1YVhScFlXd2lmUS5feFZSazBGS0J1T2pqR3FFVFNTZGZwVHRWMUM1NS1pdDFoYVBPbEdSQXQwUFlMSGRwZ0NoaVVzekh4dlplOHo3V09IMlB1Nk40ZXNYZ210RTg5YV90dw==','payment','string',NULL,NULL,'2026-06-08 04:37:46','2026-06-08 04:50:56'),
(147,'paymob_integration_id','','payment','string',NULL,NULL,'2026-06-08 04:37:46','2026-06-09 21:52:28'),
(148,'paymob_iframe_id','','payment','string',NULL,NULL,'2026-06-08 04:37:46','2026-06-09 21:52:28'),
(149,'paymob_hmac_secret','9BBEA9E0AEDDF37AB925EFF590AF8CEE','payment','string',NULL,NULL,'2026-06-08 04:37:46','2026-06-08 04:50:56'),
(150,'paymob_api_base','https://accept.paymob.com/api','payment','string',NULL,NULL,'2026-06-08 04:37:46','2026-06-09 21:52:28'),
(151,'paymob_secret_key','egy_sk_test_71740623ccbd79527ea55531f9b5400161731f686dd0d3a393701d649352cd8f','payment','string',NULL,NULL,'2026-06-08 04:48:02','2026-06-08 04:50:56'),
(152,'paymob_public_key','egy_pk_test_soFGbXw15lZLNJZknysdMDmkz6psQJgt','payment','string',NULL,NULL,'2026-06-08 04:48:02','2026-06-09 21:52:28');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_events`
--

DROP TABLE IF EXISTS `store_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `event_name` varchar(50) NOT NULL,
  `path` varchar(300) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_store_events_session` (`session_id`),
  KEY `idx_store_events_name_time` (`event_name`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1795 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_events`
--

LOCK TABLES `store_events` WRITE;
/*!40000 ALTER TABLE `store_events` DISABLE KEYS */;
INSERT INTO `store_events` VALUES
(1,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 14:33:52'),
(2,'6aa28560-464a-410b-a826-80613e149a31','page_view','/',NULL,NULL,'2026-06-08 14:40:40'),
(3,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 14:41:44'),
(4,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 14:42:00'),
(5,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 14:42:59'),
(6,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 14:43:07'),
(7,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 14:43:09'),
(8,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products',NULL,NULL,'2026-06-08 14:43:13'),
(9,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=2&page=1',NULL,NULL,'2026-06-08 14:43:17'),
(10,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=20&page=1',NULL,NULL,'2026-06-08 14:43:17'),
(11,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=200&page=1',NULL,NULL,'2026-06-08 14:43:19'),
(12,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=2000&page=1',NULL,NULL,'2026-06-08 14:43:19'),
(13,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=2000&page=1&maxPrice=2',NULL,NULL,'2026-06-08 14:43:22'),
(14,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=2000&page=1&maxPrice=25',NULL,NULL,'2026-06-08 14:43:22'),
(15,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=2000&page=1&maxPrice=250',NULL,NULL,'2026-06-08 14:43:23'),
(16,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=2000&page=1&maxPrice=2500',NULL,NULL,'2026-06-08 14:43:23'),
(17,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1&page=1&maxPrice=2500',NULL,NULL,'2026-06-08 14:43:28'),
(18,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=16&page=1&maxPrice=2500',NULL,NULL,'2026-06-08 14:43:28'),
(19,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=160&page=1&maxPrice=2500',NULL,NULL,'2026-06-08 14:43:29'),
(20,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1600&page=1&maxPrice=2500',NULL,NULL,'2026-06-08 14:43:29'),
(21,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1600&page=1&maxPrice=2500&gender=men',NULL,NULL,'2026-06-08 14:43:34'),
(22,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1600&page=1&maxPrice=2500&gender=women',NULL,NULL,'2026-06-08 14:43:35'),
(23,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1600&page=1&maxPrice=2500&gender=women&category=2',NULL,NULL,'2026-06-08 14:43:42'),
(24,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1600&page=1&maxPrice=2500&gender=women',NULL,NULL,'2026-06-08 14:43:43'),
(25,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1600&page=1&maxPrice=2500&gender=men',NULL,NULL,'2026-06-08 14:43:45'),
(26,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?minPrice=1600&page=1&maxPrice=2500&gender=women',NULL,NULL,'2026-06-08 14:43:46'),
(27,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 14:43:58'),
(28,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/login',NULL,NULL,'2026-06-08 14:44:08'),
(29,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 14:44:20'),
(30,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/dashboard',NULL,NULL,'2026-06-08 14:44:24'),
(31,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?nav=men',NULL,NULL,'2026-06-08 14:45:46'),
(32,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?nav=men',NULL,NULL,'2026-06-08 14:46:40'),
(33,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/-1780925294507',NULL,NULL,'2026-06-08 14:46:44'),
(34,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 14:47:21'),
(35,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products',NULL,NULL,'2026-06-08 14:47:22'),
(36,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1',NULL,NULL,'2026-06-08 14:47:23'),
(37,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/-1780929937195',NULL,NULL,'2026-06-08 14:47:26'),
(38,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2',NULL,NULL,'2026-06-08 14:47:26'),
(39,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=20',NULL,NULL,'2026-06-08 14:47:26'),
(40,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=200',NULL,NULL,'2026-06-08 14:47:27'),
(41,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000',NULL,NULL,'2026-06-08 14:47:27'),
(42,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=1',NULL,NULL,'2026-06-08 14:47:29'),
(43,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=15',NULL,NULL,'2026-06-08 14:47:29'),
(44,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=150',NULL,NULL,'2026-06-08 14:47:29'),
(45,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=1500',NULL,NULL,'2026-06-08 14:47:29'),
(46,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=2',NULL,NULL,'2026-06-08 14:47:31'),
(47,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=25',NULL,NULL,'2026-06-08 14:47:31'),
(48,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=250',NULL,NULL,'2026-06-08 14:47:31'),
(49,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=2000&maxPrice=2500',NULL,NULL,'2026-06-08 14:47:31'),
(50,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=3&maxPrice=2500',NULL,NULL,'2026-06-08 14:47:40'),
(51,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=30&maxPrice=2500',NULL,NULL,'2026-06-08 14:47:41'),
(52,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=300&maxPrice=2500',NULL,NULL,'2026-06-08 14:47:41'),
(53,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=3000&maxPrice=2500',NULL,NULL,'2026-06-08 14:47:42'),
(54,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=3000&maxPrice=5',NULL,NULL,'2026-06-08 14:47:43'),
(55,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=3000&maxPrice=50',NULL,NULL,'2026-06-08 14:47:43'),
(56,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=3000&maxPrice=500',NULL,NULL,'2026-06-08 14:47:44'),
(57,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=3000&maxPrice=5000',NULL,NULL,'2026-06-08 14:47:44'),
(58,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=3000&maxPrice=5001',NULL,NULL,'2026-06-08 14:47:50'),
(59,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=4&maxPrice=5001',NULL,NULL,'2026-06-08 14:47:52'),
(60,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=women&page=1&minPrice=40&maxPrice=5001',NULL,NULL,'2026-06-08 14:47:53'),
(61,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 14:51:34'),
(62,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 14:51:37'),
(63,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 14:51:46'),
(64,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 14:51:48'),
(65,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 14:52:03'),
(66,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/-1780925294507',NULL,NULL,'2026-06-08 14:52:06'),
(67,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 14:52:08'),
(68,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-08 14:53:23'),
(69,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/checkout',NULL,NULL,'2026-06-08 14:53:23'),
(70,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','begin_checkout','/checkout',NULL,NULL,'2026-06-08 14:53:23'),
(71,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','purchase','/checkout',NULL,'{\"order_id\":2,\"total\":2227.55}','2026-06-08 14:53:53'),
(72,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/order-confirmed/MW-1780930432888-f54efe259cd5',NULL,NULL,'2026-06-08 14:53:53'),
(73,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 14:55:25'),
(74,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-08 14:55:31'),
(75,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-08 14:55:41'),
(76,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=10&page=1',NULL,NULL,'2026-06-08 14:55:42'),
(77,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=100&page=1',NULL,NULL,'2026-06-08 14:55:42'),
(78,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1000&page=1',NULL,NULL,'2026-06-08 14:55:43'),
(79,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=100&page=1',NULL,NULL,'2026-06-08 14:55:43'),
(80,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=10&page=1',NULL,NULL,'2026-06-08 14:55:43'),
(81,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-08 14:55:43'),
(82,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-08 14:55:43'),
(83,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1',NULL,NULL,'2026-06-08 14:55:47'),
(84,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=17',NULL,NULL,'2026-06-08 14:55:48'),
(85,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=177',NULL,NULL,'2026-06-08 14:55:48'),
(86,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1777',NULL,NULL,'2026-06-08 14:55:48'),
(87,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 14:56:59'),
(88,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 14:57:05'),
(89,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/embroidered-denim-jacket',NULL,NULL,'2026-06-08 14:57:23'),
(90,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?gender=men&page=1&maxPrice=5001&minPrice=3000',NULL,NULL,'2026-06-08 14:57:26'),
(91,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 14:57:28'),
(92,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products',NULL,NULL,'2026-06-08 15:02:46'),
(93,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:02:48'),
(94,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/-1780925294507',NULL,NULL,'2026-06-08 15:02:54'),
(95,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:03:02'),
(96,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:03:17'),
(97,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:03:23'),
(98,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:03:26'),
(99,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:03:33'),
(100,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:05:05'),
(101,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:05:16'),
(102,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products?nav=brands',NULL,NULL,'2026-06-08 15:06:09'),
(103,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/login',NULL,NULL,'2026-06-08 15:06:20'),
(104,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:06:23'),
(105,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:07:30'),
(106,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:07:39'),
(107,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/-1780929937195',NULL,NULL,'2026-06-08 15:07:40'),
(108,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:07:55'),
(109,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 15:08:41'),
(110,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','add_to_cart','/products/washed-linen-overshirt',1,'{\"quantity\":1}','2026-06-08 15:08:42'),
(111,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/checkout',NULL,NULL,'2026-06-08 15:08:45'),
(112,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','begin_checkout','/checkout',NULL,NULL,'2026-06-08 15:08:45'),
(113,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','purchase','/checkout',NULL,'{\"order_id\":3,\"total\":1989.5}','2026-06-08 15:08:51'),
(114,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/order-confirmed/MW-1780931330643-2f6d97930608',NULL,NULL,'2026-06-08 15:08:51'),
(115,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:09:34'),
(116,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:09:36'),
(117,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:10:05'),
(118,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 15:10:27'),
(119,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','add_to_cart','/products/washed-linen-overshirt',1,'{\"quantity\":1}','2026-06-08 15:10:28'),
(120,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/checkout',NULL,NULL,'2026-06-08 15:10:31'),
(121,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','begin_checkout','/checkout',NULL,NULL,'2026-06-08 15:10:31'),
(122,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/order-confirmed/MW-1780931442465-979bc06ede19',NULL,NULL,'2026-06-08 15:10:43'),
(123,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:11:05'),
(124,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-08 15:12:19'),
(125,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:12:21'),
(126,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:12:23'),
(127,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:13:56'),
(128,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:13:59'),
(129,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:14:08'),
(130,'e568221b-69f1-4138-b7c6-5bf4a0b46b9e','page_view','/',NULL,NULL,'2026-06-08 15:14:24'),
(131,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:14:28'),
(132,'26d5a644-e3bd-40ba-be59-c4edfda2afe7','page_view','/',NULL,NULL,'2026-06-08 15:14:28'),
(133,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/login',NULL,NULL,'2026-06-08 15:14:36'),
(134,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:14:42'),
(135,'f493a00b-8122-46b0-ac13-8fe9edb474eb','page_view','/',NULL,NULL,'2026-06-08 15:14:49'),
(136,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/login',NULL,NULL,'2026-06-08 15:15:02'),
(137,'684e2c42-0607-49fe-b69c-3339ad6a474c','page_view','/products/premium-zip-hoodie',NULL,NULL,'2026-06-08 15:15:03'),
(138,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/login',NULL,NULL,'2026-06-08 15:15:03'),
(139,'903483a4-2e45-4372-9417-dd6eb1914b93','page_view','/products/premium-zip-hoodie',NULL,NULL,'2026-06-08 15:15:06'),
(140,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:15:12'),
(141,'21cbef70-5598-4afe-a8bb-b9108b8aaac1','page_view','/login',NULL,NULL,'2026-06-08 15:15:14'),
(142,'669be8f0-1975-49f9-a27c-c9c7aba463b4','page_view','/login',NULL,NULL,'2026-06-08 15:15:15'),
(143,'26d5a644-e3bd-40ba-be59-c4edfda2afe7','page_view','/products/wide-jeans',NULL,NULL,'2026-06-08 15:15:26'),
(144,'26d5a644-e3bd-40ba-be59-c4edfda2afe7','page_view','/',NULL,NULL,'2026-06-08 15:15:28'),
(145,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:15:34'),
(146,'182a863d-daf3-474d-b897-5fad62ad5c4b','page_view','/products/wide-jeans',NULL,NULL,'2026-06-08 15:15:34'),
(147,'90542a8e-e6d3-4c1e-aff5-f06cfab806a1','page_view','/products/wide-jeans',NULL,NULL,'2026-06-08 15:15:38'),
(148,'26d5a644-e3bd-40ba-be59-c4edfda2afe7','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:16:33'),
(149,'834b787e-b38a-47e3-8a9e-d57a56efca94','page_view','/products',NULL,NULL,'2026-06-08 15:17:28'),
(150,'729934de-41b2-408c-87a8-1f6366a0b9d2','page_view','/products',NULL,NULL,'2026-06-08 15:17:29'),
(151,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:20:02'),
(152,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:20:20'),
(153,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 15:21:08'),
(154,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 15:21:33'),
(155,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:21:37'),
(156,'26d5a644-e3bd-40ba-be59-c4edfda2afe7','page_view','/',NULL,NULL,'2026-06-08 15:21:39'),
(157,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:21:44'),
(158,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:21:44'),
(159,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/-1780929937195',NULL,NULL,'2026-06-08 15:21:46'),
(160,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:22:10'),
(161,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/login',NULL,NULL,'2026-06-08 15:22:11'),
(162,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/register',NULL,NULL,'2026-06-08 15:22:13'),
(163,'26d5a644-e3bd-40ba-be59-c4edfda2afe7','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:22:18'),
(164,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:22:19'),
(165,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-08 15:22:22'),
(166,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products',NULL,NULL,'2026-06-08 15:22:25'),
(167,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-08 15:22:28'),
(168,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/login',NULL,NULL,'2026-06-08 15:23:10'),
(169,'1b1b48fa-ff2b-4e66-a7df-83247701065d','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-08 15:23:14'),
(170,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/',NULL,NULL,'2026-06-08 15:23:14'),
(171,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:23:16'),
(172,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 15:23:16'),
(173,'06540287-1ac4-4c81-be42-93677ea5a3da','page_view','/',NULL,NULL,'2026-06-08 15:24:01'),
(174,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/',NULL,NULL,'2026-06-08 15:24:20'),
(175,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/straight-leg-denim',NULL,NULL,'2026-06-08 15:24:34'),
(176,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 15:24:41'),
(177,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 15:24:53'),
(178,'f493a00b-8122-46b0-ac13-8fe9edb474eb','page_view','/',NULL,NULL,'2026-06-08 15:24:57'),
(179,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 15:25:00'),
(180,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:25:58'),
(181,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:25:58'),
(182,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:26:01'),
(183,'9c724d92-844c-4c49-8831-f0965d6e84d7','page_view','/',NULL,NULL,'2026-06-08 15:26:08'),
(184,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:26:25'),
(185,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:26:36'),
(186,'26d5a644-e3bd-40ba-be59-c4edfda2afe7','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:26:41'),
(187,'54fdcb0c-ac90-445f-9444-36c1abc317ec','page_view','/',NULL,NULL,'2026-06-08 15:27:33'),
(188,'54fdcb0c-ac90-445f-9444-36c1abc317ec','page_view','/',NULL,NULL,'2026-06-08 15:27:39'),
(189,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:27:48'),
(190,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:27:54'),
(191,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:27:58'),
(192,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:28:02'),
(193,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/login',NULL,NULL,'2026-06-08 15:29:56'),
(194,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:29:59'),
(195,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:31:53'),
(196,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:32:24'),
(197,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:34:01'),
(198,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:34:29'),
(199,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:34:33'),
(200,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:34:37'),
(201,'0f9979de-4ca1-4c99-9c57-0141e469bd89','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnxOClEnArb2-pTmTf9qK9edYR57xFJKSYoCYhCF3FlV81FAokCr4EnpnUzJs_aem_GHTykUCGPjMUMkMukkwfYA',NULL,NULL,'2026-06-08 15:34:41'),
(202,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:34:54'),
(203,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:34:56'),
(204,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:34:57'),
(205,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:35:09'),
(206,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:35:16'),
(207,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:37:50'),
(208,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:38:17'),
(209,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-08 15:38:31'),
(210,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/login',NULL,NULL,'2026-06-08 15:38:36'),
(211,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-08 15:38:54'),
(212,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:38:56'),
(213,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:39:08'),
(214,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:39:11'),
(215,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:39:19'),
(216,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:39:20'),
(217,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:39:36'),
(218,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:39:39'),
(219,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:39:45'),
(220,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 15:39:49'),
(221,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:39:55'),
(222,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:40:01'),
(223,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:40:05'),
(224,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 15:40:10'),
(225,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:40:11'),
(226,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-08 15:40:15'),
(227,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:40:20'),
(228,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-08 15:40:22'),
(229,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-08 15:40:24'),
(230,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/checkout',NULL,NULL,'2026-06-08 15:40:36'),
(231,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','begin_checkout','/checkout',NULL,NULL,'2026-06-08 15:40:36'),
(232,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:41:06'),
(233,'9d7f642c-57ae-4333-95f5-17507b2172d9','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-08 15:41:07'),
(234,'9d7f642c-57ae-4333-95f5-17507b2172d9','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-08 15:41:10'),
(235,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/checkout',NULL,NULL,'2026-06-08 15:41:10'),
(236,'9d7f642c-57ae-4333-95f5-17507b2172d9','begin_checkout','/checkout',NULL,NULL,'2026-06-08 15:41:10'),
(237,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-08 15:41:11'),
(238,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/checkout',NULL,NULL,'2026-06-08 15:41:11'),
(239,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','begin_checkout','/checkout',NULL,NULL,'2026-06-08 15:41:11'),
(240,'cd3f2dc1-8b16-40be-b9fc-25c83c84ffb9','page_view','/',NULL,NULL,'2026-06-08 15:42:29'),
(241,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 15:42:56'),
(242,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 15:43:14'),
(243,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=new',NULL,NULL,'2026-06-08 15:43:39'),
(244,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:43:49'),
(245,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 15:44:01'),
(246,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-08 15:44:23'),
(247,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:44:31'),
(248,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:45:21'),
(249,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 15:45:24'),
(250,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:45:28'),
(251,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:45:58'),
(252,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-08 15:46:31'),
(253,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:46:35'),
(254,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-08 15:46:36'),
(255,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:46:38'),
(256,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 15:46:39'),
(257,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:46:46'),
(258,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480','page_view','/',NULL,NULL,'2026-06-08 15:48:58'),
(259,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:49:11'),
(260,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:49:13'),
(261,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 15:49:58'),
(262,'cfd7b50b-aef2-4812-9af6-48c3f461ef95','page_view','/',NULL,NULL,'2026-06-08 15:50:07'),
(263,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 15:50:20'),
(264,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 15:51:16'),
(265,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:51:18'),
(266,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=new',NULL,NULL,'2026-06-08 15:51:34'),
(267,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-08 15:51:36'),
(268,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:51:38'),
(269,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 15:51:41'),
(270,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:51:46'),
(271,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 15:51:50'),
(272,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:51:50'),
(273,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:52:17'),
(274,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-08 15:52:40'),
(275,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:52:43'),
(276,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 15:52:46'),
(277,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:53:01'),
(278,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands',NULL,NULL,'2026-06-08 15:53:05'),
(279,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 15:53:15'),
(280,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:53:20'),
(281,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-08 15:53:22'),
(282,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:55:17'),
(283,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=trending',NULL,NULL,'2026-06-08 15:55:37'),
(284,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands',NULL,NULL,'2026-06-08 15:55:39'),
(285,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 15:55:53'),
(286,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:56:03'),
(287,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-08 15:56:11'),
(288,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 15:56:23'),
(289,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:56:33'),
(290,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:56:40'),
(291,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 15:56:48'),
(292,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:56:55'),
(293,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:57:23'),
(294,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:57:54'),
(295,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:59:51'),
(296,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 15:59:51'),
(297,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 16:00:26'),
(298,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-08 16:00:55'),
(299,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 16:01:03'),
(300,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/login',NULL,NULL,'2026-06-08 16:02:03'),
(301,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 16:02:06'),
(302,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-08 16:02:56'),
(303,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 16:06:25'),
(304,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 16:06:26'),
(305,'d20194ef-b7c0-42e7-af0a-c88969f2cb42','page_view','/',NULL,NULL,'2026-06-08 16:07:00'),
(306,'b0b96214-ee00-447a-b355-0b89fce38122','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnHa2mAQeaDWLMADzjwwxoLt3vRER_BNIuJnZcUi0NsjjDJxA2S1W-bQG1jEk_aem_ByRmM9nAGk_1D_cicCl13w',NULL,NULL,'2026-06-08 16:07:34'),
(307,'d9747463-ce45-49d3-b2cd-10429d3c5217','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-08 16:07:44'),
(308,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 16:07:57'),
(309,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-08 16:08:13'),
(310,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-08 16:08:33'),
(311,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 16:08:36'),
(312,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 16:08:38'),
(313,'cf1f4f53-7ce9-4aa0-8325-e6fcc0ea1e1b','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 16:08:39'),
(314,'d9747463-ce45-49d3-b2cd-10429d3c5217','page_view','/',NULL,NULL,'2026-06-08 16:10:41'),
(315,'d9747463-ce45-49d3-b2cd-10429d3c5217','page_view','/',NULL,NULL,'2026-06-08 16:10:45'),
(316,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:10:47'),
(317,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-08 16:11:56'),
(318,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-08 16:12:02'),
(319,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-08 16:12:06'),
(320,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-08 16:12:24'),
(321,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 16:12:26'),
(322,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-08 16:12:41'),
(323,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-08 16:13:13'),
(324,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-08 16:13:50'),
(325,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 16:14:39'),
(326,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 16:14:54'),
(327,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 16:16:31'),
(328,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 16:17:59'),
(329,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-08 16:18:12'),
(330,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 16:18:17'),
(331,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-08 16:19:35'),
(332,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:19:44'),
(333,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-08 16:19:52'),
(334,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-08 16:20:27'),
(335,'0d9cce6e-d5bc-44bb-a40e-a22da26c95f9','page_view','/',NULL,NULL,'2026-06-08 16:25:45'),
(336,'0d9cce6e-d5bc-44bb-a40e-a22da26c95f9','page_view','/login',NULL,NULL,'2026-06-08 16:26:16'),
(337,'2aa44102-3358-4ae2-9465-5f02b1973303','page_view','/',NULL,NULL,'2026-06-08 16:29:28'),
(338,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:32:07'),
(339,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:32:13'),
(340,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:32:23'),
(341,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-08 16:32:30'),
(342,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:32:32'),
(343,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 16:32:34'),
(344,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:32:45'),
(345,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 16:32:49'),
(346,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:32:51'),
(347,'50979b2e-4082-401f-ae12-b16564ae1ec1','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn5PFzLF9ShXuibCV2r-_ioeYjjIFLmrJLP-sSJ-EUD1v6uFOiWGL7qdo88GI_aem_XXacnqY93xyxwkZ5M1GM2w',NULL,NULL,'2026-06-08 16:33:01'),
(348,'1d18e39a-99ec-4347-83fa-548fbceccae9','page_view','/products/embroidered-denim-jacket',NULL,NULL,'2026-06-08 16:33:30'),
(349,'1d18e39a-99ec-4347-83fa-548fbceccae9','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn5PFzLF9ShXuibCV2r-_ioeYjjIFLmrJLP-sSJ-EUD1v6uFOiWGL7qdo88GI_aem_XXacnqY93xyxwkZ5M1GM2w',NULL,NULL,'2026-06-08 16:33:39'),
(350,'1d18e39a-99ec-4347-83fa-548fbceccae9','page_view','/products?on_sale=true',NULL,NULL,'2026-06-08 16:33:55'),
(351,'99bf4d86-8b12-4fce-90c1-de5219b94c6f','page_view','/',NULL,NULL,'2026-06-08 16:34:42'),
(352,'7b7e33f1-d4c4-44f9-8a1b-cdcfb2f368f8','page_view','/',NULL,NULL,'2026-06-08 16:40:39'),
(353,'d9747463-ce45-49d3-b2cd-10429d3c5217','page_view','/',NULL,NULL,'2026-06-08 16:41:25'),
(354,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:46:30'),
(355,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 16:46:38'),
(356,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:47:27'),
(357,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:47:40'),
(358,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:47:42'),
(359,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-08 16:47:47'),
(360,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:48:05'),
(361,'6848a907-8cd7-4e3a-91dd-5f55299fd22d','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPNTY3MDY3MzQzMzUyNDI3AAGnU86JwgYRaggLHvbk3QxmJoksDT2oudub8vpChpCO7gmI-FccVA8badyKysk_aem_YWdncwACivlBhvzJ5nS9utD0X2Ks&brid=YWdncwGHpTv4tOPITSRN72n6Fsdx',NULL,NULL,'2026-06-08 16:48:17'),
(362,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 16:50:53'),
(363,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=new',NULL,NULL,'2026-06-08 16:59:08'),
(364,'d96b9ea6-7df9-431a-a341-b2856b4494e7','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnCYPvV1uB4JatwL5YVhUbDkOWLqKSuMuTcpya4tfYl7B6glkxoFWj-orZ0M0_aem_BrN0XOzfxNBJk50uQ6uWSg',NULL,NULL,'2026-06-08 17:01:13'),
(365,'480abc1f-1fbc-41ff-8add-b5f90e5abfe8','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPNTY3MDY3MzQzMzUyNDI3AAGn4dWuPIndtv7TXLIK6SnzeXjNlBTH6GqFlGxorVs05YGVS_9FsMsGdYdEs7s_aem_BC9r5v8eLiWHUTFH6kdIZQ',NULL,NULL,'2026-06-08 17:11:21'),
(366,'480abc1f-1fbc-41ff-8add-b5f90e5abfe8','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPNTY3MDY3MzQzMzUyNDI3AAGnnwkCGYZg8wjcNEN_Rv4fGDAGjWE7pBZPnKHsjO6XmVC-J9ePh8zejQ7PNdE_aem_wYTeUOxHA9RjyIF4eZ5-BQ',NULL,NULL,'2026-06-08 17:12:22'),
(367,'480abc1f-1fbc-41ff-8add-b5f90e5abfe8','page_view','/about',NULL,NULL,'2026-06-08 17:12:31'),
(368,'480abc1f-1fbc-41ff-8add-b5f90e5abfe8','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPNTY3MDY3MzQzMzUyNDI3AAGnnwkCGYZg8wjcNEN_Rv4fGDAGjWE7pBZPnKHsjO6XmVC-J9ePh8zejQ7PNdE_aem_wYTeUOxHA9RjyIF4eZ5-BQ',NULL,NULL,'2026-06-08 17:13:55'),
(369,'95a33ef3-3a74-4516-a8a2-779d734278ca','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnUCJMDQVBo99xugZo_TqaTI-PNbHmjBewN8RJddl2-H4rLwhJEvDNTxfgINw_aem_K-nReXaSkD7Dbgdwa0Yuxw',NULL,NULL,'2026-06-08 17:38:40'),
(370,'30c83f33-1a06-4b79-8fda-dad49cf50aea','page_view','/terms',NULL,NULL,'2026-06-08 18:01:12'),
(371,'5fb9f186-c221-41f4-bb16-7a07f5c4e5cf','page_view','/',NULL,NULL,'2026-06-08 18:05:11'),
(372,'5fb9f186-c221-41f4-bb16-7a07f5c4e5cf','page_view','/login',NULL,NULL,'2026-06-08 18:05:43'),
(373,'e860ef7a-8e02-4eca-a00b-c64ebe0b5775','page_view','/',NULL,NULL,'2026-06-08 18:05:56'),
(374,'e860ef7a-8e02-4eca-a00b-c64ebe0b5775','page_view','/login',NULL,NULL,'2026-06-08 18:06:28'),
(375,'6766a480-ca28-421e-9aff-1b95eff38a5d','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn6rUtbR_1rR6Yt2Qzz4ZM02jxij6b0Qashxl_Gih8QPdSykaIoYUAZSXQvoU_aem_laDD0D2kpJlp62vpI52yZw',NULL,NULL,'2026-06-08 18:20:57'),
(376,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=new',NULL,NULL,'2026-06-08 18:46:08'),
(377,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/',NULL,NULL,'2026-06-08 18:46:11'),
(378,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 18:46:20'),
(379,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 18:55:55'),
(380,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 18:56:12'),
(381,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 18:56:13'),
(382,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing',NULL,NULL,'2026-06-08 18:56:18'),
(383,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing?minPrice=1&page=1',NULL,NULL,'2026-06-08 18:56:25'),
(384,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing?page=1',NULL,NULL,'2026-06-08 18:56:26'),
(385,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-08 18:57:05'),
(386,'54fdcb0c-ac90-445f-9444-36c1abc317ec','page_view','/',NULL,NULL,'2026-06-08 18:57:39'),
(387,'54fdcb0c-ac90-445f-9444-36c1abc317ec','page_view','/',NULL,NULL,'2026-06-08 18:57:41'),
(388,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 18:59:01'),
(389,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 18:59:13'),
(390,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 18:59:36'),
(391,'56ce9872-204d-4599-8291-dfb1b53315ae','page_view','/?fbclid=IwZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQMMjU2MjgxMDQwNTU4AAEehwgAcuNefyVZv5WvJujYibNp1SJKmaFYfDXihJoY9jhrE6b_xgT7x4Al6gw_aem_MXE6AboeFM56EdcoOqahCQ',NULL,NULL,'2026-06-08 19:02:25'),
(392,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 19:49:49'),
(393,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-08 19:50:01'),
(394,'9d7f642c-57ae-4333-95f5-17507b2172d9','add_to_cart','/products/hyh-1780933430759',27,'{\"quantity\":3}','2026-06-08 19:50:21'),
(395,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/checkout',NULL,NULL,'2026-06-08 19:50:21'),
(396,'9d7f642c-57ae-4333-95f5-17507b2172d9','begin_checkout','/checkout',NULL,NULL,'2026-06-08 19:50:21'),
(397,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 19:50:28'),
(398,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-08 19:50:38'),
(399,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 19:51:21'),
(400,'7f429012-d5f7-460c-bdb8-ada8ab00aec0','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn5ZM1UoaPQREBMj3px6pcxpW3iGSt32yaP_xQiZsomU9tfRDDvhA29lzChtk_aem_7d2oX-_EKnfGTGma6UR8zA',NULL,NULL,'2026-06-08 21:06:48'),
(401,'b6626c68-e8c1-4058-88fb-c28c1b46243f','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnfZgx5R_3VLFXNtIf9ULYVIl1KVtXVjJfvZlVHYESxKzaQiOfvyKW0vS2sN8_aem_ZMG7k_IucQwXAbor648ksQ',NULL,NULL,'2026-06-08 21:13:31'),
(402,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAdGRleASUD9FleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA8xMjQwMjQ1NzQyODc0MTQAAad9mDHlH_dUsVc20h_1QthUiXUpW1dWMl-9mVUdgRLErNpCI5-_IpbS9Law3w_aem_ZMG7k_IucQwXAbor648ksQ',NULL,NULL,'2026-06-08 21:13:41'),
(403,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAdGRleASUD9FleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA8xMjQwMjQ1NzQyODc0MTQAAad9mDHlH_dUsVc20h_1QthUiXUpW1dWMl-9mVUdgRLErNpCI5-_IpbS9Law3w_aem_ZMG7k_IucQwXAbor648ksQ',NULL,NULL,'2026-06-08 21:57:39'),
(404,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-08 21:57:47'),
(405,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-08 23:46:23'),
(406,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/login',NULL,NULL,'2026-06-08 23:49:02'),
(407,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-08 23:49:17'),
(408,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-08 23:50:40'),
(409,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-08 23:51:06'),
(410,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-08 23:51:09'),
(411,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 23:51:30'),
(412,'33342a76-000b-4540-83d6-6c1061fc73b2','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn8OlGgLvbnDwezA3JRnycFI2mf3NLd1fU62ne2sjqz5Mh6ddUWXZyqVj1rrk_aem_zVw_vN3Ka_-0fwjqXNLKYA',NULL,NULL,'2026-06-08 23:52:26'),
(413,'16a94f31-66de-4aa6-8a67-de6b90c49cb1','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAdGRleASUNTtleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA8xMjQwMjQ1NzQyODc0MTQAAafw6UaAu9ucPB7MDclGfJwUjaZ_c0t3V9Trad7ayOrPkyHp11RZdnKpWPWuuQ_aem_zVw_vN3Ka_-0fwjqXNLKYA',NULL,NULL,'2026-06-08 23:53:19'),
(414,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-08 23:54:15'),
(415,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-08 23:55:51'),
(416,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAdGRleASUNTtleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA8xMjQwMjQ1NzQyODc0MTQAAafw6UaAu9ucPB7MDclGfJwUjaZ_c0t3V9Trad7ayOrPkyHp11RZdnKpWPWuuQ_aem_zVw_vN3Ka_-0fwjqXNLKYA',NULL,NULL,'2026-06-08 23:55:57'),
(417,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-08 23:57:36'),
(418,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/products?nav=deals',NULL,NULL,'2026-06-08 23:57:55'),
(419,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/wishlist',NULL,NULL,'2026-06-08 23:58:07'),
(420,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/products',NULL,NULL,'2026-06-08 23:58:09'),
(421,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/wishlist',NULL,NULL,'2026-06-08 23:58:13'),
(422,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-08 23:59:10'),
(423,'0be87f4c-9850-4bc8-82fd-22e503253dfb','add_to_cart','/products/jjj-1780933364286',26,'{\"quantity\":1}','2026-06-08 23:59:12'),
(424,'0be87f4c-9850-4bc8-82fd-22e503253dfb','add_to_cart','/products/jjj-1780933364286',26,'{\"quantity\":1}','2026-06-08 23:59:13'),
(425,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/checkout',NULL,NULL,'2026-06-08 23:59:13'),
(426,'0be87f4c-9850-4bc8-82fd-22e503253dfb','begin_checkout','/checkout',NULL,NULL,'2026-06-08 23:59:13'),
(427,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/register',NULL,NULL,'2026-06-08 23:59:19'),
(428,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/verify-otp',NULL,NULL,'2026-06-08 23:59:52'),
(429,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:00:19'),
(430,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 00:00:55'),
(431,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 00:00:55'),
(432,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 00:03:06'),
(433,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/products/zz-1780963384040',NULL,NULL,'2026-06-09 00:03:10'),
(434,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 00:03:16'),
(435,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 00:03:56'),
(436,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/zz-1780963384040',NULL,NULL,'2026-06-09 00:04:02'),
(437,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 00:04:07'),
(438,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 00:04:09'),
(439,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 00:04:12'),
(440,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/checkout',NULL,NULL,'2026-06-09 00:04:33'),
(441,'0be87f4c-9850-4bc8-82fd-22e503253dfb','begin_checkout','/checkout',NULL,NULL,'2026-06-09 00:04:33'),
(442,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/wishlist',NULL,NULL,'2026-06-09 00:04:34'),
(443,'0be87f4c-9850-4bc8-82fd-22e503253dfb','purchase','/checkout',NULL,'{\"order_id\":5,\"total\":977.5}','2026-06-09 00:04:49'),
(444,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 00:04:49'),
(445,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/order-confirmed/MW-1780963488499-90a2e60984a3',NULL,NULL,'2026-06-09 00:04:49'),
(446,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 00:08:37'),
(447,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/',NULL,NULL,'2026-06-09 00:11:52'),
(448,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 00:12:39'),
(449,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/',NULL,NULL,'2026-06-09 00:13:06'),
(450,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/',NULL,NULL,'2026-06-09 00:13:39'),
(451,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 00:13:41'),
(452,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/',NULL,NULL,'2026-06-09 00:13:44'),
(453,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:27:09'),
(454,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/wide-jeans',NULL,NULL,'2026-06-09 00:27:12'),
(455,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:27:34'),
(456,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:27:42'),
(457,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:27:44'),
(458,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?maxPrice=2&page=1',NULL,NULL,'2026-06-09 00:27:50'),
(459,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?maxPrice=26&page=1',NULL,NULL,'2026-06-09 00:27:50'),
(460,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?maxPrice=262&page=1',NULL,NULL,'2026-06-09 00:27:50'),
(461,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?maxPrice=26&page=1',NULL,NULL,'2026-06-09 00:27:52'),
(462,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?maxPrice=2&page=1',NULL,NULL,'2026-06-09 00:27:52'),
(463,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?page=1',NULL,NULL,'2026-06-09 00:27:52'),
(464,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:28:02'),
(465,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 00:28:09'),
(466,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:28:10'),
(467,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 00:28:11'),
(468,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true&gender=men&minPrice=4&page=1',NULL,NULL,'2026-06-09 00:28:15'),
(469,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true&gender=men&minPrice=47&page=1',NULL,NULL,'2026-06-09 00:28:15'),
(470,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true',NULL,NULL,'2026-06-09 00:28:49'),
(471,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:28:54'),
(472,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/terms',NULL,NULL,'2026-06-09 00:29:05'),
(473,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:29:08'),
(474,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 00:29:09'),
(475,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:29:11'),
(476,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 00:29:13'),
(477,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:29:15'),
(478,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 00:29:18'),
(479,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders/5',NULL,NULL,'2026-06-09 00:29:20'),
(480,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 00:29:57'),
(481,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders/5',NULL,NULL,'2026-06-09 00:30:02'),
(482,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 00:30:21'),
(483,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders/5',NULL,NULL,'2026-06-09 00:30:24'),
(484,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/about',NULL,NULL,'2026-06-09 00:31:37'),
(485,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:31:56'),
(486,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 00:31:58'),
(487,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:31:59'),
(488,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/wishlist',NULL,NULL,'2026-06-09 00:32:00'),
(489,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:32:02'),
(490,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/cart',NULL,NULL,'2026-06-09 00:32:03'),
(491,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:32:03'),
(492,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/addresses',NULL,NULL,'2026-06-09 00:32:05'),
(493,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:32:11'),
(494,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/addresses',NULL,NULL,'2026-06-09 00:32:16'),
(495,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:32:26'),
(496,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/addresses',NULL,NULL,'2026-06-09 00:32:29'),
(497,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:32:32'),
(498,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/addresses',NULL,NULL,'2026-06-09 00:32:38'),
(499,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:18'),
(500,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/profile',NULL,NULL,'2026-06-09 00:33:18'),
(501,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:32'),
(502,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/profile',NULL,NULL,'2026-06-09 00:33:32'),
(503,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:32'),
(504,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/profile',NULL,NULL,'2026-06-09 00:33:32'),
(505,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:43'),
(506,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/terms',NULL,NULL,'2026-06-09 00:33:48'),
(507,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:49'),
(508,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/privacy',NULL,NULL,'2026-06-09 00:33:50'),
(509,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:53'),
(510,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/wishlist',NULL,NULL,'2026-06-09 00:33:54'),
(511,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:55'),
(512,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 00:33:56'),
(513,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:33:57'),
(514,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/about',NULL,NULL,'2026-06-09 00:33:58'),
(515,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:34:08'),
(516,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/about',NULL,NULL,'2026-06-09 00:34:10'),
(517,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:34:16'),
(518,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true',NULL,NULL,'2026-06-09 00:34:18'),
(519,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:34:19'),
(520,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:34:24'),
(521,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 00:34:28'),
(522,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true&gender=men&page=2',NULL,NULL,'2026-06-09 00:34:34'),
(523,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 00:34:38'),
(524,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 00:34:39'),
(525,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=trending',NULL,NULL,'2026-06-09 00:34:44'),
(526,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=new',NULL,NULL,'2026-06-09 00:34:46'),
(527,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=men',NULL,NULL,'2026-06-09 00:34:48'),
(528,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/about',NULL,NULL,'2026-06-09 00:34:51'),
(529,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=men',NULL,NULL,'2026-06-09 00:35:33'),
(530,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=new',NULL,NULL,'2026-06-09 00:35:41'),
(531,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=trending',NULL,NULL,'2026-06-09 00:35:44'),
(532,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 00:35:45'),
(533,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 00:35:46'),
(534,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:35:47'),
(535,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:35:54'),
(536,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:35:56'),
(537,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 00:35:58'),
(538,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:36:00'),
(539,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 00:36:01'),
(540,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:36:02'),
(541,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:36:27'),
(542,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:36:30'),
(543,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?nav=trending',NULL,NULL,'2026-06-09 00:36:42'),
(544,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:36:51'),
(545,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/addresses',NULL,NULL,'2026-06-09 00:36:55'),
(546,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 00:36:59'),
(547,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:37:34'),
(548,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-09 00:37:44'),
(549,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?category=2',NULL,NULL,'2026-06-09 00:37:53'),
(550,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-09 00:37:55'),
(551,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:38:21'),
(552,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 00:38:23'),
(553,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:38:40'),
(554,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1',NULL,NULL,'2026-06-09 00:38:45'),
(555,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true',NULL,NULL,'2026-06-09 00:38:48'),
(556,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true&gender=men',NULL,NULL,'2026-06-09 00:38:50'),
(557,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true&gender=women',NULL,NULL,'2026-06-09 00:38:51'),
(558,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true&gender=women&maxPrice=2',NULL,NULL,'2026-06-09 00:38:52'),
(559,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true&gender=women&maxPrice=26',NULL,NULL,'2026-06-09 00:38:52'),
(560,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true&gender=women&maxPrice=262',NULL,NULL,'2026-06-09 00:38:52'),
(561,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true&gender=women&maxPrice=262',NULL,NULL,'2026-06-09 00:40:15'),
(562,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:40:16'),
(563,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 00:40:17'),
(564,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-09 00:40:24'),
(565,'17c332ea-d6c8-45d2-8a57-ecc728f06082','add_to_cart','/products/washed-linen-overshirt',1,'{\"quantity\":3}','2026-06-09 00:40:28'),
(566,'17c332ea-d6c8-45d2-8a57-ecc728f06082','add_to_cart','/products/washed-linen-overshirt',1,'{\"quantity\":3}','2026-06-09 00:40:28'),
(567,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/checkout',NULL,NULL,'2026-06-09 00:40:28'),
(568,'17c332ea-d6c8-45d2-8a57-ecc728f06082','begin_checkout','/checkout',NULL,NULL,'2026-06-09 00:40:28'),
(569,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 00:40:31'),
(570,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/privacy',NULL,NULL,'2026-06-09 00:40:50'),
(571,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:40:51'),
(572,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&page=1&best_sellers=true&gender=women&maxPrice=262',NULL,NULL,'2026-06-09 00:41:13'),
(573,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 00:41:16'),
(574,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 00:41:27'),
(575,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 00:56:09'),
(576,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 00:57:36'),
(577,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 00:57:39'),
(578,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 00:57:41'),
(579,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 00:58:16'),
(580,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 01:03:54'),
(581,'39c6485a-0dbd-453e-a5ba-54519f780039','page_view','/products/long-sleeve-shirt',NULL,NULL,'2026-06-09 05:06:36'),
(582,'66a23493-7b01-4ac6-a562-d278d69705cf','page_view','/',NULL,NULL,'2026-06-09 06:49:33'),
(583,'a46a522a-734e-41ec-9843-3d5d4e09c2a0','page_view','/login',NULL,NULL,'2026-06-09 06:50:13'),
(584,'2eb524a8-1eb8-4209-9fa6-273c8ba21cb3','page_view','/products?category=2',NULL,NULL,'2026-06-09 06:51:39'),
(585,'5d83c271-c134-4d2c-a409-99a6b22baf31','page_view','/',NULL,NULL,'2026-06-09 06:51:53'),
(586,'eb8a870e-cd88-4e9d-a112-a59994a59478','page_view','/login',NULL,NULL,'2026-06-09 06:52:30'),
(587,'2a42377c-da2f-4e13-862b-9bd1447e9670','page_view','/products?category=2',NULL,NULL,'2026-06-09 06:54:15'),
(588,'70dd0e03-8ea0-421a-9f7f-c37911ae337b','page_view','/',NULL,NULL,'2026-06-09 06:55:53'),
(589,'34560882-7fc7-4c41-b2e5-df9306431270','page_view','/login',NULL,NULL,'2026-06-09 06:56:17'),
(590,'5c20b8e6-340c-4961-82ba-9456d39bc82f','page_view','/cmd_sco',NULL,NULL,'2026-06-09 06:56:32'),
(591,'85bea5a9-0f6e-4abe-8c39-14f6bab89193','page_view','/about-us',NULL,NULL,'2026-06-09 07:01:42'),
(592,'55b3620e-417d-4eff-938a-ef4045070d88','page_view','/',NULL,NULL,'2026-06-09 07:09:10'),
(593,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 07:20:51'),
(594,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/checkout',NULL,NULL,'2026-06-09 07:22:03'),
(595,'3c73de53-fab9-4726-a1c2-f390233736a5','begin_checkout','/checkout',NULL,NULL,'2026-06-09 07:22:03'),
(596,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 07:23:05'),
(597,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 07:23:10'),
(598,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 07:24:43'),
(599,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 07:24:51'),
(600,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 07:27:01'),
(601,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 07:31:45'),
(602,'a7686653-8085-47c3-8300-a9f8e3f93baa','page_view','/',NULL,NULL,'2026-06-09 07:39:59'),
(603,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/wishlist',NULL,NULL,'2026-06-09 07:40:13'),
(604,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 07:40:15'),
(605,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/',NULL,NULL,'2026-06-09 07:44:38'),
(606,'0ce8aabb-e446-45c7-8f27-7ffa6f89bb93','page_view','/',NULL,NULL,'2026-06-09 08:53:35'),
(607,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 09:22:09'),
(608,'8e34d515-411a-4c6f-9410-924f85a2c218','page_view','/',NULL,NULL,'2026-06-09 09:44:06'),
(609,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 09:49:21'),
(610,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 09:49:21'),
(611,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 09:50:07'),
(612,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 09:52:25'),
(613,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-09 09:55:33'),
(614,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?page=1',NULL,NULL,'2026-06-09 09:55:44'),
(615,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 09:58:43'),
(616,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 09:58:45'),
(617,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','begin_checkout','/checkout',NULL,NULL,'2026-06-09 10:00:00'),
(618,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/checkout',NULL,NULL,'2026-06-09 10:00:00'),
(619,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 10:00:35'),
(620,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 10:00:46'),
(621,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 10:01:03'),
(622,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:02:20'),
(623,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 10:02:21'),
(624,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:04:22'),
(625,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:04:34'),
(626,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:06:00'),
(627,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:11:01'),
(628,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:11:46'),
(629,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:11:49'),
(630,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-09 10:13:07'),
(631,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:13:45'),
(632,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:13:46'),
(633,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:13:51'),
(634,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 10:13:54'),
(635,'9d7f642c-57ae-4333-95f5-17507b2172d9','add_to_cart','/products/huhh-1780933306363',24,'{\"quantity\":1}','2026-06-09 10:14:14'),
(636,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/checkout',NULL,NULL,'2026-06-09 10:14:14'),
(637,'9d7f642c-57ae-4333-95f5-17507b2172d9','begin_checkout','/checkout',NULL,NULL,'2026-06-09 10:14:14'),
(638,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 10:14:16'),
(639,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:14:34'),
(640,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 10:14:41'),
(641,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 10:15:16'),
(642,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/',NULL,NULL,'2026-06-09 10:15:21'),
(643,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 10:16:02'),
(644,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:16:12'),
(645,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:16:20'),
(646,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/',NULL,NULL,'2026-06-09 10:16:30'),
(647,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 10:16:34'),
(648,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 10:16:40'),
(649,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 10:16:48'),
(650,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/',NULL,NULL,'2026-06-09 10:21:39'),
(651,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/',NULL,NULL,'2026-06-09 10:21:45'),
(652,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/products',NULL,NULL,'2026-06-09 10:22:29'),
(653,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:22:52'),
(654,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 10:25:43'),
(655,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 10:27:44'),
(656,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 10:29:28'),
(657,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/dashboard',NULL,NULL,'2026-06-09 10:29:33'),
(658,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/orders',NULL,NULL,'2026-06-09 10:29:35'),
(659,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/orders/4',NULL,NULL,'2026-06-09 10:29:38'),
(660,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/orders',NULL,NULL,'2026-06-09 10:29:41'),
(661,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/dashboard',NULL,NULL,'2026-06-09 10:29:44'),
(662,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/dashboard',NULL,NULL,'2026-06-09 10:30:04'),
(663,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/orders',NULL,NULL,'2026-06-09 10:30:06'),
(664,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/orders/4',NULL,NULL,'2026-06-09 10:30:08'),
(665,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/dashboard',NULL,NULL,'2026-06-09 10:30:40'),
(666,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','begin_checkout','/checkout',NULL,NULL,'2026-06-09 10:31:19'),
(667,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/checkout',NULL,NULL,'2026-06-09 10:31:19'),
(668,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-09 10:31:46'),
(669,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 10:32:08'),
(670,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products',NULL,NULL,'2026-06-09 10:32:28'),
(671,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 10:35:23'),
(672,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=7&page=1',NULL,NULL,'2026-06-09 10:35:26'),
(673,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=72&page=1',NULL,NULL,'2026-06-09 10:35:26'),
(674,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 10:35:43'),
(675,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 10:35:45'),
(676,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 10:35:48'),
(677,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:35:54'),
(678,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:35:57'),
(679,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 10:35:58'),
(680,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 10:36:02'),
(681,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 10:36:07'),
(682,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 10:36:16'),
(683,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 10:36:21'),
(684,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 10:36:26'),
(685,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/addresses',NULL,NULL,'2026-06-09 10:36:29'),
(686,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:36:32'),
(687,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 10:36:34'),
(688,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/hyh-1780933430759',27,'{\"quantity\":1}','2026-06-09 10:36:36'),
(689,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','begin_checkout','/checkout',NULL,NULL,'2026-06-09 10:36:36'),
(690,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/checkout',NULL,NULL,'2026-06-09 10:36:36'),
(691,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 10:36:39'),
(692,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/addresses',NULL,NULL,'2026-06-09 10:36:41'),
(693,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/dashboard',NULL,NULL,'2026-06-09 10:36:45'),
(694,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/wishlist',NULL,NULL,'2026-06-09 10:36:48'),
(695,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 10:36:49'),
(696,'0be87f4c-9850-4bc8-82fd-22e503253dfb','add_to_cart','/products/jjj-1780933364286',26,'{\"quantity\":1}','2026-06-09 10:36:51'),
(697,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/checkout',NULL,NULL,'2026-06-09 10:36:51'),
(698,'0be87f4c-9850-4bc8-82fd-22e503253dfb','begin_checkout','/checkout',NULL,NULL,'2026-06-09 10:36:51'),
(699,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/order-confirmed/MW-1781001420956-9e56cd83c759',NULL,NULL,'2026-06-09 10:37:01'),
(700,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 10:37:14'),
(701,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 10:37:16'),
(702,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 10:37:17'),
(703,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=16&page=1',NULL,NULL,'2026-06-09 10:37:17'),
(704,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=162&page=1',NULL,NULL,'2026-06-09 10:37:18'),
(705,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 10:37:20'),
(706,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 10:37:23'),
(707,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders/6',NULL,NULL,'2026-06-09 10:37:25'),
(708,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=16&page=1',NULL,NULL,'2026-06-09 10:37:29'),
(709,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 10:37:29'),
(710,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 10:37:29'),
(711,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=2',NULL,NULL,'2026-06-09 10:37:29'),
(712,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=27',NULL,NULL,'2026-06-09 10:37:30'),
(713,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=272',NULL,NULL,'2026-06-09 10:37:30'),
(714,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=2727',NULL,NULL,'2026-06-09 10:37:30'),
(715,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=272',NULL,NULL,'2026-06-09 10:37:32'),
(716,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=27',NULL,NULL,'2026-06-09 10:37:32'),
(717,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=2',NULL,NULL,'2026-06-09 10:37:32'),
(718,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 10:37:33'),
(719,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=2',NULL,NULL,'2026-06-09 10:37:33'),
(720,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=26',NULL,NULL,'2026-06-09 10:37:33'),
(721,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=262',NULL,NULL,'2026-06-09 10:37:33'),
(722,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=2626',NULL,NULL,'2026-06-09 10:37:33'),
(723,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=26263',NULL,NULL,'2026-06-09 10:37:34'),
(724,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/orders',NULL,NULL,'2026-06-09 10:37:34'),
(725,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 10:37:37'),
(726,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands&category=2&page=1',NULL,NULL,'2026-06-09 10:37:38'),
(727,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands&page=1',NULL,NULL,'2026-06-09 10:37:39'),
(728,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:37:40'),
(729,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands&page=1&category=2',NULL,NULL,'2026-06-09 10:37:40'),
(730,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 10:38:35'),
(731,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true',NULL,NULL,'2026-06-09 10:38:55'),
(732,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&minPrice=3&page=1',NULL,NULL,'2026-06-09 10:38:57'),
(733,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&minPrice=36&page=1',NULL,NULL,'2026-06-09 10:38:58'),
(734,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products',NULL,NULL,'2026-06-09 10:38:58'),
(735,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&minPrice=363&page=1',NULL,NULL,'2026-06-09 10:38:58'),
(736,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products?on_sale=true&minPrice=3636&page=1',NULL,NULL,'2026-06-09 10:38:58'),
(737,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 10:39:00'),
(738,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=1&page=1',NULL,NULL,'2026-06-09 10:39:08'),
(739,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=15&page=1',NULL,NULL,'2026-06-09 10:39:08'),
(740,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=1&page=1',NULL,NULL,'2026-06-09 10:39:08'),
(741,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 10:39:08'),
(742,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/heavyweight-hoodie',NULL,NULL,'2026-06-09 10:40:50'),
(743,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-09 10:42:15'),
(744,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 10:42:39'),
(745,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1',NULL,NULL,'2026-06-09 10:42:46'),
(746,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=16',NULL,NULL,'2026-06-09 10:42:47'),
(747,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=169',NULL,NULL,'2026-06-09 10:42:47'),
(748,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1692',NULL,NULL,'2026-06-09 10:42:48'),
(749,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=16927',NULL,NULL,'2026-06-09 10:42:48'),
(750,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=169277',NULL,NULL,'2026-06-09 10:42:48'),
(751,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1692772',NULL,NULL,'2026-06-09 10:42:48'),
(752,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=16927722',NULL,NULL,'2026-06-09 10:42:48'),
(753,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 10:42:48'),
(754,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=16',NULL,NULL,'2026-06-09 10:43:02'),
(755,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1',NULL,NULL,'2026-06-09 10:43:02'),
(756,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=168',NULL,NULL,'2026-06-09 10:43:02'),
(757,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 10:43:31'),
(758,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=168',NULL,NULL,'2026-06-09 10:43:37'),
(759,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/washed-linen-overshirt',NULL,NULL,'2026-06-09 10:43:43'),
(760,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=168',NULL,NULL,'2026-06-09 10:43:44'),
(761,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 10:44:03'),
(762,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 10:45:34'),
(763,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 10:51:17'),
(764,'37156259-5972-451a-bb85-c8e5c37be70a','page_view','/products',NULL,NULL,'2026-06-09 10:55:06'),
(765,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 11:06:46'),
(766,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 11:07:49'),
(767,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/',NULL,NULL,'2026-06-09 11:07:50'),
(768,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 11:07:50'),
(769,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands&minPrice=3&page=1',NULL,NULL,'2026-06-09 11:08:02'),
(770,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands&minPrice=31&page=1',NULL,NULL,'2026-06-09 11:08:02'),
(771,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands&minPrice=312&page=1',NULL,NULL,'2026-06-09 11:08:02'),
(772,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products?nav=brands&minPrice=3123&page=1',NULL,NULL,'2026-06-09 11:08:02'),
(773,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products',NULL,NULL,'2026-06-09 11:12:56'),
(774,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products',NULL,NULL,'2026-06-09 11:17:38'),
(775,'3c73de53-fab9-4726-a1c2-f390233736a5','page_view','/products',NULL,NULL,'2026-06-09 11:17:55'),
(776,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 11:18:11'),
(777,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products',NULL,NULL,'2026-06-09 11:18:27'),
(778,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 11:18:35'),
(779,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 11:18:42'),
(780,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products',NULL,NULL,'2026-06-09 11:18:49'),
(781,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/login',NULL,NULL,'2026-06-09 11:18:56'),
(782,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 11:18:59'),
(783,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 11:20:01'),
(784,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-09 11:25:48'),
(785,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men&page=2',NULL,NULL,'2026-06-09 11:26:10'),
(786,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men&page=1',NULL,NULL,'2026-06-09 11:26:17'),
(787,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 11:28:27'),
(788,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-09 11:39:59'),
(789,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=26263',NULL,NULL,'2026-06-09 11:42:02'),
(790,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 11:42:02'),
(791,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-09 11:42:07'),
(792,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 11:42:16'),
(793,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 11:42:19'),
(794,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 11:42:40'),
(795,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 11:42:43'),
(796,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:06:23'),
(797,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 12:06:28'),
(798,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:06:32'),
(799,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 12:31:52'),
(800,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 12:32:24'),
(801,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 12:32:40'),
(802,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 12:39:40'),
(803,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 12:39:43'),
(804,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 12:39:47'),
(805,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 12:44:52'),
(806,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 12:49:25'),
(807,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/',NULL,NULL,'2026-06-09 12:50:26'),
(808,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 12:50:49'),
(809,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:51:26'),
(810,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 12:51:27'),
(811,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:51:28'),
(812,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 12:51:29'),
(813,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:51:30'),
(814,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 12:51:32'),
(815,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 12:51:37'),
(816,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:52:12'),
(817,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 12:53:46'),
(818,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:54:19'),
(819,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-09 12:54:20'),
(820,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=168',NULL,NULL,'2026-06-09 12:55:17'),
(821,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=8168',NULL,NULL,'2026-06-09 12:55:22'),
(822,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=816',NULL,NULL,'2026-06-09 12:55:26'),
(823,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=81',NULL,NULL,'2026-06-09 12:55:26'),
(824,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=8',NULL,NULL,'2026-06-09 12:55:26'),
(825,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 12:55:26'),
(826,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1',NULL,NULL,'2026-06-09 12:55:27'),
(827,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=15',NULL,NULL,'2026-06-09 12:55:27'),
(828,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=150',NULL,NULL,'2026-06-09 12:55:28'),
(829,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1500',NULL,NULL,'2026-06-09 12:55:28'),
(830,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1500&maxPrice=2',NULL,NULL,'2026-06-09 12:55:44'),
(831,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1500&maxPrice=20',NULL,NULL,'2026-06-09 12:55:44'),
(832,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:55:44'),
(833,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1500&maxPrice=200',NULL,NULL,'2026-06-09 12:55:45'),
(834,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1500&maxPrice=2000',NULL,NULL,'2026-06-09 12:55:45'),
(835,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 12:55:46'),
(836,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1500&maxPrice=200',NULL,NULL,'2026-06-09 12:56:16'),
(837,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=1500&maxPrice=2000',NULL,NULL,'2026-06-09 12:56:17'),
(838,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:57:59'),
(839,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 12:58:06'),
(840,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 12:58:07'),
(841,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 12:58:09'),
(842,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products',NULL,NULL,'2026-06-09 13:02:41'),
(843,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products',NULL,NULL,'2026-06-09 13:02:53'),
(844,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 13:03:24'),
(845,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 13:04:12'),
(846,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 13:06:48'),
(847,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:07:05'),
(848,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:07:06'),
(849,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:12:15'),
(850,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products',NULL,NULL,'2026-06-09 13:22:08'),
(851,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?page=1',NULL,NULL,'2026-06-09 13:22:16'),
(852,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?page=1&maxPrice=8',NULL,NULL,'2026-06-09 13:22:19'),
(853,'5d05081b-1eb2-44e6-bec3-c2f0099b012e','page_view','/products?page=1',NULL,NULL,'2026-06-09 13:22:21'),
(854,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products',NULL,NULL,'2026-06-09 13:23:16'),
(855,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 13:24:53'),
(856,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 13:25:20'),
(857,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&minPrice=2&page=1',NULL,NULL,'2026-06-09 13:25:24'),
(858,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&minPrice=22&page=1',NULL,NULL,'2026-06-09 13:25:25'),
(859,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&minPrice=225&page=1',NULL,NULL,'2026-06-09 13:25:25'),
(860,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&minPrice=22&page=1',NULL,NULL,'2026-06-09 13:25:26'),
(861,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&minPrice=2&page=1',NULL,NULL,'2026-06-09 13:25:26'),
(862,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 13:25:26'),
(863,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&maxPrice=2',NULL,NULL,'2026-06-09 13:25:28'),
(864,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&maxPrice=22',NULL,NULL,'2026-06-09 13:25:28'),
(865,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&maxPrice=222',NULL,NULL,'2026-06-09 13:25:28'),
(866,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&maxPrice=2222',NULL,NULL,'2026-06-09 13:25:28'),
(867,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&maxPrice=222',NULL,NULL,'2026-06-09 13:25:30'),
(868,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&maxPrice=22',NULL,NULL,'2026-06-09 13:25:30'),
(869,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&maxPrice=2',NULL,NULL,'2026-06-09 13:25:30'),
(870,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 13:25:30'),
(871,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1',NULL,NULL,'2026-06-09 13:25:38'),
(872,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=12',NULL,NULL,'2026-06-09 13:25:38'),
(873,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=120',NULL,NULL,'2026-06-09 13:25:39'),
(874,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200',NULL,NULL,'2026-06-09 13:25:39'),
(875,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=1',NULL,NULL,'2026-06-09 13:25:40'),
(876,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15',NULL,NULL,'2026-06-09 13:25:41'),
(877,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=155',NULL,NULL,'2026-06-09 13:25:41'),
(878,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=1550',NULL,NULL,'2026-06-09 13:25:41'),
(879,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15500',NULL,NULL,'2026-06-09 13:25:41'),
(880,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=155008',NULL,NULL,'2026-06-09 13:25:42'),
(881,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=1550084',NULL,NULL,'2026-06-09 13:25:42'),
(882,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15500846',NULL,NULL,'2026-06-09 13:25:42'),
(883,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=155008463',NULL,NULL,'2026-06-09 13:25:42'),
(884,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=1550084634',NULL,NULL,'2026-06-09 13:25:42'),
(885,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15500846348',NULL,NULL,'2026-06-09 13:25:42'),
(886,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=155008463484',NULL,NULL,'2026-06-09 13:25:43'),
(887,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=1550084634849',NULL,NULL,'2026-06-09 13:25:43'),
(888,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15500846348494',NULL,NULL,'2026-06-09 13:25:43'),
(889,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=155008463484948',NULL,NULL,'2026-06-09 13:25:43'),
(890,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=1550084634849484',NULL,NULL,'2026-06-09 13:25:43'),
(891,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15500846348494848',NULL,NULL,'2026-06-09 13:25:44'),
(892,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=155008463484948488',NULL,NULL,'2026-06-09 13:25:44'),
(893,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=1550084634849484888',NULL,NULL,'2026-06-09 13:25:44'),
(894,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15500846348494848885',NULL,NULL,'2026-06-09 13:25:44'),
(895,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 13:31:29'),
(896,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 13:32:11'),
(897,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:33:42'),
(898,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:33:46'),
(899,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:33:51'),
(900,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 13:33:56'),
(901,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:34:12'),
(902,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 13:34:13'),
(903,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:34:16'),
(904,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 13:35:06'),
(905,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:35:18'),
(906,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 13:35:20'),
(907,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 13:35:22'),
(908,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 13:35:26'),
(909,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/iuiii-1780933275521',NULL,NULL,'2026-06-09 13:35:28'),
(910,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/premium-zip-hoodie',NULL,NULL,'2026-06-09 13:43:26'),
(911,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 13:43:28'),
(912,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-09 13:44:08'),
(913,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 13:44:40'),
(914,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 13:44:48'),
(915,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 13:44:56'),
(916,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/iuiii-1780933275521',NULL,NULL,'2026-06-09 14:02:17'),
(917,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:02:27'),
(918,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:06:04'),
(919,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 14:06:08'),
(920,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:06:09'),
(921,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-09 14:11:07'),
(922,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 14:34:29'),
(923,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 14:34:35'),
(924,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 14:34:36'),
(925,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 14:34:38'),
(926,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 14:34:40'),
(927,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 14:34:42'),
(928,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 14:34:45'),
(929,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-09 14:34:46'),
(930,'b7802db3-fcdf-43c3-9d90-18ec3468c396','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnP0ZLJtRr2zklu9-3auloiTWJCm5rsN80jHIRiQdRDqT9wE0WrkfrlxehkVA_aem_w4SFidsnQWi5yDYdJatABA',NULL,NULL,'2026-06-09 14:36:10'),
(931,'b7802db3-fcdf-43c3-9d90-18ec3468c396','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnP0ZLJtRr2zklu9-3auloiTWJCm5rsN80jHIRiQdRDqT9wE0WrkfrlxehkVA_aem_w4SFidsnQWi5yDYdJatABA',NULL,NULL,'2026-06-09 14:36:48'),
(932,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 14:37:19'),
(933,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 14:37:22'),
(934,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 14:37:40'),
(935,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 14:37:49'),
(936,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 14:37:52'),
(937,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:43:19'),
(938,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:43:19'),
(939,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-09 14:45:08'),
(940,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products?nav=men',NULL,NULL,'2026-06-09 14:45:10'),
(941,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 14:45:12'),
(942,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 14:45:51'),
(943,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 14:46:12'),
(944,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 14:48:30'),
(945,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 14:50:15'),
(946,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/hyh-1780933430759',27,'{\"quantity\":1}','2026-06-09 14:50:16'),
(947,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','begin_checkout','/checkout',NULL,NULL,'2026-06-09 14:50:16'),
(948,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/checkout',NULL,NULL,'2026-06-09 14:50:16'),
(949,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:51:00'),
(950,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 14:51:01'),
(951,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:51:02'),
(952,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 14:51:04'),
(953,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:51:05'),
(954,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 14:51:06'),
(955,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 14:51:06'),
(956,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:51:07'),
(957,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 14:51:08'),
(958,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 14:51:11'),
(959,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=15&page=1',NULL,NULL,'2026-06-09 14:51:11'),
(960,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=150&page=1',NULL,NULL,'2026-06-09 14:51:12'),
(961,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=15&page=1',NULL,NULL,'2026-06-09 14:51:13'),
(962,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 14:51:13'),
(963,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 14:51:13'),
(964,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1',NULL,NULL,'2026-06-09 14:51:15'),
(965,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=15',NULL,NULL,'2026-06-09 14:51:15'),
(966,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=150',NULL,NULL,'2026-06-09 14:51:15'),
(967,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 14:56:14'),
(968,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 14:57:00'),
(969,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 14:57:02'),
(970,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 14:57:33'),
(971,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 14:57:39'),
(972,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 14:58:26'),
(973,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=4&page=1',NULL,NULL,'2026-06-09 14:58:32'),
(974,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=48&page=1',NULL,NULL,'2026-06-09 14:58:32'),
(975,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=4&page=1',NULL,NULL,'2026-06-09 14:58:52'),
(976,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 14:58:52'),
(977,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=8',NULL,NULL,'2026-06-09 14:58:54'),
(978,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=88',NULL,NULL,'2026-06-09 14:58:55'),
(979,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=8',NULL,NULL,'2026-06-09 14:58:59'),
(980,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 14:58:59'),
(981,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=9',NULL,NULL,'2026-06-09 14:59:00'),
(982,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=96',NULL,NULL,'2026-06-09 14:59:00'),
(983,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=9',NULL,NULL,'2026-06-09 14:59:04'),
(984,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 14:59:04'),
(985,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=6',NULL,NULL,'2026-06-09 14:59:08'),
(986,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=69',NULL,NULL,'2026-06-09 14:59:08'),
(987,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=6',NULL,NULL,'2026-06-09 14:59:09'),
(988,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 14:59:09'),
(989,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1',NULL,NULL,'2026-06-09 14:59:12'),
(990,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=18',NULL,NULL,'2026-06-09 14:59:12'),
(991,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 14:59:44'),
(992,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 15:00:04'),
(993,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 15:00:13'),
(994,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 15:00:22'),
(995,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:01:20'),
(996,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 15:01:40'),
(997,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?new_arrivals=true&gender=men&minPrice=1&page=1',NULL,NULL,'2026-06-09 15:01:55'),
(998,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?new_arrivals=true&gender=men&minPrice=15&page=1',NULL,NULL,'2026-06-09 15:01:55'),
(999,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?new_arrivals=true&gender=men&minPrice=150&page=1',NULL,NULL,'2026-06-09 15:01:56'),
(1000,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?new_arrivals=true&gender=men&minPrice=1500&page=1',NULL,NULL,'2026-06-09 15:01:56'),
(1001,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1200&maxPrice=15500846348494848885',NULL,NULL,'2026-06-09 15:02:02'),
(1002,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products',NULL,NULL,'2026-06-09 15:02:05'),
(1003,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products',NULL,NULL,'2026-06-09 15:02:06'),
(1004,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=7&page=1',NULL,NULL,'2026-06-09 15:02:12'),
(1005,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=77&page=1',NULL,NULL,'2026-06-09 15:02:13'),
(1006,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=779&page=1',NULL,NULL,'2026-06-09 15:02:13'),
(1007,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=7794&page=1',NULL,NULL,'2026-06-09 15:02:13'),
(1008,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=77949&page=1',NULL,NULL,'2026-06-09 15:02:13'),
(1009,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=7799&page=1',NULL,NULL,'2026-06-09 15:02:17'),
(1010,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=779&page=1',NULL,NULL,'2026-06-09 15:02:17'),
(1011,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=79&page=1',NULL,NULL,'2026-06-09 15:02:17'),
(1012,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?minPrice=9&page=1',NULL,NULL,'2026-06-09 15:02:17'),
(1013,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:02:18'),
(1014,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=4',NULL,NULL,'2026-06-09 15:02:19'),
(1015,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=46',NULL,NULL,'2026-06-09 15:02:19'),
(1016,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=4',NULL,NULL,'2026-06-09 15:02:28'),
(1017,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:02:28'),
(1018,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=5',NULL,NULL,'2026-06-09 15:02:29'),
(1019,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=55',NULL,NULL,'2026-06-09 15:02:29'),
(1020,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=555',NULL,NULL,'2026-06-09 15:02:30'),
(1021,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=555&maxPrice=5',NULL,NULL,'2026-06-09 15:02:31'),
(1022,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=555&maxPrice=55',NULL,NULL,'2026-06-09 15:02:31'),
(1023,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=555&maxPrice=555',NULL,NULL,'2026-06-09 15:02:32'),
(1024,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=1&minPrice=555&maxPrice=5555',NULL,NULL,'2026-06-09 15:02:32'),
(1025,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?page=2&minPrice=555&maxPrice=5555',NULL,NULL,'2026-06-09 15:02:44'),
(1026,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:02:53'),
(1027,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 15:03:08'),
(1028,'99431ad7-5ce4-45d3-8b2b-4604d898e65e','page_view','/',NULL,NULL,'2026-06-09 15:03:14'),
(1029,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 15:03:25'),
(1030,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 15:03:34'),
(1031,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 15:03:34'),
(1032,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:03:36'),
(1033,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:03:41'),
(1034,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 15:03:44'),
(1035,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women',NULL,NULL,'2026-06-09 15:03:46'),
(1036,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/iuiii-1780933275521',NULL,NULL,'2026-06-09 15:03:52'),
(1037,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 15:03:53'),
(1038,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:03:58'),
(1039,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7',NULL,NULL,'2026-06-09 15:04:00'),
(1040,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75',NULL,NULL,'2026-06-09 15:04:00'),
(1041,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752',NULL,NULL,'2026-06-09 15:04:00'),
(1042,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7524',NULL,NULL,'2026-06-09 15:04:00'),
(1043,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75245',NULL,NULL,'2026-06-09 15:04:00'),
(1044,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752454',NULL,NULL,'2026-06-09 15:04:00'),
(1045,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7524546',NULL,NULL,'2026-06-09 15:04:00'),
(1046,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75245464',NULL,NULL,'2026-06-09 15:04:01'),
(1047,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752454645',NULL,NULL,'2026-06-09 15:04:01'),
(1048,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7524546454',NULL,NULL,'2026-06-09 15:04:01'),
(1049,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75245464548',NULL,NULL,'2026-06-09 15:04:01'),
(1050,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752454645485',NULL,NULL,'2026-06-09 15:04:01'),
(1051,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7524546454854',NULL,NULL,'2026-06-09 15:04:01'),
(1052,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752454645485',NULL,NULL,'2026-06-09 15:04:02'),
(1053,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75245464548',NULL,NULL,'2026-06-09 15:04:02'),
(1054,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7524546454',NULL,NULL,'2026-06-09 15:04:02'),
(1055,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752454645',NULL,NULL,'2026-06-09 15:04:03'),
(1056,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75245464',NULL,NULL,'2026-06-09 15:04:03'),
(1057,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7524546',NULL,NULL,'2026-06-09 15:04:03'),
(1058,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752454',NULL,NULL,'2026-06-09 15:04:03'),
(1059,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75245',NULL,NULL,'2026-06-09 15:04:03'),
(1060,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7524',NULL,NULL,'2026-06-09 15:04:03'),
(1061,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=752',NULL,NULL,'2026-06-09 15:04:03'),
(1062,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=75',NULL,NULL,'2026-06-09 15:04:03'),
(1063,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=7',NULL,NULL,'2026-06-09 15:04:04'),
(1064,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women',NULL,NULL,'2026-06-09 15:04:04'),
(1065,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5',NULL,NULL,'2026-06-09 15:04:08'),
(1066,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=55',NULL,NULL,'2026-06-09 15:04:08'),
(1067,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=555',NULL,NULL,'2026-06-09 15:04:08'),
(1068,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555',NULL,NULL,'2026-06-09 15:04:08'),
(1069,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=55555',NULL,NULL,'2026-06-09 15:04:08'),
(1070,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=555558',NULL,NULL,'2026-06-09 15:04:09'),
(1071,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555585',NULL,NULL,'2026-06-09 15:04:09'),
(1072,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555585&maxPrice=6',NULL,NULL,'2026-06-09 15:04:10'),
(1073,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555585&maxPrice=65',NULL,NULL,'2026-06-09 15:04:10'),
(1074,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555585&maxPrice=656',NULL,NULL,'2026-06-09 15:04:10'),
(1075,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555585&maxPrice=6565',NULL,NULL,'2026-06-09 15:04:10'),
(1076,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555585&maxPrice=65656',NULL,NULL,'2026-06-09 15:04:10'),
(1077,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&page=1&gender=women&minPrice=5555585&maxPrice=656565',NULL,NULL,'2026-06-09 15:04:10'),
(1078,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:04:12'),
(1079,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products',NULL,NULL,'2026-06-09 15:04:30'),
(1080,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 15:04:32'),
(1081,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=8&page=1',NULL,NULL,'2026-06-09 15:04:33'),
(1082,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=85&page=1',NULL,NULL,'2026-06-09 15:04:34'),
(1083,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=858&page=1',NULL,NULL,'2026-06-09 15:04:34'),
(1084,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=8585&page=1',NULL,NULL,'2026-06-09 15:04:34'),
(1085,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=85855&page=1',NULL,NULL,'2026-06-09 15:04:34'),
(1086,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=858558&page=1',NULL,NULL,'2026-06-09 15:04:34'),
(1087,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=8585586&page=1',NULL,NULL,'2026-06-09 15:04:35'),
(1088,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=858558&page=1',NULL,NULL,'2026-06-09 15:04:36'),
(1089,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=85855&page=1',NULL,NULL,'2026-06-09 15:04:36'),
(1090,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=8585&page=1',NULL,NULL,'2026-06-09 15:04:36'),
(1091,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=858&page=1',NULL,NULL,'2026-06-09 15:04:36'),
(1092,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=85&page=1',NULL,NULL,'2026-06-09 15:04:36'),
(1093,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:04:37'),
(1094,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?minPrice=8&page=1',NULL,NULL,'2026-06-09 15:04:37'),
(1095,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products',NULL,NULL,'2026-06-09 15:04:38'),
(1096,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?minPrice=5&page=1',NULL,NULL,'2026-06-09 15:04:50'),
(1097,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?minPrice=50&page=1',NULL,NULL,'2026-06-09 15:04:50'),
(1098,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?minPrice=500&page=1',NULL,NULL,'2026-06-09 15:04:51'),
(1099,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?minPrice=5000&page=1',NULL,NULL,'2026-06-09 15:04:51'),
(1100,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?minPrice=500&page=1',NULL,NULL,'2026-06-09 15:04:53'),
(1101,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?minPrice=50&page=1',NULL,NULL,'2026-06-09 15:04:53'),
(1102,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?minPrice=5&page=1',NULL,NULL,'2026-06-09 15:04:53'),
(1103,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:04:53'),
(1104,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:16:37'),
(1105,'61c74084-7036-401a-b873-915b3817e16d','page_view','/',NULL,NULL,'2026-06-09 15:17:12'),
(1106,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 15:17:16'),
(1107,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?nav=brands&minPrice=5&page=1',NULL,NULL,'2026-06-09 15:17:20'),
(1108,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?nav=brands&minPrice=54&page=1',NULL,NULL,'2026-06-09 15:17:20'),
(1109,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/login',NULL,NULL,'2026-06-09 15:20:11'),
(1110,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 15:20:12'),
(1111,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:20:13'),
(1112,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:20:17'),
(1113,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:20:18'),
(1114,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=5',NULL,NULL,'2026-06-09 15:20:21'),
(1115,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=51',NULL,NULL,'2026-06-09 15:20:21'),
(1116,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=511',NULL,NULL,'2026-06-09 15:20:21'),
(1117,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=5115',NULL,NULL,'2026-06-09 15:20:22'),
(1118,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=51151',NULL,NULL,'2026-06-09 15:20:22'),
(1119,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=511518',NULL,NULL,'2026-06-09 15:20:22'),
(1120,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=5115184',NULL,NULL,'2026-06-09 15:20:22'),
(1121,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=51151845',NULL,NULL,'2026-06-09 15:20:22'),
(1122,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=511518454',NULL,NULL,'2026-06-09 15:20:22'),
(1123,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=5115184545',NULL,NULL,'2026-06-09 15:20:23'),
(1124,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=511518454',NULL,NULL,'2026-06-09 15:20:23'),
(1125,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=51151845',NULL,NULL,'2026-06-09 15:20:24'),
(1126,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 15:20:24'),
(1127,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=5115184',NULL,NULL,'2026-06-09 15:20:24'),
(1128,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=511518',NULL,NULL,'2026-06-09 15:20:24'),
(1129,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=51151',NULL,NULL,'2026-06-09 15:20:24'),
(1130,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=5115',NULL,NULL,'2026-06-09 15:20:24'),
(1131,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=511',NULL,NULL,'2026-06-09 15:20:24'),
(1132,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=51',NULL,NULL,'2026-06-09 15:20:24'),
(1133,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1&minPrice=5',NULL,NULL,'2026-06-09 15:20:24'),
(1134,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:20:25'),
(1135,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 15:20:29'),
(1136,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-09 15:20:43'),
(1137,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products',NULL,NULL,'2026-06-09 15:21:15'),
(1138,'08100d0d-3fc1-44cd-b846-38a10e8137a7','page_view','/products',NULL,NULL,'2026-06-09 15:21:18'),
(1139,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=5&page=1',NULL,NULL,'2026-06-09 15:21:18'),
(1140,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=51&page=1',NULL,NULL,'2026-06-09 15:21:18'),
(1141,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=512&page=1',NULL,NULL,'2026-06-09 15:21:18'),
(1142,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=5124&page=1',NULL,NULL,'2026-06-09 15:21:18'),
(1143,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=51245&page=1',NULL,NULL,'2026-06-09 15:21:18'),
(1144,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=5124&page=1',NULL,NULL,'2026-06-09 15:21:19'),
(1145,'a97a0019-1aef-49c2-ae9a-b6843901e125','page_view','/products?minPrice=5&page=1',NULL,NULL,'2026-06-09 15:21:19'),
(1146,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=512&page=1',NULL,NULL,'2026-06-09 15:21:19'),
(1147,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=51&page=1',NULL,NULL,'2026-06-09 15:21:19'),
(1148,'3354e84e-13fb-4062-98aa-a558055556cc','page_view','/products?minPrice=5124&page=1',NULL,NULL,'2026-06-09 15:21:20'),
(1149,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=5&page=1',NULL,NULL,'2026-06-09 15:21:20'),
(1150,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:21:20'),
(1151,'f973e263-222d-4b73-aab8-09bfe20bc6d9','page_view','/products?minPrice=5&page=1',NULL,NULL,'2026-06-09 15:21:20'),
(1152,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=1',NULL,NULL,'2026-06-09 15:21:52'),
(1153,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15',NULL,NULL,'2026-06-09 15:21:52'),
(1154,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=155',NULL,NULL,'2026-06-09 15:21:52'),
(1155,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:21:52'),
(1156,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=1554',NULL,NULL,'2026-06-09 15:21:52'),
(1157,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545',NULL,NULL,'2026-06-09 15:21:52'),
(1158,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545&maxPrice=5',NULL,NULL,'2026-06-09 15:21:53'),
(1159,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545&maxPrice=55',NULL,NULL,'2026-06-09 15:21:53'),
(1160,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545&maxPrice=555',NULL,NULL,'2026-06-09 15:21:53'),
(1161,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545&maxPrice=5552',NULL,NULL,'2026-06-09 15:21:54'),
(1162,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545&maxPrice=55526',NULL,NULL,'2026-06-09 15:21:54'),
(1163,'bc93ced0-794d-4cd1-9183-ee917abddf70','page_view','/products?page=1&minPrice=1554',NULL,NULL,'2026-06-09 15:21:54'),
(1164,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545&maxPrice=555265',NULL,NULL,'2026-06-09 15:21:54'),
(1165,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15545&maxPrice=5552651',NULL,NULL,'2026-06-09 15:21:54'),
(1166,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 15:21:54'),
(1167,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&minPrice=2&page=1',NULL,NULL,'2026-06-09 15:21:58'),
(1168,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&minPrice=21&page=1',NULL,NULL,'2026-06-09 15:21:58'),
(1169,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=1554&maxPrice=5552651',NULL,NULL,'2026-06-09 15:21:59'),
(1170,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=155&maxPrice=5552651',NULL,NULL,'2026-06-09 15:21:59'),
(1171,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=15&maxPrice=5552651',NULL,NULL,'2026-06-09 15:21:59'),
(1172,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=1&maxPrice=5552651',NULL,NULL,'2026-06-09 15:22:00'),
(1173,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&maxPrice=5552651',NULL,NULL,'2026-06-09 15:22:00'),
(1174,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 15:22:00'),
(1175,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&maxPrice=555265',NULL,NULL,'2026-06-09 15:22:02'),
(1176,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&maxPrice=55526',NULL,NULL,'2026-06-09 15:22:02'),
(1177,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&maxPrice=5552',NULL,NULL,'2026-06-09 15:22:02'),
(1178,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&maxPrice=555',NULL,NULL,'2026-06-09 15:22:02'),
(1179,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&maxPrice=55',NULL,NULL,'2026-06-09 15:22:02'),
(1180,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&maxPrice=5',NULL,NULL,'2026-06-09 15:22:03'),
(1181,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:22:03'),
(1182,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&minPrice=21&page=1',NULL,NULL,'2026-06-09 15:22:03'),
(1183,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&minPrice=2&page=1',NULL,NULL,'2026-06-09 15:22:13'),
(1184,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 15:22:13'),
(1185,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=4',NULL,NULL,'2026-06-09 15:22:14'),
(1186,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&page=1',NULL,NULL,'2026-06-09 15:22:15'),
(1187,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1',NULL,NULL,'2026-06-09 15:22:15'),
(1188,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=15',NULL,NULL,'2026-06-09 15:22:15'),
(1189,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=150',NULL,NULL,'2026-06-09 15:22:16'),
(1190,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men&page=1&minPrice=1500',NULL,NULL,'2026-06-09 15:22:16'),
(1191,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:22:35'),
(1192,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 15:22:38'),
(1193,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:22:43'),
(1194,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 15:23:05'),
(1195,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/iuiii-1780933275521',NULL,NULL,'2026-06-09 15:23:20'),
(1196,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:23:21'),
(1197,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 15:23:22'),
(1198,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:23:24'),
(1199,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 15:23:26'),
(1200,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:24:02'),
(1201,'ddcac290-aa95-47a4-94f1-fcb293aed5ce','page_view','/',NULL,NULL,'2026-06-09 15:24:12'),
(1202,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 15:25:33'),
(1203,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:27:00'),
(1204,'5e27c4eb-dca0-4256-b22c-e05187dc2e4e','page_view','/',NULL,NULL,'2026-06-09 15:27:22'),
(1205,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 15:29:26'),
(1206,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 15:29:30'),
(1207,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 15:29:33'),
(1208,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 15:29:35'),
(1209,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:29:36'),
(1210,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/heavyweight-hoodie',NULL,NULL,'2026-06-09 15:29:40'),
(1211,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:29:42'),
(1212,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-09 15:29:46'),
(1213,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:29:58'),
(1214,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:30:08'),
(1215,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:30:21'),
(1216,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&gender=men',NULL,NULL,'2026-06-09 15:30:23'),
(1217,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&gender=women',NULL,NULL,'2026-06-09 15:30:27'),
(1218,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:30:28'),
(1219,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&gender=women',NULL,NULL,'2026-06-09 15:30:29'),
(1220,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:30:30'),
(1221,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/embroidered-denim-jacket',NULL,NULL,'2026-06-09 15:30:32'),
(1222,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:30:32'),
(1223,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:30:41'),
(1224,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:30:56'),
(1225,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:31:00'),
(1226,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:31:08'),
(1227,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/wishlist',NULL,NULL,'2026-06-09 15:31:24'),
(1228,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:31:41'),
(1229,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/orders',NULL,NULL,'2026-06-09 15:32:10'),
(1230,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:33:03'),
(1231,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:36:30'),
(1232,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=5',NULL,NULL,'2026-06-09 15:36:33'),
(1233,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=52',NULL,NULL,'2026-06-09 15:36:33'),
(1234,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=524',NULL,NULL,'2026-06-09 15:36:33'),
(1235,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=5245',NULL,NULL,'2026-06-09 15:36:33'),
(1236,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=52454',NULL,NULL,'2026-06-09 15:36:33'),
(1237,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=524545',NULL,NULL,'2026-06-09 15:36:34'),
(1238,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=5245454',NULL,NULL,'2026-06-09 15:36:34'),
(1239,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=52454548',NULL,NULL,'2026-06-09 15:36:34'),
(1240,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=524545484',NULL,NULL,'2026-06-09 15:36:34'),
(1241,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=5245454845',NULL,NULL,'2026-06-09 15:36:34'),
(1242,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1&minPrice=52454548455',NULL,NULL,'2026-06-09 15:36:34'),
(1243,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-09 15:37:10'),
(1244,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-09 15:37:11'),
(1245,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products',NULL,NULL,'2026-06-09 15:37:14'),
(1246,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=4&page=1',NULL,NULL,'2026-06-09 15:37:17'),
(1247,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=42&page=1',NULL,NULL,'2026-06-09 15:37:17'),
(1248,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=425&page=1',NULL,NULL,'2026-06-09 15:37:17'),
(1249,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=4254&page=1',NULL,NULL,'2026-06-09 15:37:17'),
(1250,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=42544&page=1',NULL,NULL,'2026-06-09 15:37:17'),
(1251,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=425445&page=1',NULL,NULL,'2026-06-09 15:37:17'),
(1252,'8f242bd1-0936-4a70-bedd-f25afd72fbe0','page_view','/products?minPrice=42&page=1',NULL,NULL,'2026-06-09 15:37:19'),
(1253,'d806bbc0-25f6-4ebd-b22a-dfa29e02326d','page_view','/products?minPrice=425&page=1',NULL,NULL,'2026-06-09 15:37:19'),
(1254,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 15:44:41'),
(1255,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 15:44:57'),
(1256,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 15:44:59'),
(1257,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 15:45:27'),
(1258,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=425445&page=1',NULL,NULL,'2026-06-09 15:46:28'),
(1259,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products',NULL,NULL,'2026-06-09 15:46:28'),
(1260,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=4&page=1',NULL,NULL,'2026-06-09 15:46:31'),
(1261,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=48&page=1',NULL,NULL,'2026-06-09 15:46:31'),
(1262,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?minPrice=4&page=1',NULL,NULL,'2026-06-09 15:46:32'),
(1263,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=1',NULL,NULL,'2026-06-09 15:46:32'),
(1264,'9cdf5dfe-ef1e-4d30-83cf-c65e4a478d08','page_view','/products?minPrice=48&page=1',NULL,NULL,'2026-06-09 15:46:33'),
(1265,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=2',NULL,NULL,'2026-06-09 15:46:37'),
(1266,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/signature-knit-sweater',NULL,NULL,'2026-06-09 15:48:19'),
(1267,'f256ac6a-a5b0-492b-bbc9-28c2d98795ba','page_view','/products/signature-knit-sweater',NULL,NULL,'2026-06-09 15:48:33'),
(1268,'edc939d8-9f1f-4247-826a-c0b4430a1bdc','page_view','/products/signature-knit-sweater',NULL,NULL,'2026-06-09 15:48:37'),
(1269,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:51:23'),
(1270,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 15:51:35'),
(1271,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:51:42'),
(1272,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-09 15:51:44'),
(1273,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:51:49'),
(1274,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 15:51:59'),
(1275,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 15:52:01'),
(1276,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?new_arrivals=true&gender=men&minPrice=54&maxPrice=214&page=1',NULL,NULL,'2026-06-09 15:52:08'),
(1277,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products',NULL,NULL,'2026-06-09 15:52:10'),
(1278,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/signature-knit-sweater',NULL,NULL,'2026-06-09 15:52:31'),
(1279,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/signature-knit-sweater',NULL,NULL,'2026-06-09 15:52:32'),
(1280,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/signature-knit-sweater',NULL,NULL,'2026-06-09 15:52:34'),
(1281,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/signature-knit-sweater',NULL,NULL,'2026-06-09 15:52:34'),
(1282,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=2',NULL,NULL,'2026-06-09 15:52:36'),
(1283,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/orders',NULL,NULL,'2026-06-09 15:52:37'),
(1284,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=2',NULL,NULL,'2026-06-09 15:52:37'),
(1285,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:52:40'),
(1286,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 15:52:54'),
(1287,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/iuiii-1780933275521',NULL,NULL,'2026-06-09 15:54:02'),
(1288,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:54:23'),
(1289,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products',NULL,NULL,'2026-06-09 15:54:47'),
(1290,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?minPrice=1&page=1',NULL,NULL,'2026-06-09 15:55:00'),
(1291,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:55:01'),
(1292,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:57:44'),
(1293,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:57:48'),
(1294,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/long-sleeve-shirt',NULL,NULL,'2026-06-09 15:57:53'),
(1295,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:58:09'),
(1296,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?nav=deals',NULL,NULL,'2026-06-09 15:58:52'),
(1297,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 15:58:54'),
(1298,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=2',NULL,NULL,'2026-06-09 15:59:55'),
(1299,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products?page=2',NULL,NULL,'2026-06-09 15:59:56'),
(1300,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-09 15:59:57'),
(1301,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-09 15:59:58'),
(1302,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products?nav=deals',NULL,NULL,'2026-06-09 16:01:09'),
(1303,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:01:23'),
(1304,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products',NULL,NULL,'2026-06-09 16:01:26'),
(1305,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 16:01:28'),
(1306,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 16:01:31'),
(1307,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/about',NULL,NULL,'2026-06-09 16:02:16'),
(1308,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 16:02:35'),
(1309,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:02:43'),
(1310,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/orders',NULL,NULL,'2026-06-09 16:02:44'),
(1311,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:02:45'),
(1312,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/wishlist',NULL,NULL,'2026-06-09 16:02:47'),
(1313,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:02:47'),
(1314,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/privacy',NULL,NULL,'2026-06-09 16:02:48'),
(1315,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:02:49'),
(1316,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/',NULL,NULL,'2026-06-09 16:02:49'),
(1317,'61a6f42a-ada4-4e30-879a-4fd971a6dc30','page_view','/about',NULL,NULL,'2026-06-09 16:02:51'),
(1318,'a021b6af-e765-4194-bbd6-afabdc251574','page_view','/about',NULL,NULL,'2026-06-09 16:02:51'),
(1319,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/terms',NULL,NULL,'2026-06-09 16:02:52'),
(1320,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:02:56'),
(1321,'6cc60d10-e340-48a1-a656-65b5d5f2e360','page_view','/privacy',NULL,NULL,'2026-06-09 16:02:57'),
(1322,'a7feb5b1-950e-4dc7-a323-b19af598a2f6','page_view','/privacy',NULL,NULL,'2026-06-09 16:02:58'),
(1323,'9de0606c-ee01-4871-91bd-48713eae8ce6','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 16:03:01'),
(1324,'1f467b9d-64cb-4354-b34f-758cea6d92ed','page_view','/terms',NULL,NULL,'2026-06-09 16:03:03'),
(1325,'f5bb767b-84a5-4751-944f-06f521263df3','page_view','/terms',NULL,NULL,'2026-06-09 16:03:03'),
(1326,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:05:24'),
(1327,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 16:05:28'),
(1328,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:05:34'),
(1329,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 16:05:53'),
(1330,'9d7f642c-57ae-4333-95f5-17507b2172d9','add_to_cart','/products/jjj-1780933364286',26,'{\"quantity\":1}','2026-06-09 16:05:54'),
(1331,'9d7f642c-57ae-4333-95f5-17507b2172d9','begin_checkout','/checkout',NULL,NULL,'2026-06-09 16:05:54'),
(1332,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/checkout',NULL,NULL,'2026-06-09 16:05:54'),
(1333,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 16:06:11'),
(1334,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:06:31'),
(1335,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:07:55'),
(1336,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-09 16:08:20'),
(1337,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/',NULL,NULL,'2026-06-09 16:08:21'),
(1338,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 16:08:26'),
(1339,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 16:12:37'),
(1340,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 16:21:09'),
(1341,'f5fc4640-c267-4b6b-86ae-6bbbdcd3800c','page_view','/',NULL,NULL,'2026-06-09 16:31:31'),
(1342,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAdGRleASVHzhleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA8xMjQwMjQ1NzQyODc0MTQAAadThUlfJ9LEVnZJFtkao9xNdcOZ-0KinGkfSoP8bqIVKqqDt3K29DOL0CGVKA_aem__5k6VfNzMslyU681BTXFGQ',NULL,NULL,'2026-06-09 16:31:41'),
(1343,'9c5fa2b3-f796-4c43-ad3a-cc1cbeb9bc47','page_view','/',NULL,NULL,'2026-06-09 16:32:09'),
(1344,'0cd2dab6-3486-481a-b85b-e665877dc211','page_view','/',NULL,NULL,'2026-06-09 16:33:01'),
(1345,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 16:43:49'),
(1346,'0109911e-3cc2-4dc9-8f36-32123b167cd7','page_view','/',NULL,NULL,'2026-06-09 17:49:42'),
(1347,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 17:50:54'),
(1348,'5b07a1ca-44b1-4254-bb6c-ba2352901a78','page_view','/',NULL,NULL,'2026-06-09 18:05:40'),
(1349,'91895a99-dccf-4bbc-9bd3-b926e508241a','page_view','/',NULL,NULL,'2026-06-09 18:06:36'),
(1350,'dfe13112-d065-4f48-bcb0-de04b1dab4e8','page_view','/',NULL,NULL,'2026-06-09 18:25:37'),
(1351,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 18:26:16'),
(1352,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 18:26:16'),
(1353,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 18:26:44'),
(1354,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/hyh-1780933430759',27,'{\"quantity\":5}','2026-06-09 18:26:47'),
(1355,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/hyh-1780933430759',27,'{\"quantity\":5}','2026-06-09 18:26:48'),
(1356,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/checkout',NULL,NULL,'2026-06-09 18:26:48'),
(1357,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','begin_checkout','/checkout',NULL,NULL,'2026-06-09 18:26:48'),
(1358,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 18:26:54'),
(1359,'61c74084-7036-401a-b873-915b3817e16d','page_view','/products?nav=brands&minPrice=54&page=1',NULL,NULL,'2026-06-09 18:48:38'),
(1360,'54fdcb0c-ac90-445f-9444-36c1abc317ec','page_view','/',NULL,NULL,'2026-06-09 19:09:07'),
(1361,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 19:23:04'),
(1362,'228c918c-5edd-41ad-9841-0f1b94843797','page_view','/',NULL,NULL,'2026-06-09 19:48:49'),
(1363,'bc653a7c-1205-4e3b-b6ca-bb13ccaf683a','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnali8dGQz1VJmuSLnNF6eFrvUOwa8iE5XOoPxy0VvC1nAKRsIiHfWA8j-gMA_aem_npMxds7nwVYR_MLmkmVN7A',NULL,NULL,'2026-06-09 20:01:13'),
(1364,'bc653a7c-1205-4e3b-b6ca-bb13ccaf683a','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 20:01:22'),
(1365,'bc653a7c-1205-4e3b-b6ca-bb13ccaf683a','page_view','/category/mens-clothing?page=2',NULL,NULL,'2026-06-09 20:01:25'),
(1366,'bc653a7c-1205-4e3b-b6ca-bb13ccaf683a','page_view','/category/mens-clothing?page=3',NULL,NULL,'2026-06-09 20:01:30'),
(1367,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:17:03'),
(1368,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:17:08'),
(1369,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:17:15'),
(1370,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:17:28'),
(1371,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 20:17:30'),
(1372,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:17:54'),
(1373,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:18:36'),
(1374,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?page=1',NULL,NULL,'2026-06-09 20:19:48'),
(1375,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 20:19:49'),
(1376,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 20:19:51'),
(1377,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:20:08'),
(1378,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 20:20:19'),
(1379,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/socks-sky',NULL,NULL,'2026-06-09 20:20:29'),
(1380,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:20:34'),
(1381,'52fb79aa-ebe9-4ae1-8c5b-31dd1ad13cd1','page_view','/',NULL,NULL,'2026-06-09 20:29:43'),
(1382,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 20:33:39'),
(1383,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 20:34:25'),
(1384,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:39:31'),
(1385,'97cdce09-db3d-4dd8-aa32-1fda3fc97dd8','page_view','/',NULL,NULL,'2026-06-09 20:40:52'),
(1386,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:41:01'),
(1387,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 20:41:40'),
(1388,'97cdce09-db3d-4dd8-aa32-1fda3fc97dd8','page_view','/products/premium-zip-hoodie',NULL,NULL,'2026-06-09 20:41:45'),
(1389,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:41:50'),
(1390,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 20:59:18'),
(1391,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 21:00:46'),
(1392,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products',NULL,NULL,'2026-06-09 21:00:49'),
(1393,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-09 21:00:50'),
(1394,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:00:51'),
(1395,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/login',NULL,NULL,'2026-06-09 21:10:29'),
(1396,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:10:37'),
(1397,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:10:38'),
(1398,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:10:38'),
(1399,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/login',NULL,NULL,'2026-06-09 21:11:11'),
(1400,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:11:38'),
(1401,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:13:06'),
(1402,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/straight-leg-denim',NULL,NULL,'2026-06-09 21:13:50'),
(1403,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:15:58'),
(1404,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:16:34'),
(1405,'83d03ae5-37f8-4881-b206-c1e2f85619d8','page_view','/products/premium-zip-hoodie',NULL,NULL,'2026-06-09 21:16:40'),
(1406,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:18:51'),
(1407,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/uuu-1781039570104',NULL,NULL,'2026-06-09 21:23:59'),
(1408,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:24:01'),
(1409,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:24:27'),
(1410,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:24:58'),
(1411,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:26:42'),
(1412,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:27:14'),
(1413,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:29:21'),
(1414,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/about',NULL,NULL,'2026-06-09 21:30:08'),
(1415,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:31:11'),
(1416,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:31:11'),
(1417,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:31:28'),
(1418,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:32:09'),
(1419,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 21:32:16'),
(1420,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:32:39'),
(1421,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/huhh-1780933306363',NULL,NULL,'2026-06-09 21:32:40'),
(1422,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/checkout',NULL,NULL,'2026-06-09 21:32:46'),
(1423,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:32:46'),
(1424,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:32:56'),
(1425,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/uuu-1781039570104',NULL,NULL,'2026-06-09 21:32:58'),
(1426,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:33:00'),
(1427,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/hyh-1780933430759',NULL,NULL,'2026-06-09 21:33:01'),
(1428,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:33:02'),
(1429,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 21:33:03'),
(1430,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:33:04'),
(1431,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 21:33:06'),
(1432,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:33:06'),
(1433,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 21:33:41'),
(1434,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-09 21:33:44'),
(1435,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:33:50'),
(1436,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 21:34:44'),
(1437,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 21:34:49'),
(1438,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 21:34:57'),
(1439,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/relaxed-fit-tee',NULL,NULL,'2026-06-09 21:35:00'),
(1440,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 21:35:02'),
(1441,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:35:07'),
(1442,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 21:35:09'),
(1443,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/',NULL,NULL,'2026-06-09 21:35:25'),
(1444,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/products',NULL,NULL,'2026-06-09 21:35:29'),
(1445,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 21:35:35'),
(1446,'0be87f4c-9850-4bc8-82fd-22e503253dfb','page_view','/',NULL,NULL,'2026-06-09 21:35:43'),
(1447,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/wishlist',NULL,NULL,'2026-06-09 21:35:46'),
(1448,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:35:49'),
(1449,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?nav=trending',NULL,NULL,'2026-06-09 21:36:18'),
(1450,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/',NULL,NULL,'2026-06-09 21:36:20'),
(1451,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products',NULL,NULL,'2026-06-09 21:36:20'),
(1452,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnYNidTGYIvWfi0cx_umnzhlS0r61VY-iUQWUk-zciFVIQbXn1RtT7q_rVpms_aem_x3S2Su5B2A-U86uJEZBuTA',NULL,NULL,'2026-06-09 21:36:21'),
(1453,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 21:36:23'),
(1454,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 21:36:24'),
(1455,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/products/uuu-1781039570104',NULL,NULL,'2026-06-09 21:36:25'),
(1456,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnYNidTGYIvWfi0cx_umnzhlS0r61VY-iUQWUk-zciFVIQbXn1RtT7q_rVpms_aem_x3S2Su5B2A-U86uJEZBuTA',NULL,NULL,'2026-06-09 21:36:27'),
(1457,'68b2c010-c63d-459a-b73e-1af25b83830c','add_to_cart','/products/jjj-1780933364286',26,'{\"quantity\":1}','2026-06-09 21:36:28'),
(1458,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/checkout',NULL,NULL,'2026-06-09 21:36:28'),
(1459,'68b2c010-c63d-459a-b73e-1af25b83830c','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:36:28'),
(1460,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 21:36:36'),
(1461,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-09 21:36:36'),
(1462,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 21:36:39'),
(1463,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/uuu-1781039570104',NULL,NULL,'2026-06-09 21:37:07'),
(1464,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-09 21:37:09'),
(1465,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 21:37:19'),
(1466,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-09 21:37:22'),
(1467,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/products/uuu-1781039570104',NULL,NULL,'2026-06-09 21:37:23'),
(1468,'50e12dd0-b1af-4405-bd56-b3f240c4934e','add_to_cart','/products/uuu-1781039570104',30,'{\"quantity\":2}','2026-06-09 21:37:26'),
(1469,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/checkout',NULL,NULL,'2026-06-09 21:37:26'),
(1470,'50e12dd0-b1af-4405-bd56-b3f240c4934e','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:37:26'),
(1471,'68b2c010-c63d-459a-b73e-1af25b83830c','purchase','/checkout',NULL,'{\"order_id\":7,\"total\":517.5}','2026-06-09 21:37:29'),
(1472,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/order-confirmed/MW-1781041048219-d1d173b198fe',NULL,NULL,'2026-06-09 21:37:29'),
(1473,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 21:40:38'),
(1474,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','add_to_cart','/products/off-white-teeshirt-1780930281053',22,'{\"quantity\":1}','2026-06-09 21:41:50'),
(1475,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/products/embroidered-denim-jacket',NULL,NULL,'2026-06-09 21:41:53'),
(1476,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/checkout',NULL,NULL,'2026-06-09 21:41:54'),
(1477,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:41:54'),
(1478,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/checkout',NULL,NULL,'2026-06-09 21:42:00'),
(1479,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:42:00'),
(1480,'17c332ea-d6c8-45d2-8a57-ecc728f06082','add_to_cart','/products/embroidered-denim-jacket',9,'{\"quantity\":5}','2026-06-09 21:42:03'),
(1481,'17c332ea-d6c8-45d2-8a57-ecc728f06082','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:42:03'),
(1482,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/checkout',NULL,NULL,'2026-06-09 21:42:03'),
(1483,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/checkout',NULL,NULL,'2026-06-09 21:42:15'),
(1484,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:42:15'),
(1485,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 21:43:29'),
(1486,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:43:30'),
(1487,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:44:22'),
(1488,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:44:57'),
(1489,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:45:44'),
(1490,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products?nav=brands',NULL,NULL,'2026-06-09 21:46:49'),
(1491,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/off-white-teeshirt-1780930281053',NULL,NULL,'2026-06-09 21:46:51'),
(1492,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/checkout',NULL,NULL,'2026-06-09 21:47:05'),
(1493,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/products/jjj-1780933364286',NULL,NULL,'2026-06-09 21:47:05'),
(1494,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/',NULL,NULL,'2026-06-09 21:47:06'),
(1495,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 21:48:33'),
(1496,'50e12dd0-b1af-4405-bd56-b3f240c4934e','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnYNidTGYIvWfi0cx_umnzhlS0r61VY-iUQWUk-zciFVIQbXn1RtT7q_rVpms_aem_x3S2Su5B2A-U86uJEZBuTA',NULL,NULL,'2026-06-09 21:48:44'),
(1497,'52d413b8-64c0-49a1-8157-c3f05a2c03b6','page_view','/products/long-sleeve-shirt',NULL,NULL,'2026-06-09 21:48:55'),
(1498,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/checkout',NULL,NULL,'2026-06-09 21:49:31'),
(1499,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:49:31'),
(1500,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/checkout',NULL,NULL,'2026-06-09 21:49:34'),
(1501,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:49:34'),
(1502,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/checkout',NULL,NULL,'2026-06-09 21:49:54'),
(1503,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:49:54'),
(1504,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/checkout',NULL,NULL,'2026-06-09 21:52:34'),
(1505,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','begin_checkout','/checkout',NULL,NULL,'2026-06-09 21:52:34'),
(1506,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 21:53:43'),
(1507,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 21:54:01'),
(1508,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 21:55:23'),
(1509,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:55:30'),
(1510,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:55:34'),
(1511,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 21:55:40'),
(1512,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/a-1781042116120',NULL,NULL,'2026-06-09 21:57:03'),
(1513,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 21:57:12'),
(1514,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-09 21:59:35'),
(1515,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:59:44'),
(1516,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 21:59:44'),
(1517,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/h-1781020659296',NULL,NULL,'2026-06-09 22:00:38'),
(1518,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products',NULL,NULL,'2026-06-09 22:00:39'),
(1519,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/a-1781042116120',NULL,NULL,'2026-06-09 22:00:41'),
(1520,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/',NULL,NULL,'2026-06-09 22:01:40'),
(1521,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/products/premium-zip-hoodie',NULL,NULL,'2026-06-09 22:03:17'),
(1522,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/',NULL,NULL,'2026-06-09 22:03:33'),
(1523,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 22:04:01'),
(1524,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 22:09:22'),
(1525,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/products/a-1781042116120',NULL,NULL,'2026-06-09 22:10:52'),
(1526,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 22:11:21'),
(1527,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-09 22:11:26'),
(1528,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing',NULL,NULL,'2026-06-09 22:11:34'),
(1529,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-09 22:11:34'),
(1530,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 22:11:38'),
(1531,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-09 22:11:43'),
(1532,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-09 22:11:43'),
(1533,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-09 22:11:45'),
(1534,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 22:46:41'),
(1535,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 22:46:44'),
(1536,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 22:47:59'),
(1537,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 22:48:33'),
(1538,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-09 23:06:32'),
(1539,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 23:13:51'),
(1540,'499ab9a6-9080-41f1-af53-4c7e85a3f15d','page_view','/',NULL,NULL,'2026-06-09 23:43:28'),
(1541,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 23:47:03'),
(1542,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-09 23:47:06'),
(1543,'25066b7a-73e1-4f82-9220-33d7eed3a423','page_view','/',NULL,NULL,'2026-06-09 23:58:13'),
(1544,'s-1781049504266-xv4klumyw','page_view','/',NULL,NULL,'2026-06-09 23:58:24'),
(1545,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/',NULL,NULL,'2026-06-10 00:00:00'),
(1546,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/category/mens-clothing',NULL,NULL,'2026-06-10 00:00:05'),
(1547,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-10 00:00:06'),
(1548,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-10 00:07:01'),
(1549,'68b2c010-c63d-459a-b73e-1af25b83830c','page_view','/',NULL,NULL,'2026-06-10 00:14:32'),
(1550,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-10 00:24:14'),
(1551,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 00:24:56'),
(1552,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 00:24:58'),
(1553,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/',NULL,NULL,'2026-06-10 00:25:13'),
(1554,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/products/a-1781042116120',NULL,NULL,'2026-06-10 00:25:19'),
(1555,'7384018e-2e78-40e4-8624-2f3d23544628','add_to_cart','/products/a-1781042116120',31,'{\"quantity\":1}','2026-06-10 00:25:39'),
(1556,'7384018e-2e78-40e4-8624-2f3d23544628','add_to_cart','/products/a-1781042116120',31,'{\"quantity\":1}','2026-06-10 00:25:59'),
(1557,'7384018e-2e78-40e4-8624-2f3d23544628','begin_checkout','/checkout',NULL,NULL,'2026-06-10 00:25:59'),
(1558,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/checkout',NULL,NULL,'2026-06-10 00:25:59'),
(1559,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/products/a-1781042116120',NULL,NULL,'2026-06-10 00:26:07'),
(1560,'7384018e-2e78-40e4-8624-2f3d23544628','add_to_cart','/products/a-1781042116120',31,'{\"quantity\":1}','2026-06-10 00:26:09'),
(1561,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/checkout',NULL,NULL,'2026-06-10 00:26:09'),
(1562,'7384018e-2e78-40e4-8624-2f3d23544628','begin_checkout','/checkout',NULL,NULL,'2026-06-10 00:26:09'),
(1563,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/',NULL,NULL,'2026-06-10 00:26:41'),
(1564,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/products/hhh-1780933335938',NULL,NULL,'2026-06-10 00:26:43'),
(1565,'7384018e-2e78-40e4-8624-2f3d23544628','add_to_cart','/products/hhh-1780933335938',25,'{\"quantity\":1}','2026-06-10 00:26:45'),
(1566,'7384018e-2e78-40e4-8624-2f3d23544628','add_to_cart','/products/hhh-1780933335938',25,'{\"quantity\":1}','2026-06-10 00:26:47'),
(1567,'7384018e-2e78-40e4-8624-2f3d23544628','begin_checkout','/checkout',NULL,NULL,'2026-06-10 00:26:47'),
(1568,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/checkout',NULL,NULL,'2026-06-10 00:26:47'),
(1569,'7384018e-2e78-40e4-8624-2f3d23544628','purchase','/checkout',NULL,'{\"order_id\":8,\"total\":1364}','2026-06-10 00:27:29'),
(1570,'7384018e-2e78-40e4-8624-2f3d23544628','page_view','/order-confirmed/MW-1781051249332-8a18fe85f987',NULL,NULL,'2026-06-10 00:27:30'),
(1571,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 00:43:54'),
(1572,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:44:08'),
(1573,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 00:44:13'),
(1574,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 00:52:21'),
(1575,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/category/mens-clothing',NULL,NULL,'2026-06-10 00:52:33'),
(1576,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-10 00:52:33'),
(1577,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 00:52:35'),
(1578,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jersey-crewneck-t-shirt-and-short-1781052738383',NULL,NULL,'2026-06-10 00:52:38'),
(1579,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 00:52:39'),
(1580,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-10 00:52:41'),
(1581,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=2000&page=1',NULL,NULL,'2026-06-10 00:52:47'),
(1582,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=2000&page=1&maxPrice=2500',NULL,NULL,'2026-06-10 00:52:58'),
(1583,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=2000&page=1&maxPrice=2100',NULL,NULL,'2026-06-10 00:53:04'),
(1584,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=2000&page=1&maxPrice=2100&best_sellers=true',NULL,NULL,'2026-06-10 00:53:11'),
(1585,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&minPrice=2000&page=1&maxPrice=2100&best_sellers=true&on_sale=true',NULL,NULL,'2026-06-10 00:53:11'),
(1586,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 00:53:16'),
(1587,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1',NULL,NULL,'2026-06-10 00:53:21'),
(1588,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3000',NULL,NULL,'2026-06-10 00:53:47'),
(1589,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:53:57'),
(1590,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:55:22'),
(1591,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:23'),
(1592,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:55:26'),
(1593,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:28'),
(1594,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jersey-crewneck-t-shirt-and-short-1781052738383',NULL,NULL,'2026-06-10 00:55:29'),
(1595,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:30'),
(1596,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jersey-crewneck-t-shirt-and-short-1781052738383',NULL,NULL,'2026-06-10 00:55:31'),
(1597,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:31'),
(1598,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:55:32'),
(1599,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:33'),
(1600,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:55:34'),
(1601,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:35'),
(1602,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:55:36'),
(1603,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:37'),
(1604,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:55:43'),
(1605,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:44'),
(1606,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:55:46'),
(1607,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:55:47'),
(1608,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:56:22'),
(1609,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:56:23'),
(1610,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:56:25'),
(1611,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:56:26'),
(1612,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jersey-crewneck-t-shirt-and-short-1781052738383',NULL,NULL,'2026-06-10 00:56:27'),
(1613,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:56:28'),
(1614,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:56:37'),
(1615,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:56:38'),
(1616,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:56:40'),
(1617,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:56:41'),
(1618,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jersey-crewneck-t-shirt-and-short-1781052738383',NULL,NULL,'2026-06-10 00:56:42'),
(1619,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:56:43'),
(1620,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:57:35'),
(1621,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/louis-vuitton-cotton-cashmere-short-sleeved-crewneck-1781052190199',NULL,NULL,'2026-06-10 00:57:35'),
(1622,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:57:36'),
(1623,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/jersey-crewneck-t-shirt-and-short-1781052738383',NULL,NULL,'2026-06-10 00:57:37'),
(1624,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?sort=price_asc&page=1&minPrice=2000&maxPrice=3800',NULL,NULL,'2026-06-10 00:57:37'),
(1625,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:01:49'),
(1626,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:01:53'),
(1627,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:09:36'),
(1628,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:17:05'),
(1629,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 01:17:22'),
(1630,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:17:24'),
(1631,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/straight-leg-denim',NULL,NULL,'2026-06-10 01:17:25'),
(1632,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:17:26'),
(1633,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/straight-leg-denim',NULL,NULL,'2026-06-10 01:17:32'),
(1634,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:17:34'),
(1635,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/embroidered-denim-jacket',NULL,NULL,'2026-06-10 01:17:36'),
(1636,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:17:37'),
(1637,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/red-leather-sneakers',NULL,NULL,'2026-06-10 01:17:38'),
(1638,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:17:39'),
(1639,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-10 01:21:16'),
(1640,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-10 01:21:22'),
(1641,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:21:34'),
(1642,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:29:13'),
(1643,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-10 01:29:24'),
(1644,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/gucci-cotton-knit-polo-shirt-1781054221240',NULL,NULL,'2026-06-10 01:29:32'),
(1645,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-10 01:29:46'),
(1646,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/gucci-cotton-knit-polo-shirt-1781054221240',NULL,NULL,'2026-06-10 01:29:55'),
(1647,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-10 01:30:32'),
(1648,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/off-white-arrows-t-shirt-1781053303270',NULL,NULL,'2026-06-10 01:31:39'),
(1649,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:43:00'),
(1650,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:44:19'),
(1651,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/ami-paris-short-sleeves-t-shirt-1781055706642',NULL,NULL,'2026-06-10 01:44:26'),
(1652,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:44:47'),
(1653,'988de8f3-b1e8-4ba2-8d7b-1f6c0b240286','page_view','/',NULL,NULL,'2026-06-10 01:55:02'),
(1654,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:57:39'),
(1655,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/lv-blason-embroidered-short-sleeved-crewneck-1781056504674',NULL,NULL,'2026-06-10 01:57:44'),
(1656,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/lv-blason-embroidered-short-sleeved-crewneck-1781056504674',NULL,NULL,'2026-06-10 01:58:07'),
(1657,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 01:58:19'),
(1658,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:02:30'),
(1659,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:04:05'),
(1660,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/ami-paris-short-sleeves-t-shirt-1781056939762',NULL,NULL,'2026-06-10 02:04:17'),
(1661,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:15:21'),
(1662,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/gucci-terry-knit-polo-1781057716343',NULL,NULL,'2026-06-10 02:15:35'),
(1663,'17c332ea-d6c8-45d2-8a57-ecc728f06082','page_view','/',NULL,NULL,'2026-06-10 02:16:39'),
(1664,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:19:31'),
(1665,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/gucci-terry-knit-polo-1781057716343',NULL,NULL,'2026-06-10 02:19:44'),
(1666,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:38:26'),
(1667,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/gucci-men-s-navy-polo-shirt-1781059098580',NULL,NULL,'2026-06-10 02:38:31'),
(1668,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:39:16'),
(1669,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-10 02:39:22'),
(1670,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/ami-paris-short-sleeves-t-shirt-1781056939762',NULL,NULL,'2026-06-10 02:39:27'),
(1671,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:48:22'),
(1672,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/dior-t-shirt-with-pocket-relaxed-fit-1781059686092',NULL,NULL,'2026-06-10 02:48:24'),
(1673,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:48:27'),
(1674,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:48:30'),
(1675,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:49:15'),
(1676,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:50:09'),
(1677,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:50:58'),
(1678,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:51:16'),
(1679,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 02:51:49'),
(1680,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:51:59'),
(1681,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 02:58:12'),
(1682,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:03:32'),
(1683,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:04:05'),
(1684,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 03:04:11'),
(1685,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:04:14'),
(1686,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/gucci-men-s-navy-polo-shirt-1781059098580',NULL,NULL,'2026-06-10 03:04:15'),
(1687,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:04:28'),
(1688,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 03:04:30'),
(1689,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 03:06:07'),
(1690,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:06:12'),
(1691,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 03:06:19'),
(1692,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:06:21'),
(1693,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/category/mens-clothing',NULL,NULL,'2026-06-10 03:06:27'),
(1694,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-10 03:06:27'),
(1695,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:06:28'),
(1696,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 03:06:50'),
(1697,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:06:53'),
(1698,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:07:10'),
(1699,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:07:30'),
(1700,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:07:49'),
(1701,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:08:01'),
(1702,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:10:37'),
(1703,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:10:45'),
(1704,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 03:11:01'),
(1705,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:11:02'),
(1706,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/ami-paris-short-sleeves-t-shirt-1781056939762',NULL,NULL,'2026-06-10 03:11:03'),
(1707,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:11:03'),
(1708,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/ami-paris-short-sleeves-t-shirt-1781055706642',NULL,NULL,'2026-06-10 03:11:04'),
(1709,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:11:05'),
(1710,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/lv-blason-embroidered-short-sleeved-crewneck-1781056504674',NULL,NULL,'2026-06-10 03:11:06'),
(1711,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:11:07'),
(1712,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/off-white-arrows-t-shirt-1781053303270',NULL,NULL,'2026-06-10 03:11:08'),
(1713,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:11:09'),
(1714,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:11:12'),
(1715,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 03:11:16'),
(1716,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:11:19'),
(1717,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:20:43'),
(1718,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=trending',NULL,NULL,'2026-06-10 03:23:40'),
(1719,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=trending',NULL,NULL,'2026-06-10 03:24:07'),
(1720,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=trending',NULL,NULL,'2026-06-10 03:24:08'),
(1721,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=trending',NULL,NULL,'2026-06-10 03:24:10'),
(1722,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=trending',NULL,NULL,'2026-06-10 03:24:19'),
(1723,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=trending',NULL,NULL,'2026-06-10 03:24:55'),
(1724,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?nav=trending',NULL,NULL,'2026-06-10 03:25:12'),
(1725,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:25:19'),
(1726,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?minPrice=2000&maxPrice=3000&page=1',NULL,NULL,'2026-06-10 03:25:33'),
(1727,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:25:40'),
(1728,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:33:05'),
(1729,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:34:23'),
(1730,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/represent-banner-t-shirt-1781062377828',NULL,NULL,'2026-06-10 03:34:28'),
(1731,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:34:29'),
(1732,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/represent-banner-t-shirt-1781062377828',NULL,NULL,'2026-06-10 03:34:32'),
(1733,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/represent-banner-t-shirt-1781062377828',48,'{\"quantity\":1}','2026-06-10 03:34:49'),
(1734,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/represent-banner-t-shirt-1781062377828',48,'{\"quantity\":1}','2026-06-10 03:34:50'),
(1735,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/checkout',NULL,NULL,'2026-06-10 03:34:50'),
(1736,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','begin_checkout','/checkout',NULL,NULL,'2026-06-10 03:34:50'),
(1737,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/represent-banner-t-shirt-1781062377828',NULL,NULL,'2026-06-10 03:35:23'),
(1738,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products',NULL,NULL,'2026-06-10 03:35:25'),
(1739,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:35:27'),
(1740,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/long-sleeve-shirt',NULL,NULL,'2026-06-10 03:36:25'),
(1741,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:36:27'),
(1742,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:43:37'),
(1743,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/amiri-black-chateau-script-t-shirt-1781063011206',NULL,NULL,'2026-06-10 03:43:43'),
(1744,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:43:50'),
(1745,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/amiri-black-chateau-script-t-shirt-1781063011206',NULL,NULL,'2026-06-10 03:43:52'),
(1746,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:44:01'),
(1747,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/amiri-black-chateau-script-t-shirt-1781063011206',NULL,NULL,'2026-06-10 03:44:04'),
(1748,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:44:11'),
(1749,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 03:44:18'),
(1750,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 03:44:29'),
(1751,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:44:34'),
(1752,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:44:42'),
(1753,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 03:44:55'),
(1754,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/acne-studios-1781061637032',NULL,NULL,'2026-06-10 03:44:56'),
(1755,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 03:45:03'),
(1756,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/acne-studios-1781061637032',NULL,NULL,'2026-06-10 03:45:05'),
(1757,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 03:45:09'),
(1758,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:45:11'),
(1759,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/s-1781059851988',NULL,NULL,'2026-06-10 03:45:42'),
(1760,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/products/s-1781059851988',46,'{\"quantity\":1}','2026-06-10 03:45:45'),
(1761,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:45:47'),
(1762,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/',47,'{\"quantity\":1}','2026-06-10 03:45:49'),
(1763,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/amiri-black-chateau-script-t-shirt-1781063011206',NULL,NULL,'2026-06-10 03:45:50'),
(1764,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:45:51'),
(1765,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/represent-banner-t-shirt-1781062377828',NULL,NULL,'2026-06-10 03:45:52'),
(1766,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:45:53'),
(1767,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/',46,'{\"quantity\":1}','2026-06-10 03:46:01'),
(1768,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/ami-paris-short-sleeves-t-shirt-1781055706642',NULL,NULL,'2026-06-10 03:46:09'),
(1769,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','add_to_cart','/',38,'{\"quantity\":1}','2026-06-10 03:46:11'),
(1770,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/lv-blason-embroidered-short-sleeved-crewneck-1781056504674',NULL,NULL,'2026-06-10 03:46:13'),
(1771,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:54:58'),
(1772,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:55:25'),
(1773,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?on_sale=true',NULL,NULL,'2026-06-10 03:55:53'),
(1774,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:56:00'),
(1775,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-10 03:56:05'),
(1776,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&maxPrice=2000&page=1',NULL,NULL,'2026-06-10 03:56:23'),
(1777,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&maxPrice=3000&page=1',NULL,NULL,'2026-06-10 03:56:28'),
(1778,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products/represent-banner-t-shirt-1781062377828',NULL,NULL,'2026-06-10 03:56:35'),
(1779,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:56:55'),
(1780,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 03:58:52'),
(1781,'b6626c68-e8c1-4058-88fb-c28c1b46243f','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnyPhylJhStm6G9kkSCChQzBchQKO67juU6gOm9k_laW9okdfCQN_4QIOqtmc_aem_TVgeZLka_K5JSQCYl6MwrQ',NULL,NULL,'2026-06-10 04:51:42'),
(1782,'b6626c68-e8c1-4058-88fb-c28c1b46243f','page_view','/products/amiri-black-chateau-script-t-shirt-1781063011206',NULL,NULL,'2026-06-10 04:53:06'),
(1783,'b6626c68-e8c1-4058-88fb-c28c1b46243f','page_view','/',NULL,NULL,'2026-06-10 04:53:28'),
(1784,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAdGRleASVzRxleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA8xMjQwMjQ1NzQyODc0MTQAAafI-HKUmFK2bob2SRIIKFDMFyFAo7ruO5TqA6b2T-Vpb2iR18JA3_hAg6q2Zw_aem_TVgeZLka_K5JSQCYl6MwrQ',NULL,NULL,'2026-06-10 04:53:35'),
(1785,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men',NULL,NULL,'2026-06-10 04:53:47'),
(1786,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/products?new_arrivals=true&gender=men&page=2',NULL,NULL,'2026-06-10 04:53:53'),
(1787,'e5710b25-5372-4d8e-a9a9-8a59c47475b5','page_view','/',NULL,NULL,'2026-06-10 04:53:57'),
(1788,'b6626c68-e8c1-4058-88fb-c28c1b46243f','page_view','/',NULL,NULL,'2026-06-10 04:55:46'),
(1789,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/category/mens-clothing?category=2',NULL,NULL,'2026-06-10 05:00:13'),
(1790,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-10 05:00:17'),
(1791,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/amiri-black-chateau-script-t-shirt-1781063011206',NULL,NULL,'2026-06-10 05:00:25'),
(1792,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/',NULL,NULL,'2026-06-10 05:00:46'),
(1793,'9d7f642c-57ae-4333-95f5-17507b2172d9','page_view','/products/represent-banner-t-shirt-1781062377828',NULL,NULL,'2026-06-10 05:00:48'),
(1794,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a','page_view','/',NULL,NULL,'2026-06-10 07:30:30');
/*!40000 ALTER TABLE `store_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_sessions`
--

DROP TABLE IF EXISTS `store_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `referrer` varchar(500) DEFAULT NULL,
  `utm_source` varchar(100) DEFAULT NULL,
  `utm_medium` varchar(100) DEFAULT NULL,
  `utm_campaign` varchar(100) DEFAULT NULL,
  `device_type` varchar(20) NOT NULL DEFAULT 'other',
  `country` varchar(80) DEFAULT NULL,
  `city` varchar(80) DEFAULT NULL,
  `landing_path` varchar(300) DEFAULT NULL,
  `started_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_seen_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_id` (`session_id`),
  KEY `idx_store_sessions_started` (`started_at`),
  KEY `idx_store_sessions_device` (`device_type`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_sessions`
--

LOCK TABLES `store_sessions` WRITE;
/*!40000 ALTER TABLE `store_sessions` DISABLE KEYS */;
INSERT INTO `store_sessions` VALUES
(1,'7b8ab818-7dce-4e10-97f3-5d5ec3e48480',1,'https://theboutiqueline.com/admin/products',NULL,NULL,NULL,'desktop','EG',NULL,'/','2026-06-08 14:33:52','2026-06-08 15:48:58','2026-06-08 14:33:52','2026-06-08 15:48:58'),
(2,'6aa28560-464a-410b-a826-80613e149a31',NULL,NULL,NULL,NULL,NULL,'desktop',NULL,NULL,'/','2026-06-08 14:40:40','2026-06-08 14:40:40','2026-06-08 14:40:40','2026-06-08 14:40:40'),
(3,'5d05081b-1eb2-44e6-bec3-c2f0099b012e',1,NULL,NULL,NULL,NULL,'desktop','EG',NULL,'/','2026-06-08 14:41:44','2026-06-09 13:22:21','2026-06-08 14:41:44','2026-06-09 13:22:21'),
(4,'e5710b25-5372-4d8e-a9a9-8a59c47475b5',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/','2026-06-08 14:47:20','2026-06-10 04:53:57','2026-06-08 14:47:20','2026-06-10 04:53:57'),
(5,'9d7f642c-57ae-4333-95f5-17507b2172d9',1,'https://theboutiqueline.com/',NULL,NULL,NULL,'mobile','EG',NULL,'/category/mens-clothing','2026-06-08 14:51:46','2026-06-10 05:00:48','2026-06-08 14:51:46','2026-06-10 05:00:48'),
(6,'52d413b8-64c0-49a1-8157-c3f05a2c03b6',NULL,'https://theboutiqueline.com/products?minPrice=16&page=1&maxPrice=2000',NULL,NULL,NULL,'mobile','EG',NULL,'/','2026-06-08 14:57:28','2026-06-09 21:48:55','2026-06-08 14:57:28','2026-06-09 21:48:55'),
(7,'0e7ff701-5e95-4a1a-8d9b-55987d8afa2c',2,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/','2026-06-08 15:12:19','2026-06-10 00:00:06','2026-06-08 15:12:19','2026-06-10 00:00:06'),
(8,'3e7a1e59-72d0-49fd-9acf-72ffcebbb139',4,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/','2026-06-08 15:13:56','2026-06-09 14:45:12','2026-06-08 15:13:56','2026-06-09 14:45:12'),
(9,'e568221b-69f1-4138-b7c6-5bf4a0b46b9e',NULL,NULL,NULL,NULL,NULL,'other',NULL,NULL,'/','2026-06-08 15:14:24','2026-06-08 15:14:24','2026-06-08 15:14:24','2026-06-08 15:14:24'),
(10,'26d5a644-e3bd-40ba-be59-c4edfda2afe7',NULL,NULL,NULL,NULL,NULL,'mobile',NULL,NULL,'/','2026-06-08 15:14:28','2026-06-08 15:26:41','2026-06-08 15:14:28','2026-06-08 15:26:41'),
(11,'f493a00b-8122-46b0-ac13-8fe9edb474eb',NULL,NULL,NULL,NULL,NULL,'desktop',NULL,NULL,'/','2026-06-08 15:14:49','2026-06-08 15:24:57','2026-06-08 15:14:49','2026-06-08 15:24:57'),
(12,'684e2c42-0607-49fe-b69c-3339ad6a474c',NULL,NULL,NULL,NULL,NULL,'mobile',NULL,NULL,'/products/premium-zip-hoodie','2026-06-08 15:15:03','2026-06-08 15:15:03','2026-06-08 15:15:03','2026-06-08 15:15:03'),
(13,'903483a4-2e45-4372-9417-dd6eb1914b93',NULL,NULL,NULL,NULL,NULL,'other',NULL,NULL,'/products/premium-zip-hoodie','2026-06-08 15:15:06','2026-06-08 15:15:06','2026-06-08 15:15:06','2026-06-08 15:15:06'),
(14,'21cbef70-5598-4afe-a8bb-b9108b8aaac1',NULL,NULL,NULL,NULL,NULL,'other',NULL,NULL,'/login','2026-06-08 15:15:14','2026-06-08 15:15:14','2026-06-08 15:15:14','2026-06-08 15:15:14'),
(15,'669be8f0-1975-49f9-a27c-c9c7aba463b4',NULL,NULL,NULL,NULL,NULL,'mobile',NULL,NULL,'/login','2026-06-08 15:15:15','2026-06-08 15:15:15','2026-06-08 15:15:15','2026-06-08 15:15:15'),
(16,'182a863d-daf3-474d-b897-5fad62ad5c4b',NULL,NULL,NULL,NULL,NULL,'other',NULL,NULL,'/products/wide-jeans','2026-06-08 15:15:34','2026-06-08 15:15:34','2026-06-08 15:15:34','2026-06-08 15:15:34'),
(17,'90542a8e-e6d3-4c1e-aff5-f06cfab806a1',NULL,NULL,NULL,NULL,NULL,'mobile',NULL,NULL,'/products/wide-jeans','2026-06-08 15:15:38','2026-06-08 15:15:38','2026-06-08 15:15:38','2026-06-08 15:15:38'),
(18,'834b787e-b38a-47e3-8a9e-d57a56efca94',NULL,NULL,NULL,NULL,NULL,'other',NULL,NULL,'/products','2026-06-08 15:17:28','2026-06-08 15:17:28','2026-06-08 15:17:28','2026-06-08 15:17:28'),
(19,'729934de-41b2-408c-87a8-1f6366a0b9d2',NULL,NULL,NULL,NULL,NULL,'mobile',NULL,NULL,'/products','2026-06-08 15:17:29','2026-06-08 15:17:29','2026-06-08 15:17:29','2026-06-08 15:17:29'),
(20,'1b1b48fa-ff2b-4e66-a7df-83247701065d',NULL,NULL,NULL,NULL,NULL,'mobile',NULL,NULL,'/products?new_arrivals=true&gender=men','2026-06-08 15:23:14','2026-06-08 15:23:14','2026-06-08 15:23:14','2026-06-08 15:23:14'),
(21,'f6b7c8b3-f144-4fa2-8041-c5b56b401ca5',NULL,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/','2026-06-08 15:23:14','2026-06-09 10:16:48','2026-06-08 15:23:14','2026-06-09 10:16:48'),
(22,'06540287-1ac4-4c81-be42-93677ea5a3da',NULL,NULL,NULL,NULL,NULL,'tablet',NULL,NULL,'/','2026-06-08 15:24:01','2026-06-08 15:24:01','2026-06-08 15:24:01','2026-06-08 15:24:01'),
(23,'9c724d92-844c-4c49-8831-f0965d6e84d7',NULL,NULL,NULL,NULL,NULL,'mobile',NULL,NULL,'/','2026-06-08 15:26:08','2026-06-08 15:26:08','2026-06-08 15:26:08','2026-06-08 15:26:08'),
(24,'54fdcb0c-ac90-445f-9444-36c1abc317ec',NULL,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/','2026-06-08 15:27:33','2026-06-09 19:09:07','2026-06-08 15:27:33','2026-06-09 19:09:07'),
(25,'0f9979de-4ca1-4c99-9c57-0141e469bd89',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile',NULL,NULL,'/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnxOClEnArb2-pTmTf9qK9edYR57xFJKSYoCYhCF3FlV81FAokCr4EnpnUzJs_aem_GHTykUCGPjMUMkMukkwfYA','2026-06-08 15:34:41','2026-06-08 15:34:41','2026-06-08 15:34:41','2026-06-08 15:34:41'),
(26,'cd3f2dc1-8b16-40be-b9fc-25c83c84ffb9',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-08 15:42:29','2026-06-08 15:42:29','2026-06-08 15:42:29','2026-06-08 15:42:29'),
(27,'3c73de53-fab9-4726-a1c2-f390233736a5',1,NULL,NULL,NULL,NULL,'desktop','EG','Cairo','/','2026-06-08 15:49:11','2026-06-09 11:17:54','2026-06-08 15:49:11','2026-06-09 11:17:54'),
(28,'cfd7b50b-aef2-4812-9af6-48c3f461ef95',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-08 15:50:07','2026-06-08 15:50:07','2026-06-08 15:50:07','2026-06-08 15:50:07'),
(29,'d20194ef-b7c0-42e7-af0a-c88969f2cb42',NULL,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/','2026-06-08 16:07:00','2026-06-08 16:07:00','2026-06-08 16:07:00','2026-06-08 16:07:00'),
(30,'b0b96214-ee00-447a-b355-0b89fce38122',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnHa2mAQeaDWLMADzjwwxoLt3vRER_BNIuJnZcUi0NsjjDJxA2S1W-bQG1jEk_aem_ByRmM9nAGk_1D_cicCl13w','2026-06-08 16:07:34','2026-06-08 16:07:34','2026-06-08 16:07:34','2026-06-08 16:07:34'),
(31,'d9747463-ce45-49d3-b2cd-10429d3c5217',NULL,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/products/jjj-1780933364286','2026-06-08 16:07:44','2026-06-08 16:41:25','2026-06-08 16:07:44','2026-06-08 16:41:25'),
(32,'cf1f4f53-7ce9-4aa0-8325-e6fcc0ea1e1b',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/category/mens-clothing','2026-06-08 16:08:39','2026-06-08 16:08:39','2026-06-08 16:08:39','2026-06-08 16:08:39'),
(33,'9de0606c-ee01-4871-91bd-48713eae8ce6',NULL,NULL,NULL,NULL,NULL,'mobile','EG','Cairo','/','2026-06-08 16:11:56','2026-06-09 16:03:01','2026-06-08 16:11:56','2026-06-09 16:03:01'),
(34,'61c74084-7036-401a-b873-915b3817e16d',NULL,NULL,NULL,NULL,NULL,'mobile','EG','Cairo','/','2026-06-08 16:13:50','2026-06-09 18:48:38','2026-06-08 16:13:50','2026-06-09 18:48:38'),
(35,'0d9cce6e-d5bc-44bb-a40e-a22da26c95f9',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-08 16:25:45','2026-06-08 16:26:16','2026-06-08 16:25:45','2026-06-08 16:26:16'),
(36,'2aa44102-3358-4ae2-9465-5f02b1973303',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/','2026-06-08 16:29:28','2026-06-08 16:29:28','2026-06-08 16:29:28','2026-06-08 16:29:28'),
(37,'50979b2e-4082-401f-ae12-b16564ae1ec1',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn5PFzLF9ShXuibCV2r-_ioeYjjIFLmrJLP-sSJ-EUD1v6uFOiWGL7qdo88GI_aem_XXacnqY93xyxwkZ5M1GM2w','2026-06-08 16:33:01','2026-06-08 16:33:01','2026-06-08 16:33:01','2026-06-08 16:33:01'),
(38,'1d18e39a-99ec-4347-83fa-548fbceccae9',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/products/embroidered-denim-jacket','2026-06-08 16:33:30','2026-06-08 16:33:55','2026-06-08 16:33:30','2026-06-08 16:33:55'),
(39,'99bf4d86-8b12-4fce-90c1-de5219b94c6f',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/','2026-06-08 16:34:42','2026-06-08 16:34:42','2026-06-08 16:34:42','2026-06-08 16:34:42'),
(40,'7b7e33f1-d4c4-44f9-8a1b-cdcfb2f368f8',NULL,NULL,NULL,NULL,NULL,'desktop','US','Ashburn','/','2026-06-08 16:40:39','2026-06-08 16:40:39','2026-06-08 16:40:39','2026-06-08 16:40:39'),
(41,'6848a907-8cd7-4e3a-91dd-5f55299fd22d',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG','Cairo','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPNTY3MDY3MzQzMzUyNDI3AAGnU86JwgYRaggLHvbk3QxmJoksDT2oudub8vpChpCO7gmI-FccVA8badyKysk_aem_YWdncwACivlBhvzJ5nS9utD0X2Ks&brid=YWdncwGHpTv4tOPITSRN72n6Fsdx','2026-06-08 16:48:17','2026-06-08 16:48:17','2026-06-08 16:48:17','2026-06-08 16:48:17'),
(42,'d96b9ea6-7df9-431a-a341-b2856b4494e7',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG','Ismailia','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnCYPvV1uB4JatwL5YVhUbDkOWLqKSuMuTcpya4tfYl7B6glkxoFWj-orZ0M0_aem_BrN0XOzfxNBJk50uQ6uWSg','2026-06-08 17:01:13','2026-06-08 17:01:13','2026-06-08 17:01:13','2026-06-08 17:01:13'),
(43,'480abc1f-1fbc-41ff-8add-b5f90e5abfe8',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPNTY3MDY3MzQzMzUyNDI3AAGn4dWuPIndtv7TXLIK6SnzeXjNlBTH6GqFlGxorVs05YGVS_9FsMsGdYdEs7s_aem_BC9r5v8eLiWHUTFH6kdIZQ','2026-06-08 17:11:21','2026-06-08 17:13:55','2026-06-08 17:11:21','2026-06-08 17:13:55'),
(44,'95a33ef3-3a74-4516-a8a2-779d734278ca',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnUCJMDQVBo99xugZo_TqaTI-PNbHmjBewN8RJddl2-H4rLwhJEvDNTxfgINw_aem_K-nReXaSkD7Dbgdwa0Yuxw','2026-06-08 17:38:40','2026-06-08 17:38:40','2026-06-08 17:38:40','2026-06-08 17:38:40'),
(45,'30c83f33-1a06-4b79-8fda-dad49cf50aea',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/terms','2026-06-08 18:01:12','2026-06-08 18:01:12','2026-06-08 18:01:12','2026-06-08 18:01:12'),
(46,'5fb9f186-c221-41f4-bb16-7a07f5c4e5cf',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-08 18:05:11','2026-06-08 18:05:43','2026-06-08 18:05:11','2026-06-08 18:05:43'),
(47,'e860ef7a-8e02-4eca-a00b-c64ebe0b5775',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-08 18:05:56','2026-06-08 18:06:28','2026-06-08 18:05:56','2026-06-08 18:06:28'),
(48,'6766a480-ca28-421e-9aff-1b95eff38a5d',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn6rUtbR_1rR6Yt2Qzz4ZM02jxij6b0Qashxl_Gih8QPdSykaIoYUAZSXQvoU_aem_laDD0D2kpJlp62vpI52yZw','2026-06-08 18:20:57','2026-06-08 18:20:57','2026-06-08 18:20:57','2026-06-08 18:20:57'),
(49,'56ce9872-204d-4599-8291-dfb1b53315ae',NULL,'https://www.facebook.com/',NULL,NULL,NULL,'mobile','US',NULL,'/?fbclid=IwZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQMMjU2MjgxMDQwNTU4AAEehwgAcuNefyVZv5WvJujYibNp1SJKmaFYfDXihJoY9jhrE6b_xgT7x4Al6gw_aem_MXE6AboeFM56EdcoOqahCQ','2026-06-08 19:02:25','2026-06-08 19:02:25','2026-06-08 19:02:25','2026-06-08 19:02:25'),
(50,'7f429012-d5f7-460c-bdb8-ada8ab00aec0',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG','Giza','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn5ZM1UoaPQREBMj3px6pcxpW3iGSt32yaP_xQiZsomU9tfRDDvhA29lzChtk_aem_7d2oX-_EKnfGTGma6UR8zA','2026-06-08 21:06:48','2026-06-08 21:06:48','2026-06-08 21:06:48','2026-06-08 21:06:48'),
(51,'b6626c68-e8c1-4058-88fb-c28c1b46243f',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG','Cairo','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnfZgx5R_3VLFXNtIf9ULYVIl1KVtXVjJfvZlVHYESxKzaQiOfvyKW0vS2sN8_aem_ZMG7k_IucQwXAbor648ksQ','2026-06-08 21:13:31','2026-06-10 04:55:46','2026-06-08 21:13:31','2026-06-10 04:55:46'),
(52,'17c332ea-d6c8-45d2-8a57-ecc728f06082',1,NULL,NULL,NULL,NULL,'desktop','EG','Cairo','/','2026-06-08 23:46:23','2026-06-10 02:16:39','2026-06-08 23:46:23','2026-06-10 02:16:39'),
(53,'33342a76-000b-4540-83d6-6c1061fc73b2',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG','Cairo','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGn8OlGgLvbnDwezA3JRnycFI2mf3NLd1fU62ne2sjqz5Mh6ddUWXZyqVj1rrk_aem_zVw_vN3Ka_-0fwjqXNLKYA','2026-06-08 23:52:26','2026-06-08 23:52:26','2026-06-08 23:52:26','2026-06-08 23:52:26'),
(54,'16a94f31-66de-4aa6-8a67-de6b90c49cb1',NULL,NULL,'ig','social',NULL,'mobile','EG','Cairo','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAdGRleASUNTtleHRuA2FlbQIxMQBzcnRjBmFwcF9pZA8xMjQwMjQ1NzQyODc0MTQAAafw6UaAu9ucPB7MDclGfJwUjaZ_c0t3V9Trad7ayOrPkyHp11RZdnKpWPWuuQ_aem_zVw_vN3Ka_-0fwjqXNLKYA','2026-06-08 23:53:19','2026-06-08 23:53:19','2026-06-08 23:53:19','2026-06-08 23:53:19'),
(55,'0be87f4c-9850-4bc8-82fd-22e503253dfb',7,NULL,'ig','social',NULL,'mobile','EG','Cairo','/products/hyh-1780933430759','2026-06-08 23:55:51','2026-06-09 21:35:43','2026-06-08 23:55:51','2026-06-09 21:35:43'),
(56,'37156259-5972-451a-bb85-c8e5c37be70a',NULL,NULL,NULL,NULL,NULL,'mobile','EG','Cairo','/','2026-06-09 00:11:52','2026-06-09 10:55:06','2026-06-09 00:11:52','2026-06-09 10:55:06'),
(57,'39c6485a-0dbd-453e-a5ba-54519f780039',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products/long-sleeve-shirt','2026-06-09 05:06:36','2026-06-09 05:06:36','2026-06-09 05:06:36','2026-06-09 05:06:36'),
(58,'66a23493-7b01-4ac6-a562-d278d69705cf',NULL,NULL,NULL,NULL,NULL,'desktop','ES',NULL,'/','2026-06-09 06:49:33','2026-06-09 06:49:33','2026-06-09 06:49:33','2026-06-09 06:49:33'),
(59,'a46a522a-734e-41ec-9843-3d5d4e09c2a0',NULL,NULL,NULL,NULL,NULL,'desktop','GB','Manchester','/login','2026-06-09 06:50:13','2026-06-09 06:50:13','2026-06-09 06:50:13','2026-06-09 06:50:13'),
(60,'2eb524a8-1eb8-4209-9fa6-273c8ba21cb3',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?category=2','2026-06-09 06:51:39','2026-06-09 06:51:39','2026-06-09 06:51:39','2026-06-09 06:51:39'),
(61,'5d83c271-c134-4d2c-a409-99a6b22baf31',NULL,NULL,NULL,NULL,NULL,'desktop','RO',NULL,'/','2026-06-09 06:51:53','2026-06-09 06:51:53','2026-06-09 06:51:53','2026-06-09 06:51:53'),
(62,'eb8a870e-cd88-4e9d-a112-a59994a59478',NULL,NULL,NULL,NULL,NULL,'desktop','NL','Amsterdam','/login','2026-06-09 06:52:30','2026-06-09 06:52:30','2026-06-09 06:52:30','2026-06-09 06:52:30'),
(63,'2a42377c-da2f-4e13-862b-9bd1447e9670',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?category=2','2026-06-09 06:54:15','2026-06-09 06:54:15','2026-06-09 06:54:15','2026-06-09 06:54:15'),
(64,'70dd0e03-8ea0-421a-9f7f-c37911ae337b',NULL,NULL,NULL,NULL,NULL,'desktop','NL',NULL,'/','2026-06-09 06:55:53','2026-06-09 06:55:53','2026-06-09 06:55:53','2026-06-09 06:55:53'),
(65,'34560882-7fc7-4c41-b2e5-df9306431270',NULL,NULL,NULL,NULL,NULL,'desktop','SK',NULL,'/login','2026-06-09 06:56:17','2026-06-09 06:56:17','2026-06-09 06:56:17','2026-06-09 06:56:17'),
(66,'5c20b8e6-340c-4961-82ba-9456d39bc82f',NULL,NULL,NULL,NULL,NULL,'desktop',NULL,NULL,'/cmd_sco','2026-06-09 06:56:32','2026-06-09 06:56:32','2026-06-09 06:56:32','2026-06-09 06:56:32'),
(67,'85bea5a9-0f6e-4abe-8c39-14f6bab89193',NULL,NULL,NULL,NULL,NULL,'desktop','GB',NULL,'/about-us','2026-06-09 07:01:42','2026-06-09 07:01:42','2026-06-09 07:01:42','2026-06-09 07:01:42'),
(68,'55b3620e-417d-4eff-938a-ef4045070d88',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 07:09:09','2026-06-09 07:09:09','2026-06-09 07:09:10','2026-06-09 07:09:10'),
(69,'a7686653-8085-47c3-8300-a9f8e3f93baa',NULL,NULL,NULL,NULL,NULL,'desktop','FR',NULL,'/','2026-06-09 07:39:59','2026-06-09 07:39:59','2026-06-09 07:39:59','2026-06-09 07:39:59'),
(70,'0ce8aabb-e446-45c7-8f27-7ffa6f89bb93',NULL,NULL,NULL,NULL,NULL,'desktop','FR','Paris','/','2026-06-09 08:53:34','2026-06-09 08:53:34','2026-06-09 08:53:35','2026-06-09 08:53:35'),
(71,'8e34d515-411a-4c6f-9410-924f85a2c218',NULL,NULL,NULL,NULL,NULL,'desktop','US','Ashburn','/','2026-06-09 09:44:05','2026-06-09 09:44:05','2026-06-09 09:44:05','2026-06-09 09:44:05'),
(72,'fb5f43d0-0d0e-42b2-8277-405f1b9b9c8a',1,'https://theboutiqueline.com/',NULL,NULL,NULL,'desktop','EG','Cairo','/products','2026-06-09 11:18:27','2026-06-10 07:30:30','2026-06-09 11:18:27','2026-06-10 07:30:30'),
(73,'b7802db3-fcdf-43c3-9d90-18ec3468c396',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG',NULL,'/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnP0ZLJtRr2zklu9-3auloiTWJCm5rsN80jHIRiQdRDqT9wE0WrkfrlxehkVA_aem_w4SFidsnQWi5yDYdJatABA','2026-06-09 14:36:10','2026-06-09 14:36:48','2026-06-09 14:36:10','2026-06-09 14:36:48'),
(74,'99431ad7-5ce4-45d3-8b2b-4604d898e65e',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 15:03:14','2026-06-09 15:03:14','2026-06-09 15:03:14','2026-06-09 15:03:14'),
(75,'08100d0d-3fc1-44cd-b846-38a10e8137a7',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products','2026-06-09 15:21:18','2026-06-09 15:21:18','2026-06-09 15:21:18','2026-06-09 15:21:18'),
(76,'a97a0019-1aef-49c2-ae9a-b6843901e125',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?minPrice=5&page=1','2026-06-09 15:21:19','2026-06-09 15:21:19','2026-06-09 15:21:19','2026-06-09 15:21:19'),
(77,'3354e84e-13fb-4062-98aa-a558055556cc',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?minPrice=5124&page=1','2026-06-09 15:21:19','2026-06-09 15:21:19','2026-06-09 15:21:19','2026-06-09 15:21:19'),
(78,'f973e263-222d-4b73-aab8-09bfe20bc6d9',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?minPrice=5&page=1','2026-06-09 15:21:20','2026-06-09 15:21:20','2026-06-09 15:21:20','2026-06-09 15:21:20'),
(79,'bc93ced0-794d-4cd1-9183-ee917abddf70',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?page=1&minPrice=1554','2026-06-09 15:21:54','2026-06-09 15:21:54','2026-06-09 15:21:54','2026-06-09 15:21:54'),
(80,'ddcac290-aa95-47a4-94f1-fcb293aed5ce',NULL,NULL,NULL,NULL,NULL,'desktop','US','Ashburn','/','2026-06-09 15:24:12','2026-06-09 15:24:12','2026-06-09 15:24:12','2026-06-09 15:24:12'),
(81,'5e27c4eb-dca0-4256-b22c-e05187dc2e4e',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 15:27:22','2026-06-09 15:27:22','2026-06-09 15:27:22','2026-06-09 15:27:22'),
(82,'8f242bd1-0936-4a70-bedd-f25afd72fbe0',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?minPrice=42&page=1','2026-06-09 15:37:19','2026-06-09 15:37:19','2026-06-09 15:37:19','2026-06-09 15:37:19'),
(83,'d806bbc0-25f6-4ebd-b22a-dfa29e02326d',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?minPrice=425&page=1','2026-06-09 15:37:19','2026-06-09 15:37:19','2026-06-09 15:37:19','2026-06-09 15:37:19'),
(84,'9cdf5dfe-ef1e-4d30-83cf-c65e4a478d08',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products?minPrice=48&page=1','2026-06-09 15:46:33','2026-06-09 15:46:33','2026-06-09 15:46:33','2026-06-09 15:46:33'),
(85,'f256ac6a-a5b0-492b-bbc9-28c2d98795ba',NULL,NULL,NULL,NULL,NULL,'other','US',NULL,'/products/signature-knit-sweater','2026-06-09 15:48:33','2026-06-09 15:48:33','2026-06-09 15:48:33','2026-06-09 15:48:33'),
(86,'edc939d8-9f1f-4247-826a-c0b4430a1bdc',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/products/signature-knit-sweater','2026-06-09 15:48:37','2026-06-09 15:48:37','2026-06-09 15:48:37','2026-06-09 15:48:37'),
(87,'61a6f42a-ada4-4e30-879a-4fd971a6dc30',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/about','2026-06-09 16:02:51','2026-06-09 16:02:51','2026-06-09 16:02:51','2026-06-09 16:02:51'),
(88,'a021b6af-e765-4194-bbd6-afabdc251574',NULL,NULL,NULL,NULL,NULL,'other','US',NULL,'/about','2026-06-09 16:02:51','2026-06-09 16:02:51','2026-06-09 16:02:51','2026-06-09 16:02:51'),
(89,'6cc60d10-e340-48a1-a656-65b5d5f2e360',NULL,NULL,NULL,NULL,NULL,'other','US',NULL,'/privacy','2026-06-09 16:02:57','2026-06-09 16:02:57','2026-06-09 16:02:57','2026-06-09 16:02:57'),
(90,'a7feb5b1-950e-4dc7-a323-b19af598a2f6',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/privacy','2026-06-09 16:02:58','2026-06-09 16:02:58','2026-06-09 16:02:58','2026-06-09 16:02:58'),
(91,'1f467b9d-64cb-4354-b34f-758cea6d92ed',NULL,NULL,NULL,NULL,NULL,'other','US',NULL,'/terms','2026-06-09 16:03:03','2026-06-09 16:03:03','2026-06-09 16:03:03','2026-06-09 16:03:03'),
(92,'f5bb767b-84a5-4751-944f-06f521263df3',NULL,NULL,NULL,NULL,NULL,'mobile','US',NULL,'/terms','2026-06-09 16:03:03','2026-06-09 16:03:03','2026-06-09 16:03:03','2026-06-09 16:03:03'),
(93,'f5fc4640-c267-4b6b-86ae-6bbbdcd3800c',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 16:31:31','2026-06-09 16:31:31','2026-06-09 16:31:31','2026-06-09 16:31:31'),
(94,'9c5fa2b3-f796-4c43-ad3a-cc1cbeb9bc47',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 16:32:09','2026-06-09 16:32:09','2026-06-09 16:32:09','2026-06-09 16:32:09'),
(95,'0cd2dab6-3486-481a-b85b-e665877dc211',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 16:33:01','2026-06-09 16:33:01','2026-06-09 16:33:01','2026-06-09 16:33:01'),
(96,'0109911e-3cc2-4dc9-8f36-32123b167cd7',NULL,NULL,NULL,NULL,NULL,'desktop','RU','Vladivostok','/','2026-06-09 17:49:42','2026-06-09 17:49:42','2026-06-09 17:49:42','2026-06-09 17:49:42'),
(97,'5b07a1ca-44b1-4254-bb6c-ba2352901a78',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 18:05:40','2026-06-09 18:05:40','2026-06-09 18:05:40','2026-06-09 18:05:40'),
(98,'91895a99-dccf-4bbc-9bd3-b926e508241a',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 18:06:36','2026-06-09 18:06:36','2026-06-09 18:06:36','2026-06-09 18:06:36'),
(99,'dfe13112-d065-4f48-bcb0-de04b1dab4e8',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 18:25:37','2026-06-09 18:25:37','2026-06-09 18:25:37','2026-06-09 18:25:37'),
(100,'228c918c-5edd-41ad-9841-0f1b94843797',NULL,NULL,NULL,NULL,NULL,'desktop','US','Boardman','/','2026-06-09 19:48:49','2026-06-09 19:48:49','2026-06-09 19:48:49','2026-06-09 19:48:49'),
(101,'bc653a7c-1205-4e3b-b6ca-bb13ccaf683a',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG','Alexandria','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnali8dGQz1VJmuSLnNF6eFrvUOwa8iE5XOoPxy0VvC1nAKRsIiHfWA8j-gMA_aem_npMxds7nwVYR_MLmkmVN7A','2026-06-09 20:01:13','2026-06-09 20:01:30','2026-06-09 20:01:13','2026-06-09 20:01:30'),
(102,'52fb79aa-ebe9-4ae1-8c5b-31dd1ad13cd1',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 20:29:43','2026-06-09 20:29:43','2026-06-09 20:29:43','2026-06-09 20:29:43'),
(103,'97cdce09-db3d-4dd8-aa32-1fda3fc97dd8',NULL,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/','2026-06-09 20:40:52','2026-06-09 20:41:45','2026-06-09 20:40:52','2026-06-09 20:41:45'),
(104,'83d03ae5-37f8-4881-b206-c1e2f85619d8',NULL,NULL,NULL,NULL,NULL,'mobile','EG',NULL,'/products/premium-zip-hoodie','2026-06-09 21:16:40','2026-06-09 21:16:40','2026-06-09 21:16:40','2026-06-09 21:16:40'),
(105,'68b2c010-c63d-459a-b73e-1af25b83830c',NULL,'https://www.google.com/',NULL,NULL,NULL,'desktop','EG','Cairo','/','2026-06-09 21:35:25','2026-06-10 00:14:32','2026-06-09 21:35:25','2026-06-10 00:14:32'),
(106,'50e12dd0-b1af-4405-bd56-b3f240c4934e',NULL,'https://l.instagram.com/','ig','social',NULL,'mobile','EG','Cairo','/?utm_source=ig&utm_medium=social&utm_content=link_in_bio&fbclid=PAZXh0bgNhZW0CMTEAc3J0YwZhcHBfaWQPMTI0MDI0NTc0Mjg3NDE0AAGnYNidTGYIvWfi0cx_umnzhlS0r61VY-iUQWUk-zciFVIQbXn1RtT7q_rVpms_aem_x3S2Su5B2A-U86uJEZBuTA','2026-06-09 21:36:21','2026-06-09 21:48:44','2026-06-09 21:36:21','2026-06-09 21:48:44'),
(107,'499ab9a6-9080-41f1-af53-4c7e85a3f15d',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 23:43:28','2026-06-09 23:43:28','2026-06-09 23:43:28','2026-06-09 23:43:28'),
(108,'25066b7a-73e1-4f82-9220-33d7eed3a423',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 23:58:13','2026-06-09 23:58:13','2026-06-09 23:58:13','2026-06-09 23:58:13'),
(109,'s-1781049504266-xv4klumyw',NULL,NULL,NULL,NULL,NULL,'desktop','US',NULL,'/','2026-06-09 23:58:24','2026-06-09 23:58:24','2026-06-09 23:58:24','2026-06-09 23:58:24'),
(110,'7384018e-2e78-40e4-8624-2f3d23544628',NULL,NULL,NULL,NULL,NULL,'mobile','EG','Cairo','/','2026-06-10 00:25:13','2026-06-10 00:27:30','2026-06-10 00:25:13','2026-06-10 00:27:30'),
(111,'988de8f3-b1e8-4ba2-8d7b-1f6c0b240286',NULL,NULL,NULL,NULL,NULL,'other','CA','Montreal','/','2026-06-10 01:55:02','2026-06-10 01:55:02','2026-06-10 01:55:02','2026-06-10 01:55:02');
/*!40000 ALTER TABLE `store_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name_ar` varchar(100) NOT NULL,
  `name_en` varchar(100) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `image` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `slug_2` (`slug`),
  UNIQUE KEY `slug_3` (`slug`),
  UNIQUE KEY `slug_4` (`slug`),
  UNIQUE KEY `slug_5` (`slug`),
  UNIQUE KEY `slug_6` (`slug`),
  UNIQUE KEY `slug_7` (`slug`),
  UNIQUE KEY `slug_8` (`slug`),
  UNIQUE KEY `slug_9` (`slug`),
  UNIQUE KEY `slug_10` (`slug`),
  UNIQUE KEY `slug_11` (`slug`),
  UNIQUE KEY `slug_12` (`slug`),
  UNIQUE KEY `slug_13` (`slug`),
  UNIQUE KEY `slug_14` (`slug`),
  UNIQUE KEY `slug_15` (`slug`),
  UNIQUE KEY `slug_16` (`slug`),
  UNIQUE KEY `slug_17` (`slug`),
  UNIQUE KEY `slug_18` (`slug`),
  UNIQUE KEY `slug_19` (`slug`),
  UNIQUE KEY `slug_20` (`slug`),
  UNIQUE KEY `slug_21` (`slug`),
  UNIQUE KEY `slug_22` (`slug`),
  UNIQUE KEY `slug_23` (`slug`),
  UNIQUE KEY `slug_24` (`slug`),
  UNIQUE KEY `slug_25` (`slug`),
  UNIQUE KEY `slug_26` (`slug`),
  UNIQUE KEY `slug_27` (`slug`),
  UNIQUE KEY `slug_28` (`slug`),
  UNIQUE KEY `slug_29` (`slug`),
  UNIQUE KEY `slug_30` (`slug`),
  UNIQUE KEY `slug_31` (`slug`),
  KEY `category_id` (`category_id`),
  KEY `subcategories_parent_id_foreign_idx` (`parent_id`),
  KEY `subcategories_category_parent_idx` (`category_id`,`parent_id`),
  CONSTRAINT `subcategories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `subcategories_parent_id_foreign_idx` FOREIGN KEY (`parent_id`) REFERENCES `subcategories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subcategories`
--

LOCK TABLES `subcategories` WRITE;
/*!40000 ALTER TABLE `subcategories` DISABLE KEYS */;
/*!40000 ALTER TABLE `subcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(500) DEFAULT NULL,
  `role_id` int(11) DEFAULT 2,
  `is_active` tinyint(1) DEFAULT 1,
  `email_verified` tinyint(1) DEFAULT 0,
  `otp` varchar(10) DEFAULT NULL,
  `otp_expires` datetime DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `email_2` (`email`),
  UNIQUE KEY `email_3` (`email`),
  UNIQUE KEY `email_4` (`email`),
  UNIQUE KEY `email_5` (`email`),
  UNIQUE KEY `email_6` (`email`),
  UNIQUE KEY `email_7` (`email`),
  UNIQUE KEY `email_8` (`email`),
  UNIQUE KEY `email_9` (`email`),
  UNIQUE KEY `email_10` (`email`),
  UNIQUE KEY `email_11` (`email`),
  UNIQUE KEY `email_12` (`email`),
  UNIQUE KEY `email_13` (`email`),
  UNIQUE KEY `email_14` (`email`),
  UNIQUE KEY `email_15` (`email`),
  UNIQUE KEY `email_16` (`email`),
  UNIQUE KEY `email_17` (`email`),
  UNIQUE KEY `email_18` (`email`),
  UNIQUE KEY `email_19` (`email`),
  UNIQUE KEY `email_20` (`email`),
  UNIQUE KEY `email_21` (`email`),
  UNIQUE KEY `email_22` (`email`),
  UNIQUE KEY `email_23` (`email`),
  UNIQUE KEY `email_24` (`email`),
  UNIQUE KEY `email_25` (`email`),
  UNIQUE KEY `email_26` (`email`),
  UNIQUE KEY `email_27` (`email`),
  UNIQUE KEY `email_28` (`email`),
  UNIQUE KEY `email_29` (`email`),
  UNIQUE KEY `email_30` (`email`),
  UNIQUE KEY `email_31` (`email`),
  UNIQUE KEY `email_32` (`email`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Admin','admin@theboutiqueline.com',NULL,'$2a$12$JaqujwvZRxbo7LXyNDZYbeywYuVBhEvuRWUWgl3IP0aTZLnG2qSSu',NULL,1,1,1,NULL,NULL,NULL,NULL,'2026-06-09 21:11:37','2026-06-02 08:17:45','2026-06-09 21:11:37'),
(2,'Orders Admin 1','orders1@theboutiqueline.com',NULL,'$2a$12$qlQIEopVKYGljaM.fYEPW.ElcpYjD9TD9H7lfBpJgf0MNMSwyhQG2',NULL,3,1,1,NULL,NULL,NULL,NULL,'2026-06-07 12:01:26','2026-06-07 11:55:01','2026-06-07 12:01:26'),
(3,'Orders Admin 2','orders2@theboutiqueline.com',NULL,'$2a$12$Y00gsTCb9HprqkU.phEAuOvPkTFdX.fw.QbkYPwOtFTbkQ8IU99JK',NULL,3,1,1,NULL,NULL,NULL,NULL,NULL,'2026-06-07 11:55:01','2026-06-07 11:55:01'),
(4,'Orders Admin 3','orders3@theboutiqueline.com',NULL,'$2a$12$0uqWRcBxMC1hkDiUyi6lGevKGuW27YORz/4Dumayy4zm7yJVf/xqu',NULL,3,1,1,NULL,NULL,NULL,NULL,NULL,'2026-06-07 11:55:02','2026-06-07 11:55:02'),
(6,'Admin','admin@miskwear.com',NULL,'$2a$12$BaDcL62e2Hq9C2zsf3JnKOGRdIqEYvUiyoXVCcqiD2hDPY8.ZwXDy',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,'2026-06-08 13:27:16','2026-06-08 13:27:16'),
(7,'Mohamed atef','mohamedatef5115@gmail.com','01123360043','$2a$12$RyZySjlg2x.3QKFvCfzxD.CX0fDBTgOH8kLMmacnJY0m5uRCAkQxy',NULL,2,1,1,NULL,NULL,NULL,NULL,NULL,'2026-06-08 23:59:51','2026-06-09 00:00:19');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whatsapp_integrations`
--

DROP TABLE IF EXISTS `whatsapp_integrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `whatsapp_integrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) DEFAULT 0,
  `phone_number_id` varchar(80) DEFAULT NULL,
  `whatsapp_business_account_id` varchar(64) DEFAULT NULL,
  `graph_api_version` varchar(20) DEFAULT 'v21.0',
  `phone_country_code` varchar(15) NOT NULL DEFAULT '966',
  `encrypted_credentials` text DEFAULT NULL,
  `iv` varchar(32) DEFAULT NULL,
  `auth_tag` varchar(32) DEFAULT NULL,
  `template_config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`template_config`)),
  `connection_status` varchar(30) DEFAULT 'disconnected',
  `last_error` text DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whatsapp_integrations`
--

LOCK TABLES `whatsapp_integrations` WRITE;
/*!40000 ALTER TABLE `whatsapp_integrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `whatsapp_integrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `wishlists_ibfk_53` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `wishlists_ibfk_54` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlists`
--

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'adminanmkavps_tbl'
--

--
-- Dumping routines for database 'adminanmkavps_tbl'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-06-10  9:36:27
